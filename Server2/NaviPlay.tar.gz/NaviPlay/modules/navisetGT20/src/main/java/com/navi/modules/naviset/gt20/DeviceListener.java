package com.navi.modules.naviset.gt20;

import com.navi.core.client.messages.toClient.AlarmStatusMessage;
import com.navi.core.jms.Sender;
import com.navi.core.client.messages.FromClientMessage;
import com.navi.core.client.messages.ToClientMessage;
import com.navi.core.client.messages.toClient.ConnectMessage;
import com.navi.core.navisetGT20.AlarmSourceType;
import com.navi.core.navisetGT20.Client2DeviceConverter;
import com.navi.core.navisetGT20.Device2ClientConverter;
import com.navi.core.navisetGT20.DeviceAlarm;
import com.navi.core.navisetGT20.DeviceDataMessage;
import com.navi.core.navisetGT20.DeviceEvent;
import com.navi.core.navisetGT20.FromDeviceMessage;
import com.navi.core.navisetGT20.GetSocketListRequest;
import com.navi.core.navisetGT20.HeaderMessage;
import com.navi.core.navisetGT20.MessageType;
import com.navi.core.navisetGT20.ToConnectorMessage;
import com.navi.core.navisetGT20.ToDeviceMessage;
import com.navi.core.navisetGT20.command.ResponseMessage;
import com.navi.core.navisetGT20.command.request.GetStatusRequest;
import com.navi.core.navisetGT20.utils.Converter;
import com.navi.modules.auth.AuthManager;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import javax.jms.*;

/**
 * Implement device listener.
 * receive message from device log into database, send if need to client.
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class DeviceListener implements MessageListener {

    final Logger log = Logger.getLogger(DeviceListener.class);

    private Sender toClientSender;
    private Sender toDeviceSender;
    private AuthManager authManager;
    private Device2ClientConverter toClientConverter;
    private Client2DeviceConverter toDeviceConverter;
    private final static String PRM_COMMAND = "command";
    private final static String PRM_SOCKET = "socket_id";
    private final static String PRM_type = "type";
    private final static String PRM_DATA = "data";
    private final static String COMMAND_PACKAGE = "package";
    private final static String COMMAND_DISCONNECT = "disconnect";
    private final static String COMMAND_CONNECT = "connect";

    public DeviceListener(
            Sender toClientSender,
            Sender toDeviceSender,
            AuthManager authManager,
            Device2ClientConverter toClientConverter,
            Client2DeviceConverter toDeviceConverter
    ) {
        this.toClientSender = toClientSender;
        this.toDeviceSender = toDeviceSender;
        this.authManager = authManager;
        this.toClientConverter = toClientConverter;
        this.toDeviceConverter = toDeviceConverter;
    }

    public void init () {
        GetSocketListRequest request = new GetSocketListRequest();
        toDeviceSender.send(request.getMapForSend());
    }
    @Override
    public void onMessage(final Message message) {
        if (message instanceof MapMessage) {
            MapMessage mapMessage = (MapMessage) message;
            try {
                if (mapMessage.itemExists(PRM_COMMAND)) {
                    String command = mapMessage.getString(PRM_COMMAND);
                    Integer socketId = null;
                    if (COMMAND_PACKAGE.equalsIgnoreCase(command)) {
                        Integer mt= null;
                        if (mapMessage.itemExists(PRM_type)) {
                            mt = mapMessage.getInt(PRM_type);
                        }

                        byte[] data = new byte[0];
                        if (mapMessage.itemExists(PRM_DATA)) {
                            data = mapMessage.getBytes(PRM_DATA);
                        }
                        if (mapMessage.itemExists(PRM_SOCKET)) {
                            socketId = mapMessage.getInt(PRM_SOCKET);
                        }
                        MessageType messageType = MessageType.valueByCode(mt);
                        FromDeviceMessage fromDeviceMessage = Converter.bytes2deviceMessage(messageType, data);
                        if (fromDeviceMessage instanceof HeaderMessage) {
                            processHeader ((HeaderMessage) fromDeviceMessage ,socketId);
                        } else if (fromDeviceMessage instanceof DeviceDataMessage) {
                            tempProcessData ((DeviceDataMessage) fromDeviceMessage ,socketId);
                            processData((DeviceDataMessage) fromDeviceMessage);
                        } else if (fromDeviceMessage instanceof ResponseMessage) {
                            processResponse((ResponseMessage) fromDeviceMessage, socketId);
                        } else if (fromDeviceMessage instanceof DeviceAlarm) {
                            processAlarm((DeviceAlarm) fromDeviceMessage, socketId);
                        } else if (fromDeviceMessage instanceof DeviceEvent) {
                            processEvent((DeviceEvent) fromDeviceMessage, socketId);
                        }
                        log.info("receive message from device " + fromDeviceMessage.toString());

                    } else if (COMMAND_DISCONNECT.equalsIgnoreCase(command))  {

                        if (mapMessage.itemExists(PRM_SOCKET)) {
                            socketId = mapMessage.getInt(PRM_SOCKET);
                        }
                        log.info("disconnected socketID " + socketId);
                        Integer deviceNum = authManager.foundDevice(socketId);
                        authManager.removeDeviceBySocket(socketId);
                        ConnectMessage connectMessage = new ConnectMessage();
                        connectMessage.setOnline(false);
                        connectMessage.setDeviceNum(deviceNum);
                        toClientSender.send(connectMessage);

                    } else if (COMMAND_CONNECT.equalsIgnoreCase(command))  {
                        if (mapMessage.itemExists(PRM_SOCKET)) {
                            socketId = mapMessage.getInt(PRM_SOCKET);
                        }
                        log.info("connected socketID " + socketId);

                    } else if (GetSocketListRequest.COMMAND.equalsIgnoreCase(command))  {
                        if (mapMessage.itemExists(GetSocketListRequest.PRM_NAME_SOCKETS)) {
                            String sockets = mapMessage.getString(GetSocketListRequest.PRM_NAME_SOCKETS);
                            log.info("connected sockets " + sockets);
                            for(String s: StringUtils.split(sockets, ",")) {
                                Integer socket_id = null;
                                try {
                                    socket_id = Integer.valueOf(s.trim());
                                } catch (Exception e) {
                                    log.warn("socket cant convert to integer for value " + s);
                                }

                                if (socket_id != null)  {
                                    GetStatusRequest getStatusRequest = new GetStatusRequest();
                                    getStatusRequest.setSocket(socket_id);
                                    toDeviceSender.send(getStatusRequest.getMapForSend());
                                }
                            }
                        }

                    } else {
                        log.warn("UNEXPECTED command " + command);
                    }
                } else {
                    log.warn("UNEXPECTED MESSAGE " + mapMessage);
                }

            } catch (JMSException e) {
                log.error(e.getMessage(), e);
            } catch (NullPointerException e) {
                log.error(e.getMessage(), e);
            } catch (Throwable e) {
                log.error(e.getMessage(), e);
            }
        } else if (message instanceof ObjectMessage) {
            ObjectMessage objectMessage = (ObjectMessage)message;
            try {
                Object obj = objectMessage.getObject();
                if (obj instanceof FromClientMessage) {
                    log.info("dispatch message " + obj.toString());
                    ToConnectorMessage toConnectorMessage = toDeviceConverter.convert((FromClientMessage)obj);

                    if (toConnectorMessage instanceof ToDeviceMessage ) {
                        Integer deviceNum = ((ToDeviceMessage)toConnectorMessage).getDeviceNum();
                        if (deviceNum != null) {
                            Integer socketId = authManager.foundSocket(deviceNum);
                            if (socketId != null) {
                                ((ToDeviceMessage)toConnectorMessage).setSocket(socketId);
                                log.info("send to socket " + socketId + "  device message " + toConnectorMessage);
                            }  else {
                                log.info("device " + deviceNum + " is offline");
                            }
                        } else {
                            log.warn("cant determinate device number from message" + obj);
                        }
                    } else {
                        log.warn("to device message without device number " + toConnectorMessage);
                    }
                    toDeviceSender.send(toConnectorMessage.getMapForSend());
                } else if (obj instanceof ToConnectorMessage) {
                    ToConnectorMessage toConnectorMessage = (ToConnectorMessage) obj;
                    toDeviceSender.send(toConnectorMessage.getMapForSend());
                } else {
                    log.warn("UNEXPECTED OBJECT TYPE IN MESSAGE " + obj);
                }
            } catch (JMSException e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    private void processHeader(HeaderMessage message, Integer socketId) {
        if (authManager.addDevice(null, message.getDeviceNumber(), socketId)) {
            log.trace("SUCCESS AUTH DEVICE " + message.getDeviceNumber());
            ConnectMessage connectMessage = new ConnectMessage();
            connectMessage.setOnline(true);
            connectMessage.setDeviceNum(message.getDeviceNumber());
            toClientSender.send(connectMessage);
        }
    }

    private void tempProcessData(DeviceDataMessage message, Integer socketId) {
        Integer authSocket = authManager.foundSocket(message.getDeviceNumber());
        if (!socketId.equals(authSocket)) {

            authManager.addDevice(null, message.getDeviceNumber(), socketId);
        }
    }

    private void processData(DeviceDataMessage message) {
        //TODO implement message logging
        ToClientMessage clientDataMessage = toClientConverter.convert(message);
        toClientSender.send(clientDataMessage);
    }

    private void processResponse(ResponseMessage message, Integer socketId) {
        Integer deviceNum = authManager.foundDevice(socketId);
        if (deviceNum != null) {
            message.setDeviceNumber(deviceNum);
            ToClientMessage toClientMessage = toClientConverter.convert(message);
            if (toClientMessage != null) {
                toClientSender.send(toClientMessage);
            }
        } else {
            log.error("cant found device for ResponseMessage from socket " + socketId);
        }

    }

    private void processAlarm(DeviceAlarm message, Integer socketId) {
        Integer deviceNum = authManager.foundDevice(socketId);
        if (deviceNum != null) {
            message.setDeviceNumber(deviceNum);
            if (message.getAlarmSources().contains(AlarmSourceType.ALARM_ON)) {
                AlarmStatusMessage statusMessage = new AlarmStatusMessage();
                statusMessage.setDeviceNum(deviceNum);
                statusMessage.setStatus(true);
                toClientSender.send(statusMessage);
            } else if (message.getAlarmSources().contains(AlarmSourceType.ALARM_OFF)) {
                AlarmStatusMessage statusMessage = new AlarmStatusMessage();
                statusMessage.setDeviceNum(deviceNum);
                statusMessage.setStatus(false);
                toClientSender.send(statusMessage);
            }
            ToClientMessage toClientMessage = toClientConverter.convert(message);
            toClientSender.send(toClientMessage);
        } else {
            log.error("cant found device for DeviceAlarm from socket " + socketId);
        }

    }

    private void processEvent(DeviceEvent message, Integer socketId) {
        Integer deviceNum = authManager.foundDevice(socketId);
        if (deviceNum != null) {
            message.setDeviceNumber(deviceNum);
            ToClientMessage toClientMessage = toClientConverter.convert(message);
            toClientSender.send(toClientMessage);
        } else {
            log.error("cant found device for DeviceEvent from socket " + socketId);
        }

    }

}
