package com.navi.core.navisetGT20;

import java.util.HashMap;
import java.util.Map;

/**
 * Запрос коннектору на отключение устройства по номеру сокета.
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class DisconnectSocketRequest extends ToConnectorMessage {

    private final static String COMMAND = "disconnect";
    private final static String SOCKET = "socket_id";

    private Integer socketId;

    @Override
    public Map<String, Object> getMapForSend() {
        Map<String, Object> mapForSend = new HashMap<String, Object>();
        mapForSend.put(PRM_COMMAND, COMMAND);
        mapForSend.put(SOCKET, socketId);
        return mapForSend;
    }

    public Integer getSocketId() {
        return socketId;
    }

    public void setSocketId(final Integer socketId) {
        this.socketId = socketId;
    }

    @Override
    public String toString() {
        return this.getClass().getName() + "{" +
            "socketId=" + socketId +
                '}';
    }
}
