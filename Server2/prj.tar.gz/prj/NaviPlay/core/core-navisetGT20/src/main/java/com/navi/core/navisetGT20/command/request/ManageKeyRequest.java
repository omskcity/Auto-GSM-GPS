package com.navi.core.navisetGT20.command.request;

import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.utils.ByteArrayWriter;
import com.navi.core.navisetGT20.command.RequestMessage;

/**
 * Запрос устройству "".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class ManageKeyRequest extends RequestMessage {

    private Integer process;
    private String number;

    public ManageKeyRequest() {
        super(CommandType.MANAGE_KEY);
    }

    public Integer getProcess() {
        return process;
    }

    public void setProcess(final Integer process) {
        this.process = process;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(final String number) {
        this.number = number;
    }

    @Override
    protected void writeData(final ByteArrayWriter writer) {
        writer.setInteger(1, process);
        writer.setString(6, number);
    }
}
