package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.command.CommonResponseType;
import com.navi.core.navisetGT20.utils.ByteArrayReader;
import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.command.ResponseMessage;

/**
 * Общий ответ. Абстрактный, каждый конкретный запрос имеет свой клас с общим ответом.
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public abstract class AbstractCommonResponse extends ResponseMessage {
    private CommonResponseType status;

    protected AbstractCommonResponse(CommandType commandType) {
        super(commandType);
    }

    public CommonResponseType getStatus() {
        return status;
    }

    public void setStatus(final CommonResponseType status) {
        this.status = status;
    }

    @Override
    public void readData(final ByteArrayReader reader) {

    }

    @Override
    public String toString() {
        return this.getClass().getName()+ "{" +
                "status=" + status +
                '}';
    }
}
