package com.navi.core.navisetGT20.command.request;

import com.navi.core.navisetGT20.OutModeType;
import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.utils.ByteArrayWriter;
import com.navi.core.navisetGT20.command.RequestMessage;
import com.navi.core.navisetGT20.utils.ByteUtils;

/**
 * Запрос устройству "".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SetOutputParamRequest extends RequestMessage {

    private OutModeType mode = OutModeType.OFF;
    private Integer out;
    private Integer impulseTime;
    private Integer pauseTime;
    private Integer repeatCount;

    public SetOutputParamRequest() {
        super(CommandType.SET_OUTPUT_PARAM);
    }


    public OutModeType getMode() {
        return mode;
    }

    public void setMode(final OutModeType mode) {
        this.mode = mode;
    }

    public Integer getOut() {
        return out;
    }

    public void setOut(final Integer out) {
        this.out = out;
    }

    public Integer getImpulseTime() {
        return impulseTime;
    }

    public void setImpulseTime(final Integer impulseTime) {
        this.impulseTime = impulseTime;
    }

    public Integer getPauseTime() {
        return pauseTime;
    }

    public void setPauseTime(final Integer pauseTime) {
        this.pauseTime = pauseTime;
    }

    public Integer getRepeatCount() {
        return repeatCount;
    }

    public void setRepeatCount(final Integer repeatCount) {
        this.repeatCount = repeatCount;
    }

    @Override
    protected void writeData(final ByteArrayWriter writer) {
        boolean [] b = ByteUtils.int2bits(1, out);
        for (int i = 0 ; i < mode.getValue().length; i ++) {
            b[4 + i] = mode.getValue()[i];
        }


        writer.setBooleanArray(1, b);
        writer.setInteger(1, impulseTime);
        writer.setInteger(1, pauseTime);
        writer.setInteger(1, repeatCount);
    }
}
