package com.navi.core.navisetGT20;

import com.navi.core.navisetGT20.utils.ByteArrayReader;

import java.util.EnumSet;

public enum ServiceMessageType {


    SERVICE_MESSAGE_ALARM (200) {
        @Override
        public FromDeviceMessage createMessage(ByteArrayReader reader) {
            return new DeviceAlarm(reader);
        }
    },
    SERVICE_MESSAGE_EVENT (201) {
        @Override
        public FromDeviceMessage createMessage(ByteArrayReader reader) {
            return new DeviceEvent(reader);
        }
    };

    private int respondsID;

    ServiceMessageType(final int respondsID) {
        this.respondsID = respondsID;
    }


    public int getRespondsID() {
        return respondsID;
    }

    public static ServiceMessageType valueByCode(int value) {
        ServiceMessageType returnValue = null;
        for (final ServiceMessageType element : EnumSet.allOf(ServiceMessageType.class)) {
            if ( element.getRespondsID() == value) {
                returnValue = element;
            }
        }
        return returnValue;
    }

    public abstract FromDeviceMessage createMessage(ByteArrayReader reader);

}
