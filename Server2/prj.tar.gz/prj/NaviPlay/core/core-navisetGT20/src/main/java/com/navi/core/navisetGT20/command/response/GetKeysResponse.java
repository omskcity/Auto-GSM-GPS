package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.utils.ByteArrayReader;
import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.command.ResponseMessage;

import java.util.Arrays;

/**
 * ответ на "Получить список зарегистрированных ключей".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class GetKeysResponse extends ResponseMessage {

    private byte [] key1;
    private byte [] key2;
    private byte [] key3;
    private byte [] key4;
    private byte [] key5;
    private byte [] key6;

    public GetKeysResponse() {
        this(CommandType.GET_KEYS);
    }

    private GetKeysResponse(CommandType commandType) {
        super(commandType);
    }

    public byte[] getKey1() {
        return key1;
    }

    public void setKey1(final byte[] key1) {
        this.key1 = key1;
    }

    public byte[] getKey2() {
        return key2;
    }

    public void setKey2(final byte[] key2) {
        this.key2 = key2;
    }

    public byte[] getKey3() {
        return key3;
    }

    public void setKey3(final byte[] key3) {
        this.key3 = key3;
    }

    public byte[] getKey4() {
        return key4;
    }

    public void setKey4(final byte[] key4) {
        this.key4 = key4;
    }

    public byte[] getKey5() {
        return key5;
    }

    public void setKey5(final byte[] key5) {
        this.key5 = key5;
    }

    public byte[] getKey6() {
        return key6;
    }

    public void setKey6(final byte[] key6) {
        this.key6 = key6;
    }

    @Override
    public void readData(final ByteArrayReader reader) {
        setKey1(reader.getBytes(6));
        setKey2(reader.getBytes(6));
        setKey3(reader.getBytes(6));
        setKey4(reader.getBytes(6));
        setKey5(reader.getBytes(6));
        setKey6(reader.getBytes(6));
    }

    @Override
    public String toString() {
        return "GetKeysResponse{" +
                "key1=" + Arrays.toString(key1) +
                ", key2=" + Arrays.toString(key2) +
                ", key3=" + Arrays.toString(key3) +
                ", key4=" + Arrays.toString(key4) +
                ", key5=" + Arrays.toString(key5) +
                ", key6=" + Arrays.toString(key6) +
                '}';
    }
}
