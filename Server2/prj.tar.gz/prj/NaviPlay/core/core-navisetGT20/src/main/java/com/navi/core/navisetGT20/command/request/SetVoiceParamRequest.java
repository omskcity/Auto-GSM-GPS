package com.navi.core.navisetGT20.command.request;

import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.utils.ByteArrayWriter;
import com.navi.core.navisetGT20.command.RequestMessage;

/**
 * Запрос устройству "".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SetVoiceParamRequest extends RequestMessage {
    private Integer microphoneBoost;
    private Integer dynamicBoost;
    private Integer beepCountBeforeGetUp;
    private Integer voiceMenuVolume;


    public SetVoiceParamRequest() {
        super(CommandType.SET_VOICE_PARAM);
    }

    public Integer getMicrophoneBoost() {
        return microphoneBoost;
    }

    public void setMicrophoneBoost(final Integer microphoneBoost) {
        this.microphoneBoost = microphoneBoost;
    }

    public Integer getDynamicBoost() {
        return dynamicBoost;
    }

    public void setDynamicBoost(final Integer dynamicBoost) {
        this.dynamicBoost = dynamicBoost;
    }

    public Integer getBeepCountBeforeGetUp() {
        return beepCountBeforeGetUp;
    }

    public void setBeepCountBeforeGetUp(final Integer beepCountBeforeGetUp) {
        this.beepCountBeforeGetUp = beepCountBeforeGetUp;
    }

    public Integer getVoiceMenuVolume() {
        return voiceMenuVolume;
    }

    public void setVoiceMenuVolume(final Integer voiceMenuVolume) {
        this.voiceMenuVolume = voiceMenuVolume;
    }

    @Override
    protected void writeData(final ByteArrayWriter writer) {
        writer.setInteger(1, microphoneBoost);
        writer.setInteger(1, dynamicBoost);
        writer.setInteger(1, beepCountBeforeGetUp);
        writer.setInteger(1, voiceMenuVolume);
    }
}
