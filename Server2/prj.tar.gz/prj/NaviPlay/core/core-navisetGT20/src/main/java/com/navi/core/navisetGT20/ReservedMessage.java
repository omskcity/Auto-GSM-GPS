package com.navi.core.navisetGT20;

import com.navi.core.navisetGT20.utils.ByteArrayReader;

/**
 * Reserved messageType.
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class ReservedMessage extends FromDeviceMessage {
    private ByteArrayReader reader;


    public ReservedMessage(ByteArrayReader reader) {
        super(MessageType.RESERVED);
        this.reader = reader;
    }

    @Override
    public String toString() {
        return "ReservedMessage";
    }
}
