package com.navi.core.navisetGT20.utils;

import java.util.Arrays;

/**
 * Byte operations and conversation.
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class ByteUtils {

    public static boolean getBit(byte b, byte i) {
        return i >= 0 && i < Byte.SIZE && ((b & (1 << i)) != 0);
    }

    public static boolean getBit(int b, int i) {
        return i >= 0 && i < Byte.SIZE * 3 && ((b & (1 << i)) != 0);
    }

    public static boolean getBit(long b, int i) {
        return i >= 0 && i < Byte.SIZE * 3 && ((b & (1 << i)) != 0);
    }

    public static boolean [] byte2bits(byte b) {
        boolean [] bits = new boolean[Byte.SIZE];
        for (byte i = 0; i < Byte.SIZE; i++) {
            bits[i] = getBit(b, i);
        }
        return bits;
    }

    public static boolean [] int2bits(int len, int b) {
        boolean [] bits = new boolean[len*Byte.SIZE];
        for (int i = 0; i < Byte.SIZE; i++) {
            bits[i] = getBit(b, i);
        }
        return bits;
    }

    public static boolean [] long2bits(int len, long b) {
        boolean [] bits = new boolean[len*Byte.SIZE];
        for (int i = 0; i < Byte.SIZE; i++) {
            bits[i] = getBit(b, i);
        }
        return bits;
    }

    public static boolean [] byte2bits(int len,  byte b) {
        if (len<= Byte.SIZE && len > 0) {
            if (b <= (2 ^ len)) {
                boolean [] bits = byte2bits(b);
                boolean [] res = new boolean[len];
                System.arraycopy(bits, 0, res, 0, len);
                return res;
            }
        }
        return new boolean[0];
    }
    public static boolean [] mergeBits(boolean [] bits1, boolean [] bits2) {
        boolean [] bites = new boolean[bits1.length + bits2.length];
        System.arraycopy(bits1, 0, bites, 0, bits1.length);
        System.arraycopy(bits2, 0, bites, bits1.length, bits2.length);
        return bites;
    }

    public static boolean [] bytes2bits(byte [] bytes) {
        boolean [] bits = new boolean[Byte.SIZE * bytes.length];
        int i=0;
        for (byte b: bytes) {
            boolean [] bits2 = byte2bits(b);
            System.arraycopy(bits2, 0, bits, i * 8, Byte.SIZE);
            i++;
        }
        return bits;
    }
/*
    public static String bits2String(boolean [] bits) {
        StringBuilder sb = new StringBuilder();
        for (final boolean bit1 : bits) {
            if (bit1) {
                sb.insert(0, 1);
            }
            else {
                sb.insert(0, 0);
            }
        }
        return sb.toString();
    }
  */
    public static byte bits2byte(boolean [] bits) {
        byte b = 0;
        for (byte bit = 0;  bit < Byte.SIZE ; bit++) {
            if (bits[bit]) {
                b |= 1 << bit;
            } else {
                b &= ~(1 << bit);
            }
        }
        return b;
    }

    public static byte [] bits2bytes(int len, boolean [] bits) {

        byte b[] = new byte[len];

        for (int i = 0;  i < len ; i++) {
            boolean [] tbites = Arrays.copyOfRange(bits, i*Byte.SIZE, (i+1)*Byte.SIZE );
            b[i] = bits2byte(tbites);
        }
        return b;
    }

    /*
    public static int bits2int(boolean [] bits) {
        int b = 0;
        for (int bit =  0; bit < bits.length   ; bit++) {
            if (bits[bit]) {
                b |= 1 << bit;
            } else {
                b &= ~(1 << bit);
            }
        }
        return b;
    }

    public static long bits2long(boolean [] bits) {
        long b = 0;
        for (int bit =  0; bit < bits.length   ; bit++) {
            if (bits[bit]) {
                b |= 1 << bit;
            } else {
                b &= ~(1 << bit);
            }
        }
        return b;
    }
    public static MessageType getMessageType (byte b) {
        boolean [] bits = byte2bits(b);
        boolean b0 = bits[0];
        boolean b1 = bits[1];
        if (!b0) {
            if (!b1) {
                return MessageType.HEAD;
            } else {
                return MessageType.DATA;
            }

        } else {
            if (!b1) {
                return MessageType.RESPONSE_SERVICE;
            } else {
                return MessageType.RESERVED;
            }
        }
    }
    */

    public static int getUnsignByte(byte b) {
        return b <0? b + 256: b;
    }

    public static int getUnsignShortValue (byte[] bytes) {
        if (bytes.length <3) {
            int l=0;
            for (int i = bytes.length; i > 0; i--) {
                 l = l*256 +getUnsignByte(bytes[i-1]);
            }
            return l;
        }
        return -1;
    }

    public static long getUnsignIntValue (byte[] bytes) {
        if (bytes.length <5) {
            long l=0;

            for (int i = bytes.length; i > 0; i--) {
                l = l*256 +getUnsignByte(bytes[i-1]);
            }
            return l;
        }
        return -1;
    }
    public static long getUnsignIntValue1 (byte[] bytes) {
        if (bytes.length <5) {
            long l=0;

            for (int i = 0; i < bytes.length; i++) {
                l = l*256 +getUnsignByte(bytes[i]);
            }
            return l;
        }
        return -1;
    }

    public static String getStringValue (byte[] bytes) {
        return new String(bytes);
    }


}
