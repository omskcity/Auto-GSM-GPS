package com.navi.core.navisetGT20.command.request;

import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.utils.ByteArrayWriter;
import com.navi.core.navisetGT20.command.RequestMessage;
import com.navi.core.navisetGT20.utils.ByteUtils;

/**
 * Запрос устройству "".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class GetCamImageRequest extends RequestMessage {

    /*
    0 - запрос изображения, 1 - подтверждение: пакет принят, 2 - подтверждение: пакет битый
    */
    private byte type;
    /*
    разрешение изображения: 0 - 80х64, 1 - 160х128, 2 - 320х240, 3 - 640х480
     */
    private byte size;

    public byte getType() {
        return type;
    }

    public void setType(byte type) {
        this.type = type;
    }

    public byte getSize() {
        return size;
    }

    public void setSize(byte size) {
        this.size = size;
    }

    public GetCamImageRequest() {
        super(CommandType.GET_CAM_IMAGE);
    }

    @Override
    protected void writeData(final ByteArrayWriter writer) {
        boolean b2 [] = ByteUtils.byte2bits(4, type);
        boolean b1 [] = ByteUtils.byte2bits(4, size);
        boolean b [] = ByteUtils.mergeBits(b1, b2);
        writer.setBooleanArray(1, b);
    }

    @Override
    public String toString() {
        return "GetCamImageRequest{" +
                "type=" + type +
                ", size=" + size +
                '}';
    }
}
