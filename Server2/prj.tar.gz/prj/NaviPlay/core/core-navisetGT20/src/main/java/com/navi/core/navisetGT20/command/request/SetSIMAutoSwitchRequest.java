package com.navi.core.navisetGT20.command.request;

import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.command.RequestMessage;
import com.navi.core.navisetGT20.utils.ByteArrayWriter;

/**
 * Запрос устройству "".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SetSIMAutoSwitchRequest extends RequestMessage {
    private Integer active;

    public SetSIMAutoSwitchRequest() {
        super(CommandType.SET_SIM_AUTOSWITCH);
    }
    public Integer getActive() {
        return active;
    }

    public void setActive(final Integer active) {
        this.active = active;
    }

    @Override
    protected void writeData(final ByteArrayWriter writer) {
        writer.setInteger(1, active);
    }
}
