package com.navi.core.navisetGT20;

import com.navi.core.navisetGT20.utils.ByteArrayReader;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class DeviceAlarm extends FromDeviceMessage {

    public static final Integer ALARM_MESSAGE_LENGTH = 2;

    public DeviceAlarm(ByteArrayReader reader) {
        super(MessageType.RESPONSE_SERVICE);
        boolean [] bits = reader.getBooleanArray(ALARM_MESSAGE_LENGTH);
        for(int i=0; i<bits.length; i++) {
            if (bits[i]) {
                AlarmSourceType sourceType = AlarmSourceType.valueByCode(i);
                if (sourceType != null) {
                    alarmSources.add(sourceType);
                }
            }
        }
    }
    private Set<AlarmSourceType> alarmSources = new HashSet<AlarmSourceType>();

    public Set<AlarmSourceType> getAlarmSources() {
        return alarmSources;
    }

    @Override
    public String toString() {
        return "DeviceAlarm{" +
                "deviceNum=" + getDeviceNumber() +
                "alarmSources=" + Arrays.toString(alarmSources.toArray(new AlarmSourceType[alarmSources.size()])) +
                '}';
    }
}

