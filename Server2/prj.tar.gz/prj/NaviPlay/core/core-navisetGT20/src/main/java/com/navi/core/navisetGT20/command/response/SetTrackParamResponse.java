package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.command.CommandType;

/**
 * Ответ на "Параметры фильтрации и прорисовки трека".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SetTrackParamResponse extends AbstractCommonResponse {

    public SetTrackParamResponse() {
        this(CommandType.SET_TRACK_PARAM);
    }

    private SetTrackParamResponse(CommandType commandType) {
        super(commandType);
    }

}
