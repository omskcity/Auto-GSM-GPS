package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.command.CommandType;

/**
 * Ответ на "Сменить номер устройства".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SetDeviceNumberResponse extends AbstractCommonResponse {

    public SetDeviceNumberResponse() {
        this(CommandType.SET_DEVICE_NUMBER);
    }

    private SetDeviceNumberResponse(CommandType commandType) {
        super(commandType);
    }


}
