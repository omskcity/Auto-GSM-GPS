package com.navi.core.navisetGT20.command.request;

import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.utils.ByteArrayWriter;
import com.navi.core.navisetGT20.command.RequestMessage;

/**
 * Запрос устройству "".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SetConfigRequest extends RequestMessage {

    private Integer config;
    private Integer size;
    private Byte [] data;

    public SetConfigRequest() {
        super(CommandType.SET_CONFIG);
    }

    @Override
    protected void writeData(final ByteArrayWriter writer) {
        writer.setInteger(1, config);
        writer.setInteger(2, size);
        writer.setBytes(512, data);
    }
}
