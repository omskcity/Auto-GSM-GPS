package com.navi.core.navisetGT20.command;

import com.navi.core.navisetGT20.ToDeviceMessage;
import com.navi.core.navisetGT20.utils.ByteArrayWriter;

import java.io.Serializable;

/**
 * Запрос к устройству, в описании протокола это команда.
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public abstract class RequestMessage extends ToDeviceMessage implements Serializable {

    private static final int REQUEST_FLAG = 0x02;
    private CommandType commandType;


    protected RequestMessage(CommandType commandType) {
        this.commandType = commandType;
    }

    public CommandType getCommandType() {
        return commandType;
    }

    protected abstract void writeData(ByteArrayWriter writer);

    public byte[] getBytes() {
        ByteArrayWriter writer = new ByteArrayWriter();
        writer.setInteger(1, REQUEST_FLAG);
        writer.setInteger(1, commandType.getCommandID());
        writeData(writer);
        return writer.getBytes();
    }

    @Override
    public String toString() {
        return "RequestMessage{" +
                "commandType=" + commandType +
                '}';
    }
}
