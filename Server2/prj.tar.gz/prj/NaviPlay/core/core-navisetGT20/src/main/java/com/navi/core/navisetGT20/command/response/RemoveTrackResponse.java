package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.command.CommandType;

/**
 * Ответ на "Удалить трек из памяти устройства".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class RemoveTrackResponse extends AbstractCommonResponse {

    public RemoveTrackResponse() {
        this(CommandType.REMOVE_TRACK);
    }

    private RemoveTrackResponse(CommandType commandType) {
        super(commandType);
    }

}
