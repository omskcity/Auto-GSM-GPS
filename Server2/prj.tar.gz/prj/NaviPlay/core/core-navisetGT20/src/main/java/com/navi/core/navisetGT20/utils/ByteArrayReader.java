package com.navi.core.navisetGT20.utils;

import java.util.Arrays;

public class ByteArrayReader {

    private byte [] bytes;

    private int position = 0;

    public ByteArrayReader(byte[] bytes) {
        this.bytes = bytes;
    }

    public byte [] getBytes (int len) {
        int lenght = len;
        if (position + lenght > bytes.length) {
            lenght = bytes.length - position;
        }
        byte [] tbytes = new byte [lenght];
        if (lenght > 0) {
            tbytes = Arrays.copyOfRange(bytes, position, position + lenght);
            position+=lenght;
        }
        return tbytes;
    }


    public int getInteger (int len) {
        byte [] bytes = getBytes(len);
        return ByteUtils.getUnsignShortValue(bytes);
    }

    public long getLong (int len) {
        byte [] bytes = getBytes(len);
        return ByteUtils.getUnsignIntValue(bytes);
    }

    public String getString (int len) {
        byte [] bytes = getBytes(len);
        return ByteUtils.getStringValue(bytes);
    }

    public boolean[] getBooleanArray (int len) {
        byte [] bytes = getBytes(len);
        return ByteUtils.bytes2bits(bytes);
    }

}
