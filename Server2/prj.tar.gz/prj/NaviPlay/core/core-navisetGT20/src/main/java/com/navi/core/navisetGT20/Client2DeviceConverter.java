package com.navi.core.navisetGT20;

import com.navi.core.client.messages.FromClientMessage;
import com.navi.core.client.messages.toDevice.AlarmOnRequest;
import com.navi.core.client.messages.GetActiveDevices;
import com.navi.core.client.messages.toDevice.AlarmOffRequest;
import com.navi.core.client.messages.toDevice.StartEngineRequest;
import com.navi.core.navisetGT20.command.request.SetAlarmRequest;
import com.navi.core.navisetGT20.command.request.SetOutputParamRequest;

public class Client2DeviceConverter {
    public ToConnectorMessage convert(FromClientMessage from) {
        if (from instanceof AlarmOffRequest) {
            SetAlarmRequest request = new SetAlarmRequest();
            request.setDeviceNum(((AlarmOffRequest)from).getDeviceNum());
            request.setActive(0);
            return request;
        } else if (from instanceof AlarmOnRequest) {
            SetAlarmRequest request = new SetAlarmRequest();
            request.setDeviceNum(((AlarmOnRequest)from).getDeviceNum());
            request.setActive(1);
            return request;
        } else if (from instanceof StartEngineRequest) {
            SetOutputParamRequest request = new SetOutputParamRequest();
            request.setDeviceNum(((StartEngineRequest)from).getDeviceNum());
            request.setMode(OutModeType.ON);
            request.setOut(0);
            request.setRepeatCount(1);
            request.setImpulseTime(1);
            request.setPauseTime(5);
            return request;
        } else if (from instanceof GetActiveDevices ) {
            return new GetSocketListRequest();
        }
        return null;
    }
}
