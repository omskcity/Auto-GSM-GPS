package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.FromDeviceMessage;
import com.navi.core.navisetGT20.MessageType;
import com.navi.core.navisetGT20.utils.Converter;
import org.junit.Assert;
import org.junit.Test;

import java.io.InputStream;


public class GetStatusResponseTest  {
    @Test
    public void testParse() throws Exception {

        InputStream stream;
        stream = GetStatusResponseTest.class.getClassLoader()
            .getResourceAsStream("GetStatusResponse.bin");

        byte [] bytes = new byte[20];
        stream.read(bytes);
        stream.close();
        FromDeviceMessage m = Converter.bytes2deviceMessage(MessageType.RESPONSE_SERVICE, bytes);
        Assert.assertTrue(m instanceof GetStatusResponse);
        GetStatusResponse statusResponse = (GetStatusResponse) m;
        Assert.assertEquals(Integer.valueOf(1),  statusResponse.getDeviceNumber());
        Assert.assertEquals(Integer.valueOf(1),  statusResponse.getFirmware());
        Assert.assertEquals(Integer.valueOf(1),  statusResponse.getProtocolType());
        Assert.assertTrue(!statusResponse.getLowVoltage());
        Assert.assertTrue(!statusResponse.getMove());
        Assert.assertTrue(!statusResponse.getAlarm());
        Assert.assertTrue(statusResponse.getActiveGSM1());
        Assert.assertTrue(!statusResponse.getActiveGSM2());
        Assert.assertTrue(!statusResponse.getProblemGPRS());
        Assert.assertTrue(!statusResponse.getProblemGPS());
        Assert.assertEquals(Integer.valueOf(14200), statusResponse.getExternalVoltage());
        Assert.assertEquals(Integer.valueOf(26), statusResponse.getTemp());
        Assert.assertEquals(Integer.valueOf(24),  statusResponse.getLevelGSM());

    }

}
