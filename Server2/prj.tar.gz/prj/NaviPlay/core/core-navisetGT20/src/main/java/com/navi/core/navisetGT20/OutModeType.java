package com.navi.core.navisetGT20;


public enum OutModeType {
    OFF(new boolean []{false, false, false, false}),
    ON(new boolean []{true, false, false, false}),
    PULSE(new boolean []{false, true, false, false});

    private boolean [] value;

    private OutModeType(final boolean[] value) {
        this.value = value;
    }

    public boolean[] getValue() {
        return value;
    }
}
