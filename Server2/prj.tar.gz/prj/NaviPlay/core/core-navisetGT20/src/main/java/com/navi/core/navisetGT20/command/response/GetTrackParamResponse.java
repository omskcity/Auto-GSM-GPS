package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.utils.ByteArrayReader;
import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.command.ResponseMessage;

/**
 * Ответ на "Запрос параметров трека".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class GetTrackParamResponse extends ResponseMessage {
    private Integer filter;
    private Integer accelerationSensitivity;
    private Integer timeToStay;
    private Integer periodInStay;
    private Integer periodInMove;
    private Integer distance;
    private Integer cornerDrawing;
    private Integer minSpeed;
    private Integer maxSpeed;
    private Integer acceleration;
    private Integer leap;
    private Integer downtime;

    public GetTrackParamResponse() {
        this(CommandType.GET_TRACK_PARAM);
    }

    private GetTrackParamResponse(CommandType commandType) {
        super(commandType);
    }

    public Integer getFilter() {
        return filter;
    }

    public void setFilter(final Integer filter) {
        this.filter = filter;
    }

    public Integer getAccelerationSensitivity() {
        return accelerationSensitivity;
    }

    public void setAccelerationSensitivity(final Integer accelerationSensitivity) {
        this.accelerationSensitivity = accelerationSensitivity;
    }

    public Integer getTimeToStay() {
        return timeToStay;
    }

    public void setTimeToStay(final Integer timeToStay) {
        this.timeToStay = timeToStay;
    }

    public Integer getPeriodInStay() {
        return periodInStay;
    }

    public void setPeriodInStay(final Integer periodInStay) {
        this.periodInStay = periodInStay;
    }

    public Integer getPeriodInMove() {
        return periodInMove;
    }

    public void setPeriodInMove(final Integer periodInMove) {
        this.periodInMove = periodInMove;
    }

    public Integer getDistance() {
        return distance;
    }

    public void setDistance(final Integer distance) {
        this.distance = distance;
    }

    public Integer getCornerDrawing() {
        return cornerDrawing;
    }

    public void setCornerDrawing(final Integer cornerDrawing) {
        this.cornerDrawing = cornerDrawing;
    }

    public Integer getMinSpeed() {
        return minSpeed;
    }

    public void setMinSpeed(final Integer minSpeed) {
        this.minSpeed = minSpeed;
    }

    public Integer getMaxSpeed() {
        return maxSpeed;
    }

    public void setMaxSpeed(final Integer maxSpeed) {
        this.maxSpeed = maxSpeed;
    }

    public Integer getAcceleration() {
        return acceleration;
    }

    public void setAcceleration(final Integer acceleration) {
        this.acceleration = acceleration;
    }

    public Integer getLeap() {
        return leap;
    }

    public void setLeap(final Integer leap) {
        this.leap = leap;
    }

    public Integer getDowntime() {
        return downtime;
    }

    public void setDowntime(final Integer downtime) {
        this.downtime = downtime;
    }

    @Override
    public void readData(final ByteArrayReader reader) {
        setFilter(reader.getInteger(1));
        setAccelerationSensitivity(reader.getInteger(2));
        setTimeToStay(reader.getInteger(2));
        setPeriodInStay(reader.getInteger(2));
        setPeriodInMove(reader.getInteger(2));
        setDistance(reader.getInteger(1));
        setCornerDrawing(reader.getInteger(1));
        setMinSpeed(reader.getInteger(1));
        setMaxSpeed(reader.getInteger(1));
        setAcceleration(reader.getInteger(1));
        setLeap(reader.getInteger(1));
        setDowntime(reader.getInteger(1));
    }

    @Override
    public String toString() {
        return "GetTrackParamResponse{" +
                "filter=" + filter +
                ", accelerationSensitivity=" + accelerationSensitivity +
                ", timeToStay=" + timeToStay +
                ", periodInStay=" + periodInStay +
                ", periodInMove=" + periodInMove +
                ", distance=" + distance +
                ", cornerDrawing=" + cornerDrawing +
                ", minSpeed=" + minSpeed +
                ", maxSpeed=" + maxSpeed +
                ", acceleration=" + acceleration +
                ", leap=" + leap +
                ", downtime=" + downtime +
                '}';
    }
}
