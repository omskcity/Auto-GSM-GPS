package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.FromDeviceMessage;
import com.navi.core.navisetGT20.MessageType;
import com.navi.core.navisetGT20.utils.Converter;
import org.junit.Assert;
import org.junit.Test;

import java.io.InputStream;


public class GetCamImageResponseTest {
    @Test
    public void testParse() throws Exception {

        InputStream stream;
        stream = GetCamImageResponseTest.class.getClassLoader()
            .getResourceAsStream("GetCamImageResponse.bin");

        byte [] bytes = new byte[20];
        stream.read(bytes);
        stream.close();
        FromDeviceMessage m = Converter.bytes2deviceMessage(MessageType.RESPONSE_SERVICE, bytes);
        Assert.assertTrue(m instanceof GetCamImageResponse);
        GetCamImageResponse response = (GetCamImageResponse) m;
        Assert.assertEquals(Integer.valueOf(0),  response.getResponse());
        Assert.assertEquals(Long.valueOf(7864),  response.getImageSize());

    }

}
