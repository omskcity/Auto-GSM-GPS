package com.navi.core.navisetGT20.utils;

import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class ByteArrayWriter {

    final Logger log = Logger.getLogger(ByteArrayWriter.class);
    private List<Byte> byteList = new ArrayList<Byte>();


    public void setBytes (int len, Byte [] val) {
        int length = len;
        if (val.length > len) {
            length = len;
        }
        byteList.addAll(Arrays.asList(val));
        for (int o = length; o < len; o++ ) {
            byteList.add((byte)0);
        }
    }

    public void setBytes (int len, byte [] val) {
        Byte [] bytes =  new Byte[val.length];
        System.arraycopy(val, 0, bytes, 0, val.length);
        setBytes(len, bytes);
    }


    public void setInteger (int len, Integer val) {
        if (val == null) {
            log.error("NULL in data");
        }
        boolean [] b = ByteUtils.int2bits(len, val);
        byte [] bytes = ByteUtils.bits2bytes(len, b);
        for (byte b1: bytes) {
            byteList.add(b1);
        }
    }

    public void setLong (int len, Long val) {
        if (val == null) {
            log.error("NULL in data");
        }
        boolean [] b = ByteUtils.long2bits(len, val);
        byte [] bytes = ByteUtils.bits2bytes(len, b);
        for (byte b1: bytes) {
            byteList.add(b1);
        }
    }

    public void setString (int len, String val) {
        if (val == null) {
            log.error("NULL in data");
        }
        byte [] bytes = val.getBytes();
        setBytes(len, bytes);
    }

    public void setBooleanArray (int len, boolean[] val) {
        int length = val.length;
        if (val.length > len * Byte.SIZE) {
            length = len * Byte.SIZE;
        }

        boolean [] b = new boolean[len * Byte.SIZE];
        System.arraycopy(val, 0, b, 0, length);
        for (int o = length; o < len * Byte.SIZE; o++ ) {
            b[o] = false;
        }
        byte [] bytes = ByteUtils.bits2bytes(len, b);
        for (byte b1: bytes) {
            byteList.add(b1);
        }
    }

    public byte[] getBytes() {
        byte [] bytes = new byte[byteList.size()];
        for (int i=0; i < byteList.size(); i++) {
            bytes[i] = byteList.get(i);
        }
        return bytes;
    }
}
