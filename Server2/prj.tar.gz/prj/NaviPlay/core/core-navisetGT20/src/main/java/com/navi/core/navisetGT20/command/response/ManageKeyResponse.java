package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.command.CommandType;

/**
 * Ответ на "Добавить/удалить номер ключа".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class ManageKeyResponse extends AbstractCommonResponse {

    public ManageKeyResponse() {
        this(CommandType.MANAGE_KEY);
    }

    private ManageKeyResponse(CommandType commandType) {
        super(commandType);
    }


}
