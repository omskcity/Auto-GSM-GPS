package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.command.CommandType;

/**
 * Ответ на "Временные параметры охраны".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SetAlarmTimeResponse extends AbstractCommonResponse {

    public SetAlarmTimeResponse() {
        this(CommandType.SET_ALARM_TIME);
    }

    private SetAlarmTimeResponse(CommandType commandType) {
        super(commandType);
    }


}
