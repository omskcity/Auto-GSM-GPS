package com.navi.core.navisetGT20;

import java.io.Serializable;

/**
 * Предок всех сообщений от устройства.
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public abstract class FromDeviceMessage implements Serializable {

    private MessageType messageType;

    private Integer deviceNumber;

    public MessageType getMessageType() {
        return messageType;
    }

    public FromDeviceMessage(MessageType messageType) {
        this.messageType = messageType;
    }

    public Integer getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(Integer deviceNumber) {
        this.deviceNumber = deviceNumber;
    }
}
