package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.command.CommandType;

/**
 * Ответ на "Управление выходами".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SetOutputParamResponse extends AbstractCommonResponse {

    public SetOutputParamResponse() {
        this(CommandType.SET_OUTPUT_PARAM);
    }

    private SetOutputParamResponse(CommandType commandType) {
        super(commandType);
    }

}
