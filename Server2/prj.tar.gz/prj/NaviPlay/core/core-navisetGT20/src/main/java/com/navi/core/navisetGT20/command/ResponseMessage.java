package com.navi.core.navisetGT20.command;

import com.navi.core.navisetGT20.utils.ByteArrayReader;
import com.navi.core.navisetGT20.FromDeviceMessage;
import com.navi.core.navisetGT20.MessageType;

/**
 * Предок всех ответов устройства на запросы.
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public abstract class ResponseMessage extends FromDeviceMessage {

    private CommandType commandType;

    protected ResponseMessage(CommandType commandType) {
        super(MessageType.RESPONSE_SERVICE);
        this.commandType = commandType;
    }

    public abstract void readData(ByteArrayReader reader);

    public CommandType getCommandType() {
        return commandType;
    }
}
