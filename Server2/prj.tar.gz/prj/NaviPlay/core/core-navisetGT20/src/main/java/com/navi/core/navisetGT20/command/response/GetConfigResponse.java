package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.utils.ByteArrayReader;
import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.command.ResponseMessage;

/**
 * Ответ на "Считать конфигурацию".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class GetConfigResponse extends ResponseMessage {

    public GetConfigResponse() {
        this(CommandType.GET_CONFIG);
    }

    private GetConfigResponse(CommandType commandType) {
        super(commandType);
    }

    private Integer config;
    private Integer size;
    private byte [] data;

    public Integer getConfig() {
        return config;
    }

    public void setConfig(final Integer config) {
        this.config = config;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(final Integer size) {
        this.size = size;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(final byte[] data) {
        this.data = data;
    }

    @Override
    public void readData(final ByteArrayReader reader) {
        setConfig(reader.getInteger(1));
        setSize(reader.getInteger(2));
        setData(reader.getBytes(512));

    }

    @Override
    public String toString() {
        return "GetConfigResponse{" +
                "config=" + config +
                ", size=" + size +
                ", data=" + data +
                '}';
    }
}
