package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.command.CommandType;

/**
 * Ответ на "Тип протокола и структура пакета".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SetProtocolResponse extends AbstractCommonResponse {

    public SetProtocolResponse() {
        this(CommandType.SET_PROTOCOL);
    }

    private SetProtocolResponse(CommandType commandType) {
        super(commandType);
    }
}
