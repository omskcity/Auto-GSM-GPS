package com.navi.core.navisetGT20;

import java.util.EnumSet;
import com.navi.core.client.AlarmType;

public enum AlarmSourceType {
    INPUT0(0, null),
    INPUT1(1, null),
    INPUT2(2, null),
    INPUT3(3, null),
    INPUT4(4, null),
    INPUT5(5, null),
    INPUT6(6, null),
    INPUT7(7, null),
    ALARM_ON(8, null),
    ALARM_OFF(9, null),
    LOW_EXTERNAL_VOLTAGE(10, AlarmType.LOW_EXTERNAL_VOLTAGE),
    MOVE_SENSOR(11, AlarmType.MOVE_SENSOR);

    private int sourceCode;

    private AlarmType alarmType;

    AlarmSourceType(int sourceCode, final AlarmType alarmType) {
        this.sourceCode = sourceCode;
        this.alarmType = alarmType;
    }

    public int getSourceCode() {
        return sourceCode;
    }

    public AlarmType getAlarmType() {
        return alarmType;
    }

    public static AlarmSourceType valueByCode(int value) {
        AlarmSourceType returnValue = null;
        for (final AlarmSourceType element : EnumSet.allOf(AlarmSourceType.class)) {
            if ( element.getSourceCode() == value) {
                returnValue = element;
            }
        }
        return returnValue;
    }

}
