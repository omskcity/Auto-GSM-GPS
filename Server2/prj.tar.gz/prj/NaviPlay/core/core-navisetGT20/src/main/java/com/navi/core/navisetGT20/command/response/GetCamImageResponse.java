package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.utils.ByteArrayReader;
import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.command.ResponseMessage;

/**
 * Ответ на Запрос изображения с камеры.
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class GetCamImageResponse extends ResponseMessage {

    private Integer response;
    private Integer dataSize;
    private Long imageSize;
    private Integer packageNumber;
    private byte [] data;
    private boolean camActive = true;
    private boolean camBusy = false;

    public GetCamImageResponse() {
        this(CommandType.GET_CAM_IMAGE);
    }

    private GetCamImageResponse(CommandType commandType) {
        super(commandType);
    }

    public Integer getResponse() {
        return response;
    }

    public void setResponse(final Integer response) {
        this.response = response;
    }


    public byte[] getData() {
        return data;
    }

    public void setData(final byte[] data) {
        this.data = data;
    }

    public Integer getDataSize() {
        return dataSize;
    }

    public void setDataSize(Integer dataSize) {
        this.dataSize = dataSize;
    }

    public Long getImageSize() {
        return imageSize;
    }

    public void setImageSize(Long imageSize) {
        this.imageSize = imageSize;
    }

    public Integer getPackageNumber() {
        return packageNumber;
    }

    public void setPackageNumber(final Integer packageNumber) {
        this.packageNumber = packageNumber;
    }

    public boolean isCamActive() {
        return camActive;
    }

    public void setCamActive(final boolean camActive) {
        this.camActive = camActive;
    }

    public boolean isCamBusy() {
        return camBusy;
    }

    public void setCamBusy(boolean camBusy) {
        this.camBusy = camBusy;
    }

    @Override
    public void readData(final ByteArrayReader reader) {
        setResponse(reader.getInteger(1));
        if (response == 0) {
            setImageSize(reader.getLong(3));
        } else if (response == 1) {
            setPackageNumber(reader.getInteger(1));
            setDataSize(reader.getInteger(2));
            setData(reader.getBytes(dataSize));
        } else if (response == 2) {
            setCamActive(false);
        } else {
            setCamBusy(true);
        }

    }

    @Override
    public String toString() {
        return "GetCamImageResponse{" +
                "response=" + response +
                ", dataSize=" + dataSize +
                ", imageSize=" + imageSize +
                ", packageNumber=" + packageNumber +
                ", data=" + data +
                ", camActive=" + camActive +
                ", camBusy=" + camBusy +
                '}';
    }
}
