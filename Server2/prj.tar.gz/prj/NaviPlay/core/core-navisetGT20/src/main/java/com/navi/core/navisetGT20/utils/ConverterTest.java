package com.navi.core.navisetGT20.utils;

import com.navi.core.navisetGT20.DeviceDataMessage;
import com.navi.core.navisetGT20.FromDeviceMessage;
import com.navi.core.navisetGT20.HeaderMessage;
import com.navi.core.navisetGT20.MessageType;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created with IntelliJ IDEA.
 * User: basil
 * Date: 25.02.13
 * Time: 22:22
 * To change this template use File | Settings | File Templates.
 */
public class ConverterTest {

    private FromDeviceMessage loadData(String fileName) {
        FromDeviceMessage res = null;
        InputStream stream;
        stream = this.getClass().getClassLoader()
                .getResourceAsStream(fileName);
        String str = null;
        try {
            str = IOUtils.toString(stream, "UTF-8");
        } catch (IOException e) {
            Assert.fail(e.getMessage());
        }
        String stringType = null;
        String stringData = null;
        for (String s : StringUtils.split(str, '\n')) {
            String [] s2  = StringUtils.split(s, ":");
            if (s2.length > 0) {
                if ("type".equalsIgnoreCase(s2[0])) {
                    stringType = s2[1];
                } else if ("data".equalsIgnoreCase(s2[0])) {
                    stringData = s2[1];
                }
            }
        }
        MessageType mt = null;
        if (stringType.length()>0) {
            mt = MessageType.valueByCode(Integer.valueOf(stringType.trim()));

        }
        String [] strDatas = StringUtils.split(stringData, ' ');
        byte [] data = new byte[strDatas.length];
        int i = 0;
        for(String dataStr: strDatas){
            int i1 = Integer.decode("0x"+ dataStr.trim());
            boolean [] b = ByteUtils.int2bits(1, i1);
            byte b1 = ByteUtils.bits2byte(b);
            data[i] = b1;
            i++;

        }
        res = Converter.bytes2deviceMessage(mt, data);
        System.out.println(res);
        return res;
    }

    @Test
    public void testrequest_2013223221468506300277() throws Exception {

        FromDeviceMessage deviceMessage = loadData("request_2013223221468506300277.log");
        Assert.assertTrue(deviceMessage instanceof HeaderMessage);
        //Assert.assertArrayEquals(bytes2, bytes);

    }
    @Test
    public void testrequest_2013223221498509178189() throws Exception {

        FromDeviceMessage deviceMessage = loadData("request_2013223221498509178189.log");
        Assert.assertTrue(deviceMessage instanceof HeaderMessage);
        //Assert.assertArrayEquals(bytes2, bytes);

    }

    @Test
    public void testrequest_2013223221488508781249() throws Exception {

        FromDeviceMessage deviceMessage = loadData("request_2013223221488508781249.log");
        Assert.assertTrue(deviceMessage instanceof DeviceDataMessage);
        //Assert.assertArrayEquals(bytes2, bytes);

    }

    @Test
    public void testrequest_2013223221508510527477() throws Exception {

        FromDeviceMessage deviceMessage = loadData("request_2013223221508510527477.log");
        Assert.assertTrue(deviceMessage instanceof DeviceDataMessage);
        //Assert.assertArrayEquals(bytes2, bytes);

    }

    @Test
    public void testrequest_201322514435253032358434() throws Exception {

        FromDeviceMessage deviceMessage = loadData("request_201322514435253032358434.log");
        Assert.assertTrue(deviceMessage instanceof DeviceDataMessage);
        //Assert.assertArrayEquals(bytes2, bytes);

    }

    @Test
    public void testrequest_2013225159954549393354() throws Exception {

        FromDeviceMessage deviceMessage = loadData("request_2013225159954549393354.log");

        Assert.assertTrue(deviceMessage instanceof DeviceDataMessage);
        //Assert.assertArrayEquals(bytes2, bytes);

    }

}
