package com.navi.core.navisetGT20.command;

import com.navi.core.navisetGT20.utils.ByteArrayReader;
import com.navi.core.navisetGT20.command.response.*;
import com.navi.core.navisetGT20.command.response.SetDeviceSMSPasswordResponse;

import java.util.EnumSet;


public enum CommandType {


    GET_STATUS (0) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            GetStatusResponse response = new GetStatusResponse();
            response.readData(reader);
            return response;
        }
    },
    GET_IMEI (1) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            GetIMEIResponse response = new GetIMEIResponse();
            response.readData(reader);
            return response;
        }
    },
    SET_DEVICE_NUMBER (2) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            AbstractCommonResponse response = new SetDeviceNumberResponse();
            response.readData(reader);
            return response;
        }
    },
    SET_DEVICE_SMS_PASSWORD (3) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            AbstractCommonResponse response = new SetDeviceSMSPasswordResponse();
            response.readData(reader);
            return response;
        }
    },

    SET_GPRS_SETTINGS (4) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            AbstractCommonResponse response = new SetGPRSSettingsResponse();
            response.readData(reader);
            return response;
        }
    },
    GET_KEYS (5) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            GetKeysResponse response = new GetKeysResponse();
            response.readData(reader);
            return response;
        }
    },
    MANAGE_KEY (6) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            ManageKeyResponse response = new ManageKeyResponse();
            response.readData(reader);
            return response;
        }
    },
    GET_PHONES (7) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            GetPhonesResponse response = new GetPhonesResponse();
            response.readData(reader);
            return response;
        }
    },
    MANAGE_PHONE (8) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            ManagePhoneResponse response = new ManagePhoneResponse();
            response.readData(reader);
            return response;
        }
    },
    SET_PROTOCOL (9) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            SetProtocolResponse response = new SetProtocolResponse();
            response.readData(reader);
            return response;
        }
    },
    GET_TRACK_PARAM (10) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            GetTrackParamResponse response = new GetTrackParamResponse();
            response.readData(reader);
            return response;
        }
    },
    SET_TRACK_PARAM (11) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            SetTrackParamResponse response = new SetTrackParamResponse();
            response.readData(reader);
            return response;
        }
    },
    SET_INPUTS_PARAM (12) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            SetInputsParamResponse response = new SetInputsParamResponse();
            response.readData(reader);
            return response;
        }
    },
    SET_OUTPUT_PARAM (13) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            SetOutputParamResponse response = new SetOutputParamResponse();
            response.readData(reader);
            return response;
        }
    },
    SET_ALARM (14) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            SetAlarmResponse response = new SetAlarmResponse();
            response.readData(reader);
            return response;
        }
    },
    SET_ALARM_TIME (15) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            SetAlarmTimeResponse response = new SetAlarmTimeResponse();
            response.readData(reader);
            return response;
        }
    },
    REMOVE_TRACK (16) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            RemoveTrackResponse response = new RemoveTrackResponse();
            response.readData(reader);
            return response;
        }
    },
    SET_VOICE_PARAM (17) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            SetVoiceParamResponse  response = new SetVoiceParamResponse();
            response.readData(reader);
            return response;
        }
    },
    RESTART (18) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            RestartResponse response = new RestartResponse();
            response.readData(reader);
            return response;
        }
    },
    UPDATE_FIRMWARE (19) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            UpdateFirmwareResponse response = new UpdateFirmwareResponse();
            response.readData(reader);
            return response;
        }
    },
    GET_CAM_IMAGE (20) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            GetCamImageResponse response = new GetCamImageResponse();
            response.readData(reader);
            return response;
        }
    },
    GET_CONFIG (21) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            GetConfigResponse response = new GetConfigResponse();
            response.readData(reader);
            return response;
        }
    },
    SET_CONFIG (22) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            SetConfigResponse response = new SetConfigResponse();
            response.readData(reader);
            return response;
        }
    },
    SET_SIM_CARD (23) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            SetSimCardResponse response = new SetSimCardResponse();
            response.readData(reader);
            return response;
        }
    },
    SWITCH_DEVICE_TO_CONF_SERVER (24) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            SwitchDeviceToConfigServerResponse response = new SwitchDeviceToConfigServerResponse();
            response.readData(reader);
            return response;
        }
    },
    SET_SIM_AUTOSWITCH (25) {
        public ResponseMessage createResponse(ByteArrayReader reader) {
            SetSIMAutoSwitchResponse response = new SetSIMAutoSwitchResponse();
            response.readData(reader);
            return response;
        }
    };

    private int commandID;

     CommandType(final int commandID) {
         this.commandID = commandID;
    }


    public int getCommandID() {
        return commandID;
    }

    public static CommandType valueByCode(int value) {
        CommandType returnValue = null;
        for (final CommandType element : EnumSet.allOf(CommandType.class)) {
            if ( element.getCommandID() == value) {
                returnValue = element;
            }
        }
        return returnValue;
    }

    public abstract ResponseMessage createResponse(ByteArrayReader reader);

}
