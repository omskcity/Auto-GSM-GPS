package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.utils.ByteArrayReader;
import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.command.ResponseMessage;

/**
 * Ответ на "Запрос IMEI номера GSM модуля".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class GetIMEIResponse extends ResponseMessage {

    private String imei;

    public GetIMEIResponse() {
        this(CommandType.GET_IMEI);
    }

    private GetIMEIResponse(CommandType commandType) {
        super(commandType);
    }


    public String getImei() {
        return imei;
    }

    public void setImei(final String imei) {
        this.imei = imei;
    }


    @Override
    public void readData(final ByteArrayReader reader) {
        setImei(reader.getString(15));
    }

    @Override
    public String toString() {
        return "GetIMEIResponse{" +
                "imei='" + imei + '\'' +
                '}';
    }
}
