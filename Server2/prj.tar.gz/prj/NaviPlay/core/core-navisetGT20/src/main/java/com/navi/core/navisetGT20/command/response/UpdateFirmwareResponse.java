package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.command.CommandType;

/**
 * Ответ на "Обновление версии ПО".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class UpdateFirmwareResponse extends AbstractCommonResponse {

    public UpdateFirmwareResponse() {
        this(CommandType.UPDATE_FIRMWARE);
    }

    private UpdateFirmwareResponse(CommandType commandType) {
        super(commandType);
    }

}
