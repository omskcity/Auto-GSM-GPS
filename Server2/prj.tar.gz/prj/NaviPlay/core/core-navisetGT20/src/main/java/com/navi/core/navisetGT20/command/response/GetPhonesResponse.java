package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.utils.ByteArrayReader;
import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.command.ResponseMessage;

/**
 * ответ на "Получить список номеров телефонов".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class GetPhonesResponse extends ResponseMessage {

    private String number1;
    private Integer call1;
    private String number2;
    private Integer call2;
    private String number3;
    private Integer call3;
    private String number4;
    private Integer call4;
    private String number5;
    private Integer call5;
    private String number6;
    private Integer call6;

    public GetPhonesResponse() {
        this(CommandType.GET_PHONES);
    }

    private GetPhonesResponse(CommandType commandType) {
        super(commandType);
    }

    public String getNumber1() {
        return number1;
    }

    public void setNumber1(final String number1) {
        this.number1 = number1;
    }

    public Integer getCall1() {
        return call1;
    }

    public void setCall1(final Integer call1) {
        this.call1 = call1;
    }

    public String getNumber2() {
        return number2;
    }

    public void setNumber2(final String number2) {
        this.number2 = number2;
    }

    public Integer getCall2() {
        return call2;
    }

    public void setCall2(final Integer call2) {
        this.call2 = call2;
    }

    public String getNumber3() {
        return number3;
    }

    public void setNumber3(final String number3) {
        this.number3 = number3;
    }

    public Integer getCall3() {
        return call3;
    }

    public void setCall3(final Integer call3) {
        this.call3 = call3;
    }

    public String getNumber4() {
        return number4;
    }

    public void setNumber4(final String number4) {
        this.number4 = number4;
    }

    public Integer getCall4() {
        return call4;
    }

    public void setCall4(final Integer call4) {
        this.call4 = call4;
    }

    public String getNumber5() {
        return number5;
    }

    public void setNumber5(final String number5) {
        this.number5 = number5;
    }

    public Integer getCall5() {
        return call5;
    }

    public void setCall5(final Integer call5) {
        this.call5 = call5;
    }

    public String getNumber6() {
        return number6;
    }

    public void setNumber6(final String number6) {
        this.number6 = number6;
    }

    public Integer getCall6() {
        return call6;
    }

    public void setCall6(final Integer call6) {
        this.call6 = call6;
    }

    @Override
    public void readData(final ByteArrayReader reader) {
        setNumber1(reader.getString(10));
        setCall1(reader.getInteger(1));
        setNumber2(reader.getString(10));
        setCall2(reader.getInteger(1));
        setNumber3(reader.getString(10));
        setCall3(reader.getInteger(1));
        setNumber4(reader.getString(10));
        setCall4(reader.getInteger(1));
        setNumber5(reader.getString(10));
        setCall5(reader.getInteger(1));
        setNumber6(reader.getString(10));
        setCall6(reader.getInteger(1));
    }

    @Override
    public String toString() {
        return "GetPhonesResponse{" +
                "number1='" + number1 + '\'' +
                ", call1=" + call1 +
                ", number2='" + number2 + '\'' +
                ", call2=" + call2 +
                ", number3='" + number3 + '\'' +
                ", call3=" + call3 +
                ", number4='" + number4 + '\'' +
                ", call4=" + call4 +
                ", number5='" + number5 + '\'' +
                ", call5=" + call5 +
                ", number6='" + number6 + '\'' +
                ", call6=" + call6 +
                '}';
    }
}
