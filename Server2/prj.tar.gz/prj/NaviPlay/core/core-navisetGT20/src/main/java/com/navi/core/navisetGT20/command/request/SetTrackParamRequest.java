package com.navi.core.navisetGT20.command.request;

import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.utils.ByteArrayWriter;
import com.navi.core.navisetGT20.command.RequestMessage;

/**
 * Запрос устройству "".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SetTrackParamRequest extends RequestMessage {
    private Integer filter;
    private Integer accelerationSensitivity;
    private Integer timeToStay;
    private Integer periodInStay;
    private Integer periodInMove;
    private Integer distance;
    private Integer cornerDrawing;
    private Integer minSpeed;
    private Integer maxSpeed;
    private Integer acceleration;
    private Integer leap;
    private Integer downtime;

    public SetTrackParamRequest() {
        super(CommandType.SET_TRACK_PARAM);
    }

    public Integer getFilter() {
        return filter;
    }

    public void setFilter(final Integer filter) {
        this.filter = filter;
    }

    public Integer getAccelerationSensitivity() {
        return accelerationSensitivity;
    }

    public void setAccelerationSensitivity(final Integer accelerationSensitivity) {
        this.accelerationSensitivity = accelerationSensitivity;
    }

    public Integer getTimeToStay() {
        return timeToStay;
    }

    public void setTimeToStay(final Integer timeToStay) {
        this.timeToStay = timeToStay;
    }

    public Integer getPeriodInStay() {
        return periodInStay;
    }

    public void setPeriodInStay(final Integer periodInStay) {
        this.periodInStay = periodInStay;
    }

    public Integer getPeriodInMove() {
        return periodInMove;
    }

    public void setPeriodInMove(final Integer periodInMove) {
        this.periodInMove = periodInMove;
    }

    public Integer getDistance() {
        return distance;
    }

    public void setDistance(final Integer distance) {
        this.distance = distance;
    }

    public Integer getCornerDrawing() {
        return cornerDrawing;
    }

    public void setCornerDrawing(final Integer cornerDrawing) {
        this.cornerDrawing = cornerDrawing;
    }

    public Integer getMinSpeed() {
        return minSpeed;
    }

    public void setMinSpeed(final Integer minSpeed) {
        this.minSpeed = minSpeed;
    }

    public Integer getMaxSpeed() {
        return maxSpeed;
    }

    public void setMaxSpeed(final Integer maxSpeed) {
        this.maxSpeed = maxSpeed;
    }

    public Integer getAcceleration() {
        return acceleration;
    }

    public void setAcceleration(final Integer acceleration) {
        this.acceleration = acceleration;
    }

    public Integer getLeap() {
        return leap;
    }

    public void setLeap(final Integer leap) {
        this.leap = leap;
    }

    public Integer getDowntime() {
        return downtime;
    }

    public void setDowntime(final Integer downtime) {
        this.downtime = downtime;
    }

    @Override
    protected void writeData(final ByteArrayWriter writer) {
        writer.setInteger(1, filter);
        writer.setInteger(2, accelerationSensitivity);
        writer.setInteger(2, timeToStay);
        writer.setInteger(2, periodInStay);
        writer.setInteger(2, periodInMove);
        writer.setInteger(1, distance);
        writer.setInteger(1, cornerDrawing);
        writer.setInteger(1, minSpeed);
        writer.setInteger(1, maxSpeed);
        writer.setInteger(1, acceleration);
        writer.setInteger(1, leap);
        writer.setInteger(1, downtime);
    }
}
