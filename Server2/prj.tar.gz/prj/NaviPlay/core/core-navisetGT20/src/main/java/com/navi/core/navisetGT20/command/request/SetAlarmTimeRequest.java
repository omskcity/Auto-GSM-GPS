package com.navi.core.navisetGT20.command.request;

import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.utils.ByteArrayWriter;
import com.navi.core.navisetGT20.command.RequestMessage;

/**
 * Запрос устройству "".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SetAlarmTimeRequest extends RequestMessage {

    private Integer inTime;
    private Integer outTime;
    private Integer memoryTime;

    public SetAlarmTimeRequest() {
        super(CommandType.SET_ALARM_TIME);
    }
    public Integer getInTime() {
        return inTime;
    }

    public void setInTime(final Integer inTime) {
        this.inTime = inTime;
    }

    public Integer getOutTime() {
        return outTime;
    }

    public void setOutTime(final Integer outTime) {
        this.outTime = outTime;
    }

    public Integer getMemoryTime() {
        return memoryTime;
    }

    public void setMemoryTime(final Integer memoryTime) {
        this.memoryTime = memoryTime;
    }

    @Override
    protected void writeData(final ByteArrayWriter writer) {
        writer.setInteger(1, inTime);
        writer.setInteger(1, outTime);
        writer.setInteger(1, memoryTime);
    }
}
