package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.command.CommandType;

/**
 * Ответ на "Переключить прибор на сервер конфигурирования".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SwitchDeviceToConfigServerResponse extends AbstractCommonResponse {

    public SwitchDeviceToConfigServerResponse() {
        this(CommandType.SWITCH_DEVICE_TO_CONF_SERVER);
    }

    private SwitchDeviceToConfigServerResponse(CommandType commandType) {
        super(commandType);
    }

}
