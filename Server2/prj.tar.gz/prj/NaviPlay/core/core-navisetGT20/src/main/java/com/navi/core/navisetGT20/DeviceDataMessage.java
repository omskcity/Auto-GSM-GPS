package com.navi.core.navisetGT20;

import java.util.Arrays;
import java.util.Date;

/**
 * Структура пакета данных.
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class DeviceDataMessage extends FromDeviceMessage {

    public DeviceDataMessage() {
        super(MessageType.DATA);
    }

    private Integer packageNumber;

    private Date date;

    private Integer satellite;

    private Long longitude;

    private Long latitude;

    private Integer speed;

    private Integer direction;

    private Integer height;

    private Integer HDOP;

    private Boolean lowVoltage;
    private Boolean isMove;
    private Boolean isAlarm;
    private Boolean isActiveGSM1;
    private Boolean isActiveGSM2;
    private Boolean problemGPRS;
    private Boolean problemGPS;

    private Integer deviceVoltage;
    private Integer batteryVoltage;

    private Integer externalTemp;

    private Integer voltageInput1;
    private Integer voltageInput2;
    private Integer voltageInput3;
    private Integer voltageInput4;
    private Integer voltageInput5;
    private Integer voltageInput6;
    private Integer voltageInput7;
    private Integer voltageInput8;

    private Integer extTemp1;
    private Integer extTemp2;
    private Integer extTemp3;
    private Integer extTemp4;
    private Integer extTemp5;
    private Integer extTemp6;
    private Integer extTemp7;
    private Integer extTemp8;

    private byte [] keyCode;
    
    private Integer frequencyInput1;
    private Integer frequencyInput2;
    private Integer fuelOmniconn1;
    private Integer fuelOmniconn2;

    private Integer tempOmniconn1;
    private Integer tempOmniconn2;

    private Integer canFuel;
    private Integer canEngineRotation;
    private Integer canEngineTemp;
    private Integer canTotalFuel;
    private Integer canTotalMeters;

    public Integer getPackageNumber() {
        return packageNumber;
    }

    public void setPackageNumber(Integer packageNumber) {
        this.packageNumber = packageNumber;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Integer getSatellite() {
        return satellite;
    }

    public void setSatellite(Integer satellite) {
        this.satellite = satellite;
    }

    public Long getLongitude() {
        return longitude;
    }

    public void setLongitude(Long longitude) {
        this.longitude = longitude;
    }

    public Long getLatitude() {
        return latitude;
    }

    public void setLatitude(Long latitude) {
        this.latitude = latitude;
    }

    public Integer getSpeed() {
        return speed;
    }

    public void setSpeed(Integer speed) {
        this.speed = speed;
    }

    public Integer getDirection() {
        return direction;
    }

    public void setDirection(Integer direction) {
        this.direction = direction;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public Integer getHDOP() {
        return HDOP;
    }

    public void setHDOP(Integer HDOP) {
        this.HDOP = HDOP;
    }

    public Boolean getMove() {
        return isMove;
    }

    public void setMove(final Boolean move) {
        isMove = move;
    }

    public Boolean getAlarm() {
        return isAlarm;
    }

    public void setAlarm(final Boolean alarm) {
        isAlarm = alarm;
    }

    public Boolean getActiveGSM1() {
        return isActiveGSM1;
    }

    public void setActiveGSM1(final Boolean activeGSM1) {
        isActiveGSM1 = activeGSM1;
    }

    public Boolean getActiveGSM2() {
        return isActiveGSM2;
    }

    public void setActiveGSM2(final Boolean activeGSM2) {
        isActiveGSM2 = activeGSM2;
    }

    public Boolean getLowVoltage() {
        return lowVoltage;
    }

    public void setLowVoltage(final Boolean lowVoltage) {
        this.lowVoltage = lowVoltage;
    }

    public Boolean getProblemGPRS() {
        return problemGPRS;
    }

    public void setProblemGPRS(final Boolean problemGPRS) {
        this.problemGPRS = problemGPRS;
    }

    public Boolean getProblemGPS() {
        return problemGPS;
    }

    public void setProblemGPS(final Boolean problemGPS) {
        this.problemGPS = problemGPS;
    }

    public Integer getDeviceVoltage() {
        return deviceVoltage;
    }

    public void setDeviceVoltage(final Integer deviceVoltage) {
        this.deviceVoltage = deviceVoltage;
    }

    public Integer getBatteryVoltage() {
        return batteryVoltage;
    }

    public void setBatteryVoltage(final Integer batteryVoltage) {
        this.batteryVoltage = batteryVoltage;
    }

    public Integer getExternalTemp() {
        return externalTemp;
    }

    public void setExternalTemp(final Integer externalTemp) {
        this.externalTemp = externalTemp;
    }

    public Integer getVoltageInput1() {
        return voltageInput1;
    }

    public void setVoltageInput1(final Integer voltageInput1) {
        this.voltageInput1 = voltageInput1;
    }

    public Integer getVoltageInput2() {
        return voltageInput2;
    }

    public void setVoltageInput2(final Integer voltageInput2) {
        this.voltageInput2 = voltageInput2;
    }

    public Integer getVoltageInput3() {
        return voltageInput3;
    }

    public void setVoltageInput3(final Integer voltageInput3) {
        this.voltageInput3 = voltageInput3;
    }

    public Integer getVoltageInput4() {
        return voltageInput4;
    }

    public void setVoltageInput4(final Integer voltageInput4) {
        this.voltageInput4 = voltageInput4;
    }

    public Integer getVoltageInput5() {
        return voltageInput5;
    }

    public void setVoltageInput5(final Integer voltageInput5) {
        this.voltageInput5 = voltageInput5;
    }

    public Integer getVoltageInput6() {
        return voltageInput6;
    }

    public void setVoltageInput6(final Integer voltageInput6) {
        this.voltageInput6 = voltageInput6;
    }

    public Integer getVoltageInput7() {
        return voltageInput7;
    }

    public void setVoltageInput7(final Integer voltageInput7) {
        this.voltageInput7 = voltageInput7;
    }

    public Integer getVoltageInput8() {
        return voltageInput8;
    }

    public void setVoltageInput8(final Integer voltageInput8) {
        this.voltageInput8 = voltageInput8;
    }

    public Integer getExtTemp1() {
        return extTemp1;
    }

    public void setExtTemp1(final Integer extTemp1) {
        this.extTemp1 = extTemp1;
    }

    public Integer getExtTemp2() {
        return extTemp2;
    }

    public void setExtTemp2(final Integer extTemp2) {
        this.extTemp2 = extTemp2;
    }

    public Integer getExtTemp3() {
        return extTemp3;
    }

    public void setExtTemp3(final Integer extTemp3) {
        this.extTemp3 = extTemp3;
    }

    public Integer getExtTemp4() {
        return extTemp4;
    }

    public void setExtTemp4(final Integer extTemp4) {
        this.extTemp4 = extTemp4;
    }

    public Integer getExtTemp5() {
        return extTemp5;
    }

    public void setExtTemp5(final Integer extTemp5) {
        this.extTemp5 = extTemp5;
    }

    public Integer getExtTemp6() {
        return extTemp6;
    }

    public void setExtTemp6(final Integer extTemp6) {
        this.extTemp6 = extTemp6;
    }

    public Integer getExtTemp7() {
        return extTemp7;
    }

    public void setExtTemp7(final Integer extTemp7) {
        this.extTemp7 = extTemp7;
    }

    public Integer getExtTemp8() {
        return extTemp8;
    }

    public void setExtTemp8(final Integer extTemp8) {
        this.extTemp8 = extTemp8;
    }

    public byte[] getKeyCode() {
        return keyCode;
    }

    public void setKeyCode(final byte[] keyCode) {
        this.keyCode = keyCode;
    }

    public Integer getFrequencyInput1() {
        return frequencyInput1;
    }

    public void setFrequencyInput1(final Integer frequencyInput1) {
        this.frequencyInput1 = frequencyInput1;
    }

    public Integer getFrequencyInput2() {
        return frequencyInput2;
    }

    public void setFrequencyInput2(final Integer frequencyInput2) {
        this.frequencyInput2 = frequencyInput2;
    }

    public Integer getFuelOmniconn1() {
        return fuelOmniconn1;
    }

    public void setFuelOmniconn1(final Integer fuelOmniconn1) {
        this.fuelOmniconn1 = fuelOmniconn1;
    }

    public Integer getFuelOmniconn2() {
        return fuelOmniconn2;
    }

    public void setFuelOmniconn2(final Integer fuelOmniconn2) {
        this.fuelOmniconn2 = fuelOmniconn2;
    }

    public Integer getTempOmniconn1() {
        return tempOmniconn1;
    }

    public void setTempOmniconn1(final Integer tempOmniconn1) {
        this.tempOmniconn1 = tempOmniconn1;
    }

    public Integer getTempOmniconn2() {
        return tempOmniconn2;
    }

    public void setTempOmniconn2(final Integer tempOmniconn2) {
        this.tempOmniconn2 = tempOmniconn2;
    }

    public Integer getCanFuel() {
        return canFuel;
    }

    public void setCanFuel(final Integer canFuel) {
        this.canFuel = canFuel;
    }

    public Integer getCanEngineRotation() {
        return canEngineRotation;
    }

    public void setCanEngineRotation(final Integer canEngineRotation) {
        this.canEngineRotation = canEngineRotation;
    }

    public Integer getCanEngineTemp() {
        return canEngineTemp;
    }

    public void setCanEngineTemp(final Integer canEngineTemp) {
        this.canEngineTemp = canEngineTemp;
    }

    public Integer getCanTotalFuel() {
        return canTotalFuel;
    }

    public void setCanTotalFuel(final Integer canTotalFuel) {
        this.canTotalFuel = canTotalFuel;
    }

    public Integer getCanTotalMeters() {
        return canTotalMeters;
    }

    public void setCanTotalMeters(final Integer canTotalMeters) {
        this.canTotalMeters = canTotalMeters;
    }

    @Override
    public String toString() {
        return "DeviceDataMessage{" +
                "deviceNumber=" + getDeviceNumber() +
                ", packageNumber=" + getPackageNumber() +
                ", date=" + getDate() +
                ", satellite=" + getSatellite() +
                ", longitude=" + getLongitude() +
                ", latitude=" + getLatitude() +
                ", speed=" + getSpeed() +
                ", direction=" + getDirection() +
                ", height=" + getHeight() +
                ", HDOP=" + getHDOP() +
                ", lowVoltage=" + getLowVoltage() +
                ", isMove=" + getMove() +
                ", isAlarm=" + getAlarm() +
                ", isActiveGSM1=" + getActiveGSM1() +
                ", isActiveGSM2=" + getActiveGSM2() +
                ", problemGPRS=" + getProblemGPRS() +
                ", problemGPS=" + getProblemGPS() +
                ", deviceVoltage=" + getDeviceVoltage() +
                ", batteryVoltage=" + getBatteryVoltage() +
                ", externalTemp=" + getExternalTemp() +
                ", voltageInput1=" + getVoltageInput1() +
                ", voltageInput2=" + getVoltageInput2() +
                ", voltageInput3=" + getVoltageInput3() +
                ", voltageInput4=" + getVoltageInput4() +
                ", voltageInput5=" + getVoltageInput5() +
                ", voltageInput6=" + getVoltageInput6() +
                ", voltageInput7=" + getVoltageInput7() +
                ", voltageInput8=" + getVoltageInput8() +
                ", extTemp1=" + getExtTemp1() +
                ", extTemp2=" + getExtTemp2() +
                ", extTemp3=" + getExtTemp3() +
                ", extTemp4=" + getExtTemp4() +
                ", extTemp5=" + getExtTemp5() +
                ", extTemp6=" + getExtTemp6() +
                ", extTemp7=" + getExtTemp7() +
                ", extTemp8=" + getExtTemp8() +
                ", keyCode=" + Arrays.toString(getKeyCode()) +
                ", frequencyInput1=" + getFrequencyInput1() +
                ", frequencyInput2=" + getFrequencyInput2() +
                ", fuelOmniconn1=" + getFuelOmniconn1() +
                ", fuelOmniconn2=" + getFuelOmniconn2()+
                ", tempOmniconn1=" + getTempOmniconn1() +
                ", tempOmniconn2=" + getTempOmniconn2() +
                ", canFuel=" + getCanFuel() +
                ", canEngineRotation=" + getCanEngineRotation() +
                ", canEngineTemp=" + getCanEngineTemp() +
                ", canTotalFuel=" + getCanTotalFuel() +
                ", canTotalMeters=" + getCanTotalMeters() +
                "}\n" + getCoordAsString() ;
    }

    public String getCoordAsString() {
        Double f = latitude * 0.000001;
        String s = f.toString();
        s =s+",";
        f = longitude * 0.000001;
        s = s+f.toString();
        return s;

    }
}
