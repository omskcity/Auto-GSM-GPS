package com.navi.core.navisetGT20;

/**
 * Header message from device. receive on connect device.
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class HeaderMessage extends FromDeviceMessage {

    public HeaderMessage() {
        super(MessageType.HEAD);
    }

    private String imei;
    private Integer firmware;


    public String getImei() {
        return imei;
    }

    public void setImei(String imei) {
        this.imei = imei;
    }

    public Integer getFirmware() {
        return firmware;
    }

    public void setFirmware(Integer firmware) {
        this.firmware = firmware;
    }

    @Override
    public String toString() {
        return "HeaderMessage{" +
                "deviceNumber=" + getDeviceNumber() +
                ", imei='" + getImei() + '\'' +
                ", firmware=" + getFirmware() +
                '}';
    }
}
