package com.navi.core.navisetGT20.command.request;

import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.utils.ByteArrayWriter;
import com.navi.core.navisetGT20.command.RequestMessage;

/**
 * Запрос устройству "".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class GetConfigRequest extends RequestMessage {

    public GetConfigRequest() {
        super(CommandType.GET_CONFIG);
    }
    private Integer config;
    @Override
    protected void writeData(final ByteArrayWriter writer) {
        writer.setInteger(1, config);
    }

    @Override
    public String toString() {
        return "GetConfigRequest{" +
                "config=" + config +
                '}';
    }
}
