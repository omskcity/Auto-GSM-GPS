package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.utils.ByteArrayReader;
import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.command.ResponseMessage;

/**
 * Ответ на "Режим охраны".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SetAlarmResponse extends ResponseMessage {

    private Integer alarmSource;
    private Integer event;

    public SetAlarmResponse() {
        this(CommandType.SET_ALARM);
    }

    private SetAlarmResponse(CommandType commandType) {
        super(commandType);
    }

    public Integer getAlarmSource() {
        return alarmSource;
    }

    public void setAlarmSource(final Integer alarmSource) {
        this.alarmSource = alarmSource;
    }

    public Integer getEvent() {
        return event;
    }

    public void setEvent(final Integer event) {
        this.event = event;
    }

    @Override
    public void readData(final ByteArrayReader reader) {
        setAlarmSource(reader.getInteger(2));
        setEvent(reader.getInteger(1));
    }

    @Override
    public String toString() {
        return "SetAlarmResponse{" +
                "alarmSource=" + alarmSource +
                ", event=" + event +
                '}';
    }
}
