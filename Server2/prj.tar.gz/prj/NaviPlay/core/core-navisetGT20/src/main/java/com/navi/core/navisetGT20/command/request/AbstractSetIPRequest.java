package com.navi.core.navisetGT20.command.request;

import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.utils.ByteArrayWriter;
import com.navi.core.navisetGT20.command.RequestMessage;

/**
 * Общий запрос устройству с указанием сервера и порта, абстрактный каждая команда иеет свою реализацию.
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public abstract class AbstractSetIPRequest extends RequestMessage {

    private Integer ip1;
    private Integer ip2;
    private Integer ip3;
    private Integer ip4;
    private Integer port;

    protected AbstractSetIPRequest(CommandType commandType) {
        super(commandType);
    }

    public Integer getIp1() {
        return ip1;
    }

    public void setIp1(final Integer ip1) {
        this.ip1 = ip1;
    }

    public Integer getIp2() {
        return ip2;
    }

    public void setIp2(final Integer ip2) {
        this.ip2 = ip2;
    }

    public Integer getIp3() {
        return ip3;
    }

    public void setIp3(final Integer ip3) {
        this.ip3 = ip3;
    }

    public Integer getIp4() {
        return ip4;
    }

    public void setIp4(final Integer ip4) {
        this.ip4 = ip4;
    }

    public Integer getPort() {
        return port;
    }

    public void setPort(final Integer port) {
        this.port = port;
    }

    @Override
    protected void writeData(final ByteArrayWriter writer) {
        writer.setInteger(1 , ip1);
        writer.setInteger(1 , ip2);
        writer.setInteger(1 , ip3);
        writer.setInteger(1 , ip4);
        writer.setInteger(2 , port);
    }

    @Override
    public String toString() {
        return "AbstractSetIPRequest{ "
                +"commandType=" + getCommandType() +
                "ip1=" + ip1 +
                ", ip2=" + ip2 +
                ", ip3=" + ip3 +
                ", ip4=" + ip4 +
                ", port=" + port +
                '}';
    }
}
