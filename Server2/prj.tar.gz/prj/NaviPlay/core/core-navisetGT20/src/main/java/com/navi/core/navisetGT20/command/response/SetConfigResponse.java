package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.utils.ByteArrayReader;
import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.command.ResponseMessage;

/**
 * Ответ на "Записать конфигурацию".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SetConfigResponse extends ResponseMessage {

    private Integer config;

    public SetConfigResponse() {
        this(CommandType.SET_CONFIG);
    }

    private SetConfigResponse(CommandType commandType) {
        super(commandType);
    }

    public Integer getConfig() {
        return config;
    }

    public void setConfig(final Integer config) {
        this.config = config;
    }


    @Override
    public void readData(final ByteArrayReader reader) {
        setConfig(reader.getInteger(1));

    }

    @Override
    public String toString() {
        return "SetConfigResponse{" +
                "config=" + config +
                '}';
    }
}
