package com.navi.core.navisetGT20.command.request;

import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.utils.ByteArrayWriter;
import com.navi.core.navisetGT20.command.RequestMessage;

/**
 * Запрос устройству "".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SetInputsParamRequest extends RequestMessage {

    private Integer active;
    private Integer lowBorder;
    private Integer highBorder;
    private Integer filterLength;

    public SetInputsParamRequest() {
        super(CommandType.SET_INPUTS_PARAM);
    }

    public Integer getActive() {
        return active;
    }

    public void setActive(final Integer active) {
        this.active = active;
    }

    public Integer getLowBorder() {
        return lowBorder;
    }

    public void setLowBorder(final Integer lowBorder) {
        this.lowBorder = lowBorder;
    }

    public Integer getHighBorder() {
        return highBorder;
    }

    public void setHighBorder(final Integer highBorder) {
        this.highBorder = highBorder;
    }

    public Integer getFilterLength() {
        return filterLength;
    }

    public void setFilterLength(final Integer filterLength) {
        this.filterLength = filterLength;
    }

    @Override
    protected void writeData(final ByteArrayWriter writer) {
        writer.setInteger(1, active);
        writer.setInteger(2, lowBorder);
        writer.setInteger(2, highBorder);
        writer.setInteger(1, filterLength);
    }
}
