package com.navi.core.navisetGT20;

import java.io.Serializable;
import java.util.Map;

/**
 * Предок всех сообщений которые коннектору, сервисные запросы.
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public abstract class ToConnectorMessage implements Serializable {

    public final static String PRM_COMMAND = "command";
    public abstract Map<String, Object> getMapForSend();
}
