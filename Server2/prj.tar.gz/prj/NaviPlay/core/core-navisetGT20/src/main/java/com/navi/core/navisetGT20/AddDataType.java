package com.navi.core.navisetGT20;

import com.navi.core.navisetGT20.utils.ByteArrayReader;

import java.util.EnumSet;


public enum AddDataType {


    STATUS (0) {
        public void fill(final DeviceDataMessage deviceDataMessage, final ByteArrayReader reader) {
            //1
            boolean [] bites = reader.getBooleanArray(1);
            deviceDataMessage.setLowVoltage(bites [0]);
            deviceDataMessage.setMove(bites [1]);
            deviceDataMessage.setAlarm(bites [2]);
            deviceDataMessage.setActiveGSM1(bites [3]);
            deviceDataMessage.setActiveGSM2(bites [4]);
            deviceDataMessage.setProblemGPRS(bites [5]);
            deviceDataMessage.setProblemGPS(bites [6]);
            //deviceDataMessage.setVoltageIsNorm(bites [7]);

        }
    },

    VOLTAGE(1) {
        public void fill(final DeviceDataMessage deviceDataMessage, final ByteArrayReader reader) {
            //4
            deviceDataMessage.setDeviceVoltage(reader.getInteger(2));
            deviceDataMessage.setBatteryVoltage(reader.getInteger(2));
        }
    },
    INTERNAL_TEMP(2) {
        public void fill(final DeviceDataMessage deviceDataMessage, final ByteArrayReader reader) {
            //1
            deviceDataMessage.setExternalTemp(reader.getInteger(1));
        }
    },
    IO_STATUS(3)  {
        public void fill(final DeviceDataMessage deviceDataMessage, final ByteArrayReader reader) {
            //2
            byte [] b = reader.getBytes(2);
            //TODO implement
        }
    },
    IO_VOLTAGE_1_2(4) {
        public void fill(final DeviceDataMessage deviceDataMessage, final ByteArrayReader reader) {
            //4
            deviceDataMessage.setVoltageInput1(reader.getInteger(2));
            deviceDataMessage.setVoltageInput2(reader.getInteger(2));
        }
    },
    IO_VOLTAGE_3_4(5) {
        public void fill(final DeviceDataMessage deviceDataMessage, final ByteArrayReader reader) {
            //4
            deviceDataMessage.setVoltageInput3(reader.getInteger(2));
            deviceDataMessage.setVoltageInput4(reader.getInteger(2));
        }
    },
    IO_VOLTAGE_5_6(6){
        public void fill(final DeviceDataMessage deviceDataMessage, final ByteArrayReader reader) {
            //4
            deviceDataMessage.setVoltageInput5(reader.getInteger(2));
            deviceDataMessage.setVoltageInput6(reader.getInteger(2));
        }
    },
    IO_VOLTAGE_7_8(7) {
        public void fill(final DeviceDataMessage deviceDataMessage, final ByteArrayReader reader) {
            //4
            deviceDataMessage.setVoltageInput7(reader.getInteger(2));
            deviceDataMessage.setVoltageInput8(reader.getInteger(2));
        }
    },
    OUT_TEMP_1_4(8) {
        public void fill(final DeviceDataMessage deviceDataMessage, final ByteArrayReader reader) {
            //4
            deviceDataMessage.setExtTemp1(reader.getInteger(1));
            deviceDataMessage.setExtTemp2(reader.getInteger(1));
            deviceDataMessage.setExtTemp3(reader.getInteger(1));
            deviceDataMessage.setExtTemp4(reader.getInteger(1));
        }
    },
    OUT_TEMP_5_8(9) {
        public void fill(final DeviceDataMessage deviceDataMessage, final ByteArrayReader reader) {
            //4
            deviceDataMessage.setExtTemp5(reader.getInteger(1));
            deviceDataMessage.setExtTemp6(reader.getInteger(1));
            deviceDataMessage.setExtTemp7(reader.getInteger(1));
            deviceDataMessage.setExtTemp8(reader.getInteger(1));
        }
    },
    KEY_COD(10) {
        public void fill(final DeviceDataMessage deviceDataMessage, final ByteArrayReader reader) {
            //6
            deviceDataMessage.setKeyCode(reader.getBytes(6));
        }
    },
    FREQUENCY_DATA(11) {
        public void fill(final DeviceDataMessage deviceDataMessage, final ByteArrayReader reader) {
            //4
            deviceDataMessage.setFrequencyInput1(reader.getInteger(2));
            deviceDataMessage.setFrequencyInput2(reader.getInteger(2));
        }
    },
    FUEL_OMNICOMM(12) {
        public void fill(final DeviceDataMessage deviceDataMessage, final ByteArrayReader reader) {
            //4
            deviceDataMessage.setFuelOmniconn1(reader.getInteger(2));
            deviceDataMessage.setFuelOmniconn2(reader.getInteger(2));
        }
    },
    TEMP_OMNICOMM(13) {
        public void fill(final DeviceDataMessage deviceDataMessage, final ByteArrayReader reader) {
            //2
            deviceDataMessage.setTempOmniconn1(reader.getInteger(1));
            deviceDataMessage.setTempOmniconn2(reader.getInteger(1));
        }
    },
    CAN_DATA1(14) {
        public void fill(final DeviceDataMessage deviceDataMessage, final ByteArrayReader reader) {
            //4
            deviceDataMessage.setCanFuel(reader.getInteger(1));
            deviceDataMessage.setCanEngineRotation(reader.getInteger(2));
            deviceDataMessage.setCanEngineTemp(reader.getInteger(1));
        }
    },
    CAN_DATA2(15) {
        public void fill(final DeviceDataMessage deviceDataMessage, final ByteArrayReader reader) {
            //8
            deviceDataMessage.setCanTotalFuel(reader.getInteger(4));
            deviceDataMessage.setCanTotalMeters(reader.getInteger(4));
        }
    };
    private int order;

     AddDataType(final int order) {
         this.order = order;
    }


    public int getOrder() {
        return order;
    }

    public static AddDataType valueByCode(byte value) {
        AddDataType returnValue = null;
        for (final AddDataType element : EnumSet.allOf(AddDataType.class)) {
            if ( element.getOrder() == value) {
                returnValue = element;
            }
        }
        return returnValue;
    }

    public abstract void fill(DeviceDataMessage deviceDataMessage, ByteArrayReader reader);
}
