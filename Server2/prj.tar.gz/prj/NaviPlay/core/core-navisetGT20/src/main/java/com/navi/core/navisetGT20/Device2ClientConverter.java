package com.navi.core.navisetGT20;

import com.navi.core.client.AlarmType;
import com.navi.core.client.messages.toClient.AlarmMessage;
import com.navi.core.client.messages.toClient.DataMessage;
import com.navi.core.client.messages.EventMessage;
import com.navi.core.client.messages.ToClientMessage;
import com.navi.core.client.messages.toClient.DeviceStatusResponse;

import com.navi.core.navisetGT20.command.ResponseMessage;
import com.navi.core.navisetGT20.command.response.GetStatusResponse;
import com.navi.core.client.Coordinate;
import org.apache.log4j.Logger;

import java.util.HashSet;

public class Device2ClientConverter {

    final Logger log = Logger.getLogger(Device2ClientConverter.class);

    public ToClientMessage convert(DeviceDataMessage from) {
        DataMessage to = new DataMessage();
        to.setDeviceNum(from.getDeviceNumber());
        to.setDate(from.getDate());
        to.setAlarm(from.getAlarm());
        to.setMove(from.getMove());
        to.setSpeed(from.getSpeed());
        to.setCoordinate(new Coordinate(
                from.getLatitude(),
                from.getLongitude(),
                from.getHeight()
        ));
        return to;
    }

    public ToClientMessage convert(DeviceAlarm from) {
        AlarmMessage to = new AlarmMessage();
        to.setDeviceNum(from.getDeviceNumber());
        to.setAlarmSources(new HashSet<AlarmType>());
        for (AlarmSourceType alarmSourceType : from.getAlarmSources()) {
            if (alarmSourceType.getAlarmType() != null ) {
                to.getAlarmSources().add(alarmSourceType.getAlarmType());
            }
        }
        return to;
    }

    public ToClientMessage convert(DeviceEvent from) {
        EventMessage to = new EventMessage();
        to.setDeviceNum(from.getDeviceNumber());
        to.setEventType(from.getEventType());
        return to;
    }

    public ToClientMessage convert(GetStatusResponse from) {
        DeviceStatusResponse to = new DeviceStatusResponse();
        to.setDeviceNum(from.getDeviceNumber());
        to.setAlarm(from.getAlarm());
        to.setLowVoltage(from.getLowVoltage());
        return to;
    }

    public ToClientMessage convert(ResponseMessage from) {
        if (from instanceof GetStatusResponse) {
            return convert((GetStatusResponse)from);
        }
        log.warn("unhandled message" + from);
        return null;
    }

}
