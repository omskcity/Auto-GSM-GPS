package com.navi.core.navisetGT20.command;

import com.navi.core.navisetGT20.command.response.AbstractCommonResponse;
import com.navi.core.navisetGT20.utils.ByteArrayReader;

import java.util.EnumSet;

public enum CommonResponseType {


    COMMON_RESPONSE_UNKNOWN_CMD (250),
    COMMON_RESPONSE_CRC_ERROR (251),
    COMMON_RESPONSE_OK (252),
    COMMON_RESPONSE_CMD_ERROR (253);

    private int respondsID;
    private static final int COMMAND_ID_LENGTH = 1;

    CommonResponseType(final int respondsID) {
        this.respondsID = respondsID;
    }


    public int getRespondsID() {
        return respondsID;
    }

    public static CommonResponseType valueByCode(int value) {
        CommonResponseType returnValue = null;
        for (final CommonResponseType element : EnumSet.allOf(CommonResponseType.class)) {
            if ( element.getRespondsID() == value) {
                returnValue = element;
            }
        }
        return returnValue;
    }

    public ResponseMessage createResponse(ByteArrayReader reader) {
        int commandId = reader.getInteger(COMMAND_ID_LENGTH);
        CommandType commandType = CommandType.valueByCode(commandId);
        ResponseMessage responseMessage = commandType.createResponse(new ByteArrayReader(new byte[]{}));
        if (responseMessage instanceof AbstractCommonResponse) {
            AbstractCommonResponse commonResponse = (AbstractCommonResponse) responseMessage;
            commonResponse.setStatus(this);
        }
        return responseMessage;
    }

}
