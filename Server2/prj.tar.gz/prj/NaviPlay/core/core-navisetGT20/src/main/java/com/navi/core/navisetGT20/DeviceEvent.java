package com.navi.core.navisetGT20;

import com.navi.core.navisetGT20.utils.ByteArrayReader;

public class DeviceEvent extends FromDeviceMessage {

    public static final Integer EVENT_MESSAGE_LENGTH = 1;

    public DeviceEvent(ByteArrayReader reader) {
        super(MessageType.RESPONSE_SERVICE);
        setEventType(reader.getInteger(EVENT_MESSAGE_LENGTH));
    }
    private Integer eventType;

    public Integer getEventType() {
        return eventType;
    }

    public void setEventType(Integer eventType) {
        this.eventType = eventType;
    }

    @Override
    public String toString() {
        return "DeviceEvent{" +
               "deviceNum=" + getDeviceNumber() +
               "eventType=" + getEventType() +
                '}';
    }
}
