package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.command.CommandType;

/**
 * Ответ на "Переключить прибор на другую СИМ".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SetSimCardResponse extends AbstractCommonResponse {

    public SetSimCardResponse() {
        this(CommandType.SET_SIM_CARD);
    }

    private SetSimCardResponse(CommandType commandType) {
        super(commandType);
    }

}
