package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.utils.ByteArrayReader;
import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.command.ResponseMessage;

/**
 * ответ на "Запрос общего состояния устройства".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class GetStatusResponse extends ResponseMessage {
/*

номер(2)
версия ПО(1)
тип протокола(1)
статус(1)
внеш/внутрнапряжение(2)
температура(1)
уровень GSM сигнала(1)

 */
    private Integer deviceNumber;
    private Integer firmware;
    private Integer protocolType;
    private Integer status;
    private Integer internalVoltage;
    private Integer externalVoltage;
    private Integer temp;
    private Integer levelGSM;

    private Boolean lowVoltage;
    private Boolean isMove;
    private Boolean isAlarm;
    private Boolean isActiveGSM1;
    private Boolean isActiveGSM2;
    private Boolean problemGPRS;
    private Boolean problemGPS;

    public GetStatusResponse() {
        this(CommandType.GET_STATUS);
    }

    private GetStatusResponse(CommandType commandType) {
        super(commandType);
    }

    public Integer getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(final Integer deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Integer getFirmware() {
        return firmware;
    }

    public void setFirmware(final Integer firmware) {
        this.firmware = firmware;
    }

    public Integer getProtocolType() {
        return protocolType;
    }

    public void setProtocolType(final Integer protocolType) {
        this.protocolType = protocolType;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(final Integer status) {
        this.status = status;
    }

    public Integer getInternalVoltage() {
        return internalVoltage;
    }

    public void setInternalVoltage(final Integer internalVoltage) {
        this.internalVoltage = internalVoltage;
    }

    public Integer getExternalVoltage() {
        return externalVoltage;
    }

    public void setExternalVoltage(final Integer externalVoltage) {
        this.externalVoltage = externalVoltage;
    }

    public Integer getTemp() {
        return temp;
    }

    public void setTemp(final Integer temp) {
        this.temp = temp;
    }

    public Integer getLevelGSM() {
        return levelGSM;
    }

    public void setLevelGSM(final Integer levelGSM) {
        this.levelGSM = levelGSM;
    }

    public Boolean getLowVoltage() {
        return lowVoltage;
    }

    public void setLowVoltage(Boolean lowVoltage) {
        this.lowVoltage = lowVoltage;
    }

    public Boolean getMove() {
        return isMove;
    }

    public void setMove(Boolean move) {
        isMove = move;
    }

    public Boolean getAlarm() {
        return isAlarm;
    }

    public void setAlarm(Boolean alarm) {
        isAlarm = alarm;
    }

    public Boolean getActiveGSM1() {
        return isActiveGSM1;
    }

    public void setActiveGSM1(Boolean activeGSM1) {
        isActiveGSM1 = activeGSM1;
    }

    public Boolean getActiveGSM2() {
        return isActiveGSM2;
    }

    public void setActiveGSM2(Boolean activeGSM2) {
        isActiveGSM2 = activeGSM2;
    }

    public Boolean getProblemGPRS() {
        return problemGPRS;
    }

    public void setProblemGPRS(Boolean problemGPRS) {
        this.problemGPRS = problemGPRS;
    }

    public Boolean getProblemGPS() {
        return problemGPS;
    }

    public void setProblemGPS(Boolean problemGPS) {
        this.problemGPS = problemGPS;
    }

    @Override
    public void readData(final ByteArrayReader reader) {
        setDeviceNumber(reader.getInteger(2));
        setFirmware(reader.getInteger(1));
        setProtocolType(reader.getInteger(1));
        boolean [] bites = reader.getBooleanArray(1);
        setLowVoltage(bites[0]);
        setMove(bites[1]);
        setAlarm(bites[2]);
        setActiveGSM1(bites[3]);
        setActiveGSM2(bites[4]);
        setProblemGPRS(bites[5]);
        setProblemGPS(bites[6]);
        /*
        статус - см. описание протокола, внеш/внутр (в милливольтах) - определяется статусом (внешн, если внешнее напряжение в норме)
         */
        if (getLowVoltage()) {
            setInternalVoltage(reader.getInteger(2));
        } else {
            setExternalVoltage(reader.getInteger(2));
        }
        setTemp(reader.getInteger(1));
        setLevelGSM(reader.getInteger(1));

    }

    @Override
    public String toString() {
        return "GetStatusResponse{" +
                "deviceNumber=" + deviceNumber +
                ", firmware=" + firmware +
                ", protocolType=" + protocolType +
                ", status=" + status +
                ", internalVoltage=" + internalVoltage +
                ", externalVoltage=" + externalVoltage +
                ", temp=" + temp +
                ", levelGSM=" + levelGSM +
                ", lowVoltage=" + lowVoltage +
                ", isMove=" + isMove +
                ", isAlarm=" + isAlarm +
                ", isActiveGSM1=" + isActiveGSM1 +
                ", isActiveGSM2=" + isActiveGSM2 +
                ", problemGPRS=" + problemGPRS +
                ", problemGPS=" + problemGPS +
                '}';
    }
}
