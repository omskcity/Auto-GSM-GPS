package com.navi.core.navisetGT20.command.request;

import org.junit.Assert;
import org.junit.Test;

import java.io.InputStream;

public class GetStatusRequestTest  {

    @Test
    public void testParse() throws Exception {

        InputStream stream;
        stream = this.getClass().getClassLoader()
            .getResourceAsStream("GetCamImageRequest.bin");
        byte [] bytes = new byte[3];
        stream.read(bytes,0,3);
        stream.close();
        GetCamImageRequest request = new GetCamImageRequest();
        request.setSize((byte) 2);
        request.setType((byte) 0);
        byte [] bytes1 = request.getBytes();
        Assert.assertArrayEquals(bytes1,  bytes);

    }
}
