package com.navi.core.navisetGT20;

import java.util.EnumSet;

/**
 * Type of message
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public enum MessageType {
    HEAD(0),
    DATA(1),
    RESPONSE_SERVICE(2),
    RESERVED(3);

    private Integer code;

    private MessageType(Integer code) {
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }

    public static MessageType valueByCode(Integer value) {
        MessageType returnValue = null;
        for (final MessageType element : EnumSet.allOf(MessageType.class)) {
            if (element.getCode().equals(value)) {
                returnValue = element;
            }
        }
        return returnValue;
    }


}
