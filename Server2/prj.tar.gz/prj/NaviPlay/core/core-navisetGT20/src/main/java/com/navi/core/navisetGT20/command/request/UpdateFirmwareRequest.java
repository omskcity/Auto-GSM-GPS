package com.navi.core.navisetGT20.command.request;

import com.navi.core.navisetGT20.command.CommandType;

/**
 * Запрос устройству "".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class UpdateFirmwareRequest extends AbstractSetIPRequest {

    public UpdateFirmwareRequest() {
        super(CommandType.UPDATE_FIRMWARE);
    }

}
