package com.navi.core.navisetGT20.command.request;

import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.utils.ByteArrayWriter;
import com.navi.core.navisetGT20.command.RequestMessage;

/**
 * Запрос устройству "".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class GetTrackParamRequest extends RequestMessage {

    public GetTrackParamRequest() {
        super(CommandType.GET_TRACK_PARAM);
    }

    @Override
    protected void writeData(final ByteArrayWriter writer) {
    }
}
