package com.navi.core.navisetGT20;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * Предок всех сообщений которые напрявляются устройству.
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public abstract class ToDeviceMessage extends ToConnectorMessage implements Serializable {

    private final static String PRM_COMMAND_PACKAGE = "package";
    private final static String ATTR_DATA_NAME = "data";
    private final static String ATTR_DATA_SOCKET_ID = "socket_id";

    private Integer deviceNum;
    private Integer socketId;

    public void setSocket(final Integer socket) {
        socketId = socket;
    }

    public Integer getSocket() {
        return socketId;
    }

    public Integer getDeviceNum() {
        return deviceNum;
    }

    public void setDeviceNum(Integer deviceNum) {
        this.deviceNum = deviceNum;
    }
    public abstract byte[] getBytes();

    @Override
    public Map<String, Object> getMapForSend() {
        Map<String, Object> mapForSend = new HashMap<String, Object>();
        mapForSend.put(PRM_COMMAND, PRM_COMMAND_PACKAGE);
        mapForSend.put(ATTR_DATA_NAME, getBytes());
        mapForSend.put(ATTR_DATA_SOCKET_ID, socketId);
        return mapForSend;
    }
}
