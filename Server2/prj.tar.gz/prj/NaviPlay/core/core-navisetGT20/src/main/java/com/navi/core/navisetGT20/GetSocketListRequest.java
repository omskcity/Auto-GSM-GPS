package com.navi.core.navisetGT20;

import java.util.HashMap;
import java.util.Map;

/**
 * Запрос коннектору на списка сокетов.
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class GetSocketListRequest extends ToConnectorMessage {

    public final static String COMMAND = "get_socket_list";
    public final static String PRM_NAME_SOCKETS = "sockets";

    @Override
    public Map<String, Object> getMapForSend() {
        Map<String, Object> mapForSend = new HashMap<String, Object>();
        mapForSend.put(PRM_COMMAND, COMMAND);
        return mapForSend;
    }

    @Override
    public String toString() {
        return this.getClass().getName() + "{" +
                '}';
    }
}
