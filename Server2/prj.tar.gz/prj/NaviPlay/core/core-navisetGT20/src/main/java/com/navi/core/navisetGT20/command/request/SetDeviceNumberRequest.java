package com.navi.core.navisetGT20.command.request;

import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.utils.ByteArrayWriter;
import com.navi.core.navisetGT20.command.RequestMessage;

/**
 * Запрос устройству "".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SetDeviceNumberRequest extends RequestMessage {

    private Integer deviceNumber;

    public SetDeviceNumberRequest() {
        super(CommandType.SET_DEVICE_NUMBER);
    }

    public Integer getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(final Integer deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    @Override
    protected void writeData(final ByteArrayWriter writer) {
        writer.setInteger(2, getDeviceNumber());
    }
}
