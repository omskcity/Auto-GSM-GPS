package com.navi.core.navisetGT20.utils;

import com.navi.core.navisetGT20.AddDataType;
import com.navi.core.navisetGT20.DeviceDataMessage;
import com.navi.core.navisetGT20.FromDeviceMessage;
import com.navi.core.navisetGT20.HeaderMessage;
import com.navi.core.navisetGT20.MessageType;
import com.navi.core.navisetGT20.ReservedMessage;
import com.navi.core.navisetGT20.ServiceMessageType;
import com.navi.core.navisetGT20.command.CommandType;
import com.navi.core.navisetGT20.command.CommonResponseType;

import java.util.*;

public class Converter {

    private static final int DEVICE_NUMBER_LENGTH = 2;
    private static final int IMEI_LENGTH = 15;
    private static final int FIRMWARE_LENGTH = 1;
    private static final int ADD_DATA_DEFINITION_LENGTH = 2;
    private static final int PACKAGE_NUMBER_LENGTH = 2;
    private static final int DATE_LENGTH = 4;
    private static final int SATELLITES_LENGTH = 1;
    private static final int LATITUDE_LENGTH = 4;
    private static final int LONGITUDE_LENGTH = 4;
    private static final int SPEED_LENGTH = 2;
    private static final int DIRECTION_LENGTH = 2;
    private static final int HEIGHT_LENGTH = 2;
    private static final int HDOP_LENGTH = 1;

    private static final int RESPONSE_COMMAND_ID_LENGTH = 1;


    public static FromDeviceMessage bytes2deviceMessage (MessageType mt, byte [] bytes) {
        ByteArrayReader reader = new ByteArrayReader(bytes);
        if (mt == MessageType.HEAD) {
            return bytes2headerMessage(reader);
        } else if (mt == MessageType.RESPONSE_SERVICE) {
            return bytes2responseMessage(reader);
        } else if (mt == MessageType.DATA) {
            return bytes2dataMessage(reader);
        } else if (mt == MessageType.RESERVED) {
            return bytes2reservedMessage(reader);
        }
        return null;
    }

    public static HeaderMessage bytes2headerMessage (ByteArrayReader reader) {
        HeaderMessage headerMessage = new HeaderMessage();
        headerMessage.setDeviceNumber(reader.getInteger(DEVICE_NUMBER_LENGTH));
        headerMessage.setImei(reader.getString(IMEI_LENGTH));
        headerMessage.setFirmware(reader.getInteger(FIRMWARE_LENGTH));
        return headerMessage;

    }

    public static FromDeviceMessage bytes2responseMessage(ByteArrayReader reader) {

        Integer commandId = reader.getInteger(RESPONSE_COMMAND_ID_LENGTH);
        CommandType commandType = CommandType.valueByCode(commandId);
        if (commandType != null) {
            return commandType.createResponse(reader);
        } else {
            CommonResponseType commonResponseType = CommonResponseType.valueByCode(commandId);
            if (commonResponseType != null) {
                return commonResponseType.createResponse(reader);
            } else {
                ServiceMessageType serviceMessageType = ServiceMessageType.valueByCode(commandId);
                if (serviceMessageType != null) {
                    return serviceMessageType.createMessage(reader);
                }
            }
            return null;
        }
    }

    public static ReservedMessage bytes2reservedMessage (ByteArrayReader reader) {
        return new ReservedMessage(reader);

    }

    public static DeviceDataMessage bytes2dataMessage (ByteArrayReader reader) {
        //WARNING Order of read important
        DeviceDataMessage deviceDataMessage = new DeviceDataMessage();
        deviceDataMessage.setDeviceNumber(reader.getInteger(DEVICE_NUMBER_LENGTH));
        boolean [] addDataDef = reader.getBooleanArray(ADD_DATA_DEFINITION_LENGTH);
        deviceDataMessage.setPackageNumber(reader.getInteger(PACKAGE_NUMBER_LENGTH));
        Long l = reader.getLong(DATE_LENGTH)*1000;

        Date d = new Date(l);
        deviceDataMessage.setDate(d);
        int satelite = reader.getInteger(SATELLITES_LENGTH);
        if (satelite < 16) {
            deviceDataMessage.setSatellite(satelite);
        }
        deviceDataMessage.setLatitude(reader.getLong(LATITUDE_LENGTH));
        deviceDataMessage.setLongitude(reader.getLong(LONGITUDE_LENGTH));

        deviceDataMessage.setSpeed(reader.getInteger(SPEED_LENGTH));
        deviceDataMessage.setDirection(reader.getInteger(DIRECTION_LENGTH));
        deviceDataMessage.setHeight(reader.getInteger(HEIGHT_LENGTH));
        deviceDataMessage.setHDOP(reader.getInteger(HDOP_LENGTH));
        for (AddDataType addDataType : EnumSet.allOf(AddDataType.class)) {
            int ind = addDataType.getOrder();
            if (ind < addDataDef.length) {
                if ( addDataDef[ind]) {
                    addDataType.fill(deviceDataMessage, reader);
                }
            }
        }
        return deviceDataMessage;

    }
}