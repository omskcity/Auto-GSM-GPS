package com.navi.core.navisetGT20.utils;

import com.navi.core.navisetGT20.FromDeviceMessage;
import com.navi.core.navisetGT20.MessageType;

import java.io.*;

/**
 * Created with IntelliJ IDEA.
 * User: basil
 * Date: 13.02.13
 * Time: 22:39
 * To change this template use File | Settings | File Templates.
 */
class BitDemo {
    public static void main(String[] args) throws IOException {
/*        File f = new File("out");
        OutputStream os = new FileOutputStream(f);
        os.write(ByteUtils.setUnsignedIntValue(4, 71));
        os.flush();
        os.close();*/

        File f = new File("pack1");
        InputStream os = new FileInputStream(f);
        byte [] bytes = new byte[20];
        os.read(bytes);
        os.close();
        FromDeviceMessage m = Converter.bytes2deviceMessage(MessageType.RESPONSE_SERVICE, bytes);
        System.out.println(m);


    }
}