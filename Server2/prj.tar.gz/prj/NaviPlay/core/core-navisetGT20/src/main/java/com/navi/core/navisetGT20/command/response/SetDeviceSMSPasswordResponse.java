package com.navi.core.navisetGT20.command.response;

import com.navi.core.navisetGT20.command.CommandType;

/**
 * Ответ на "Сменить пароль доступа по СМС, DTMF".
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class SetDeviceSMSPasswordResponse extends AbstractCommonResponse {

    public SetDeviceSMSPasswordResponse() {
        this(CommandType.SET_DEVICE_SMS_PASSWORD);
    }

    private SetDeviceSMSPasswordResponse(CommandType commandType) {
        super(commandType);
    }
}
