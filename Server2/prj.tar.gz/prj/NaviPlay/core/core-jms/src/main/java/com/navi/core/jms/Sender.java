package com.navi.core.jms;

import javax.jms.*;
import javax.jms.Connection;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.pool.BasePoolableObjectFactory;
import org.apache.commons.pool.impl.GenericObjectPool;
import org.apache.log4j.Logger;

import java.io.Serializable;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Sender  {

    private final Logger log = Logger.getLogger(Sender.class);
    private ConnectionProps connectionProps;
    ExecutorService service;
    private GenericObjectPool<PooledMessageProducer> producerPool;
    private String replayToSuffix = "";
    private Map<String, Message> responses = new HashMap<String, Message>();
    private List<String> waitResponses = new ArrayList<String>();
    private int responseTimeout = 1000;
    private int responseTry = 1000;
    Receiver responseReceiver;

    public Sender(ConnectionProps connectionProps, String replayToSuffix, int responseTimeout, int responseTry) {
        this.replayToSuffix = replayToSuffix;
        this.responseTimeout = responseTimeout;
        this.connectionProps = connectionProps;
        this.responseTry = responseTry;
    }

    public Sender(ConnectionProps connectionProps) {
        this.connectionProps = connectionProps;
    }

    public void start() {
        producerPool = new GenericObjectPool<PooledMessageProducer>(new ProducerFactory(), connectionProps.getnThreads());
        service = Executors.newFixedThreadPool(connectionProps.getnThreads());
        if (StringUtils.isNotBlank(replayToSuffix)) {
            ConnectionProps receiverConnectionProps = connectionProps.copy();
            receiverConnectionProps.setSubject(connectionProps.getSubject() + ".replyTo." + replayToSuffix);
            responseReceiver = new Receiver(receiverConnectionProps, new MessageListener() {
                @Override
                public void onMessage(Message message) {
                    if (message != null) {
                        try {
                            responses.put(message.getJMSCorrelationID(), message);
                        } catch (JMSException e) {
                            log.error(e.getMessage(), e);
                        }
                    }

                }
            });
            responseReceiver.start();
        }
    }
    public void stop() {
        try {
            producerPool.close();
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
        if (responseReceiver != null) {
            responseReceiver.stop();
        }
    }

    private Message getResponse(String messageId) {
        Message result;
        result = responses.get(messageId);
        if (result != null) {
            responses.remove(messageId);
            waitResponses.remove(messageId);
        }
        //TODO clean up results

        return result;
    }

    private String createRandomString() {
        Random random = new Random(System.currentTimeMillis());
        long randomLong = random.nextLong();
        return Long.toHexString(randomLong);
    }

    public Message request(final Map<String, Object> map) {
        PooledMessageProducer producer = null;
        try {
            producer = producerPool.borrowObject();
        } catch (Exception e) {
            log.error(e);
        }
        String messageId = null;
        if (producer != null) {
            try {
                Message sendMessage =  producer.createMessage(map);
                sendMessage.setJMSMessageID(createRandomString());
                sendMessage.setJMSReplyTo(responseReceiver.getDestination());
                producer.send(sendMessage);
                messageId = sendMessage.getJMSMessageID();
                waitResponses.add(messageId);
            } catch (JMSException e) {
                log.error(e.getMessage(),e);
            }
            try {
                producerPool.returnObject(producer);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }

        for (int i=responseTry; i>0; i--) {
            try {
                Thread.sleep(responseTimeout);
            } catch (InterruptedException e) {
                log.error(e.getMessage(), e);
            }
            Message message = getResponse(messageId);
            if (message != null) {
                return message;
            }
        }
        return getResponse(messageId);
    }

    public Message request(final Serializable obj) {
        PooledMessageProducer producer = null;
        try {
            producer = producerPool.borrowObject();
        } catch (Exception e) {
            log.error(e);
        }
        String messageId = null;
        if (producer != null) {
            try {
                Message sendMessage =  producer.createMessage(obj);
                sendMessage.setJMSMessageID(createRandomString());
                sendMessage.setJMSReplyTo(responseReceiver.getDestination());
                producer.send(sendMessage);
                messageId = sendMessage.getJMSMessageID();
                waitResponses.add(messageId);
            } catch (JMSException e) {
                log.error(e.getMessage(),e);
            }
            try {
                producerPool.returnObject(producer);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }

        for (int i=responseTry; i>0; i--) {
            try {
                Thread.sleep(responseTimeout);
            } catch (InterruptedException e) {
                log.error(e.getMessage(), e);
            }
            Message message = getResponse(messageId);
            if (message != null) {
                return message;
            }
        }
        return getResponse(messageId);
    }


    public void reply(final Map<String, Object> map, Message toMessage) {
        PooledMessageProducer producer = null;
        try {
            producer = producerPool.borrowObject();
        } catch (Exception e) {
            log.error(e);
        }
        if (producer != null) {
            try {
                Message sendMessage =  producer.createMessage(map);
                sendMessage.setJMSCorrelationID(toMessage.getJMSMessageID());
                producer.send(toMessage.getJMSReplyTo(), sendMessage);
            } catch (JMSException e) {
                log.error(e.getMessage(),e);
            }
            try {
                producerPool.returnObject(producer);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    public void reply(final Serializable obj, Message toMessage) {
        PooledMessageProducer producer = null;
        try {
            producer = producerPool.borrowObject();
        } catch (Exception e) {
            log.error(e);
        }
        if (producer != null) {
            try {
                Message sendMessage =  producer.createMessage(obj);
                sendMessage.setJMSCorrelationID(toMessage.getJMSMessageID());
                producer.send(toMessage.getJMSReplyTo(), sendMessage);
            } catch (JMSException e) {
                log.error(e.getMessage(),e);
            }
            try {
                producerPool.returnObject(producer);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    public void send(final String str) {
        service.submit( new Runnable() {
            @Override
            public void run() {
                sendNow(str);
            }
        });
    }

    public void send(final byte [] bytes) {
        service.submit( new Runnable() {
            @Override
            public void run() {
                sendNow(bytes);
            }
        });
    }

    public void send(final Map<String, Object> map) {
        service.submit( new Runnable() {
            @Override
            public void run() {
                sendNow(map);
            }
        });
    }

    public void send(final Serializable obj) {
        service.submit( new Runnable() {
            @Override
            public void run() {
                sendNow(obj);
            }
        });
    }


    public void sendNow(final String str) {
        PooledMessageProducer producer = null;
        try {
            producer = producerPool.borrowObject();
        } catch (Exception e) {
            log.error(e);
        }
        if (producer != null) {
            producer.send(str);
            try {
                producerPool.returnObject(producer);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    public void sendNow(final byte [] bytes) {
        PooledMessageProducer producer = null;
        try {
            producer = producerPool.borrowObject();
        } catch (Exception e) {
            log.error(e);
        }
        if (producer != null) {
            producer.send(bytes);
            try {
                producerPool.returnObject(producer);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    public void sendNow(final Map<String, Object> map) {
        PooledMessageProducer producer = null;
        try {
            producer = producerPool.borrowObject();
        } catch (Exception e) {
            log.error(e);
        }
        if (producer != null) {
            producer.send(map);
            try {
                producerPool.returnObject(producer);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    public void sendNow(final Serializable obj) {
        PooledMessageProducer producer = null;
        try {
            producer = producerPool.borrowObject();
        } catch (Exception e) {
            log.error(e);
        }
        if (producer != null) {
            producer.send(obj);
            try {
                producerPool.returnObject(producer);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }
    
    public void close() {
        try {
            producerPool.close();
            responseReceiver.stop();
            service.shutdown();
        }
        catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    class PooledMessageProducer {

        private Connection connection;

        private MessageProducer producer;

        private Session session;

        public void open()  {
            ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(connectionProps.getUser(), connectionProps.getPassword(), connectionProps.getUrl());
            try {
                connection = connectionFactory.createConnection();
                connection.start();
                session = connection.createSession(connectionProps.isTransacted(), connectionProps.getAcknowledgeMode());

                connection.setExceptionListener(
                    new ExceptionListener() {
                        @Override
                        public void onException(final JMSException exception) {
                            log.error(exception.getMessage(), exception);
                        }
                    }
                );
                Destination destination = null;
                if (StringUtils.isNotBlank(connectionProps.getSubject())) {
                    if (connectionProps.isBroadcast()){
                        destination = session.createTopic(connectionProps.getSubject());
                    } else {
                        destination = session.createQueue(connectionProps.getSubject());
                    }

                }
                producer = session.createProducer(destination);
                producer.setDeliveryMode(DeliveryMode.NON_PERSISTENT);
            }
            catch (JMSException e) {
                log.error(e.getMessage(), e);
            }
        }
        public void close() {
            try {
                producer.close();
                session.close();
                connection.close();
            }
            catch (JMSException e) {
                e.printStackTrace();
            }
        }

        public void send(byte [] bytes ) {
            BytesMessage message;
            try {
                message = session.createBytesMessage();
                message.writeBytes(bytes);
                log.debug("[" + connectionProps.getSubject() + "] was sent message " + message.getJMSMessageID());
                send(message);
            } catch (JMSException e) {
                log.error(e.getMessage(), e);
            }
        }

        public void send(String  str) {
            Message message;
            try {
                message = session.createTextMessage(str);
                log.debug("[" + connectionProps.getSubject() + "] send message " + message.getJMSMessageID());
                send(message);
            } catch (JMSException e) {
                log.error(e.getMessage(), e);
            }
        }

        public Message createMessage(Serializable obj) {
            Message message = null;
            try {
                message = session.createObjectMessage(obj);
                log.debug("[" + connectionProps.getSubject() + "] create message " + message.getJMSMessageID());

            } catch (JMSException e) {
                log.error(e.getMessage(), e);
            }
            return message;
        }

        public void send(Serializable obj) {
            Message message;
            try {
                message = session.createObjectMessage(obj);
                log.debug("[" + connectionProps.getSubject() + "] send message " + message.getJMSMessageID());
                send(message);
            } catch (JMSException e) {
                log.error(e.getMessage(), e);
            }
        }

        public String send( Map<String, Object> map) {
            Message message = createMessage(map);
            try {
                producer.send(message);
                return message.getJMSMessageID();
            } catch (JMSException e) {
                log.error(e.getMessage(), e);
            }
            return null;
        }

        public Message createMessage(Map<String, Object> map) {
            MapMessage message;
            try {
                message = session.createMapMessage();
                for (String name: map.keySet()) {
                    Object val = map.get(name);
                    if (val instanceof Boolean) {
                        message.setBoolean(name, (Boolean) val);
                    } else if (val instanceof Byte) {
                        message.setByte(name, (Byte) val);
                    } else if (val instanceof Short) {
                        message.setShort(name, (Short) val);
                    } else if (val instanceof Character) {
                        message.setChar(name, (Character) val);
                    } else if (val instanceof Integer) {
                        message.setInt(name, (Integer) val);
                    } else if (val instanceof Long) {
                        message.setLong(name, (Long) val);
                    } else if (val instanceof Double) {
                        message.setDouble(name, (Double) val);
                    } else if (val instanceof String) {
                        message.setString(name, (String) val);
                    } else {
                        message.setObject(name, val);
                    }
                }
                log.debug("[" + connectionProps.getSubject() + "] create message " + message.getJMSMessageID());
                return  message;
            } catch (JMSException e) {
                log.error(e.getMessage(), e);
            }
            return null;
        }

        public void send(Message message) {
            try {
                producer.send(message);
            } catch (JMSException e) {
                log.error(e.getMessage(), e);
            }
        }

        public void send(Destination destination, Message message) {
            try {
                producer.send(destination, message);
            } catch (JMSException e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    class ProducerFactory extends BasePoolableObjectFactory<PooledMessageProducer> {
        public PooledMessageProducer makeObject() {
            PooledMessageProducer pooledMessageProducer = new PooledMessageProducer();
            pooledMessageProducer.open();
            return pooledMessageProducer;
        }


        @Override
        public void destroyObject(PooledMessageProducer obj) throws Exception {
            obj.close();
        }
    }

}
