package com.navi.core.jms;

import org.apache.activemq.ActiveMQConnection;

import javax.jms.Session;

/**
 * Properties for connection to JMS.
 *
 * @author <a href="mailto:basil.belokon@gmail">Vasily Belokon</a>
 * @version 1.0
 */
public class ConnectionProps {
    private String user = ActiveMQConnection.DEFAULT_USER;
    private String password = ActiveMQConnection.DEFAULT_PASSWORD;
    private String url = ActiveMQConnection.DEFAULT_BROKER_URL;
    private long timeOut = 1000;
    private boolean transacted = false;
    private boolean broadcast = false;
    private int acknowledgeMode = Session.AUTO_ACKNOWLEDGE;
    private String subject = "DEFAULT.TOOL";
    private int nThreads = 3;

    public String getUser() {
        return user;
    }

    public void setUser(final String user) {
        this.user = user;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(final String password) {
        this.password = password;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(final String url) {
        this.url = url;
    }

    public long getTimeOut() {
        return timeOut;
    }

    public void setTimeOut(final long timeOut) {
        this.timeOut = timeOut;
    }

    public boolean isTransacted() {
        return transacted;
    }

    public void setTransacted(final boolean transacted) {
        this.transacted = transacted;
    }

    public int getAcknowledgeMode() {
        return acknowledgeMode;
    }

    public void setAcknowledgeMode(final int acknowledgeMode) {
        this.acknowledgeMode = acknowledgeMode;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public int getnThreads() {
        return nThreads;
    }

    public void setnThreads(int nThreads) {
        this.nThreads = nThreads;
    }

    @Override
    public boolean equals(final Object obj) {
        if (obj != null && obj instanceof ConnectionProps) {
            ConnectionProps c = (ConnectionProps)obj;
            return url.equalsIgnoreCase(c.getUrl())
                   && subject.equalsIgnoreCase(c.getSubject())
                   && user.equalsIgnoreCase(c.getUser())
                   && password.equalsIgnoreCase(c.getPassword())
                ;
        } else {
            return false;
        }
    }

    public boolean isBroadcast() {
        return broadcast;
    }

    public void setBroadcast(boolean broadcast) {
        this.broadcast = broadcast;
    }

    public ConnectionProps copy() {
        ConnectionProps result = new ConnectionProps();
        result.setAcknowledgeMode(getAcknowledgeMode());
        result.setnThreads(getnThreads());
        result.setPassword(getPassword());
        result.setSubject(getSubject());
        result.setTimeOut(getTimeOut());
        result.setTransacted(transacted);
        result.setUrl(getUrl());
        result.setUser(getUser());
        result.setBroadcast(isBroadcast());

        return result;
    }
}
