package com.navi.core.jms;

import javax.jms.*;
import javax.jms.Connection;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.commons.pool.BasePoolableObjectFactory;
import org.apache.commons.pool.impl.GenericObjectPool;
import org.apache.log4j.Logger;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * JMS Receiver. implement connect and default onMessage
 *
 * @author <a href="mailto:basil.belokon@gmail">Vasily Belokon</a>
 * @version 1.0
 */
public class Receiver {

    private final Logger log = Logger.getLogger(Receiver.class);

    private ConnectionProps connectionProps;

    ExecutorService service;
    private GenericObjectPool<PooledMessageReceiver> receiverPool;

    private MessageListener messageListener;

    private Boolean shutdown = false;

    private Destination destination;

    public Destination getDestination() {
        return destination;
    }

    public Receiver(ConnectionProps connectionProps, MessageListener messageListener) {
        this.connectionProps = connectionProps;
        this.messageListener = messageListener;
        receiverPool = new GenericObjectPool<PooledMessageReceiver>(new ProducerFactory(), connectionProps.getnThreads());
        service = Executors.newFixedThreadPool(connectionProps.getnThreads());

    }

    public void start() {
        int i = connectionProps.getnThreads();
        while (i > 0) {
            try {
                PooledMessageReceiver receiver =  receiverPool.borrowObject();
                receiver.start();
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
            i--;
        }
    }

    public void stop() {
        try {
            synchronized (shutdown) {
                shutdown = true;
            }
            receiverPool.close();
            service.shutdown();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    class PooledMessageReceiver {

        private Connection connection;

        private  MessageConsumer consumer;


        private Session session;
        private void connect() {
            ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory(connectionProps.getUser(), connectionProps.getPassword(), connectionProps.getUrl());
            try {
                connection = connectionFactory.createConnection();
                connection.start();
                session = connection.createSession(connectionProps.isTransacted(), connectionProps.getAcknowledgeMode());

                connection.setExceptionListener(
                        new ExceptionListener() {
                            @Override
                            public void onException(JMSException exception) {
                                log.error(exception.getMessage(), exception);
                            }
                        }

                );
                connection.start();

                destination = session.createQueue(connectionProps.getSubject());
                consumer = session.createConsumer(destination);
            } catch (JMSException e) {
                log.error(e.toString(), e);
            }

        }

        private void disconnect() {
            try {
                consumer.close();
                session.close();
                connection.close();
            }
            catch (JMSException e) {
                log.error(e.toString(), e);
            }
        }
        private void reconnect() {
            disconnect();
            connect();
        }
        public void start()  {
            connect();
            service.submit(new Runnable() {

                public void run() {
                    while (!shutdown) {
                        Message message;
                        try {
                            message = consumer.receive(connectionProps.getTimeOut());
                            if (message != null ) {
                                log.debug("[" + connectionProps.getSubject() + "] receive message " + message.getJMSMessageID
                                        ());
                                try {
                                    messageListener.onMessage(message);
                                } catch (Exception e) {
                                    log.error(e.getMessage(), e);
                                }

                            }
                        }
                        catch (JMSException e) {
                            log.error(e.getMessage(), e);
                            reconnect();
                        }
                    }
                    close();

                }
            });

        }

        public void close() {
            disconnect();
        }

    }

    class ProducerFactory extends BasePoolableObjectFactory<PooledMessageReceiver> {
        public PooledMessageReceiver makeObject() {
            return new PooledMessageReceiver();
        }


        @Override
        public void destroyObject(PooledMessageReceiver obj) throws Exception {
            obj.close();
        }
    }
}
