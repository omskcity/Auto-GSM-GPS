package com.navi.core.client.messages.toClient;


public class ConnectMessage extends FromDeviceMessage {
    private Boolean online;

    public Boolean getOnline() {
        return online;
    }

    public void setOnline(final Boolean online) {
        this.online = online;
    }
}
