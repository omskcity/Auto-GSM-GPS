package com.navi.core.client.messages;

public abstract class ClientRequestMessage extends FromClientMessage {

}
