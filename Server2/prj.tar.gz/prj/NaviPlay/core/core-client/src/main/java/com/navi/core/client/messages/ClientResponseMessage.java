package com.navi.core.client.messages;

public abstract class ClientResponseMessage extends ToClientMessage {

}
