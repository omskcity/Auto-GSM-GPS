package com.navi.core.client.messages;

import com.navi.core.client.messages.FromClientMessage;

public class GetActiveDevices extends FromClientMessage  {


    @Override
    public String toString() {
        return this.getClass().getName() + "{" +
                '}';
    }
}
