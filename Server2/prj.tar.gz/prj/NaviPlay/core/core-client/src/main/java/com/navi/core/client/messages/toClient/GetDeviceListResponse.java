package com.navi.core.client.messages.toClient;

import com.navi.core.client.messages.ClientResponseMessage;
import com.navi.core.client.DeviceStatus;

import java.util.List;

public class GetDeviceListResponse extends ClientResponseMessage {

    private List<DeviceStatus> data;

    public List<DeviceStatus> getData() {
        return data;
    }

    public void setData(List<DeviceStatus> data) {
        this.data = data;
    }
}
