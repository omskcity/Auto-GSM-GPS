package com.navi.core.client;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Class .
 *
 * @author <a href="mailto:vbelokon@luxoft.com">Vasily Belokon</a>
 * @version 1.0
 */
public class DeviceStatus implements Serializable {

    private Integer deviceNumber;

    private Boolean online = false;
    private Boolean alarm = false;
    private Boolean engineOn = false;
    private Date lastChange;
    private Coordinate coordinate;
    private Set<AlarmType> alarms = new HashSet<AlarmType>();



    public Integer getDeviceNumber() {
        return deviceNumber;
    }

    public void setDeviceNumber(final Integer deviceNumber) {
        this.deviceNumber = deviceNumber;
    }

    public Boolean getOnline() {
        return online;
    }

    public void setOnline(final Boolean online) {
        this.online = online;
    }

    public Boolean getAlarm() {
        return alarm;
    }

    public void setAlarm(final Boolean alarm) {
        this.alarm = alarm;
    }

    public Boolean getEngineOn() {
        return engineOn;
    }

    public void setEngineOn(final Boolean engineOn) {
        this.engineOn = engineOn;
    }

    public Date getLastChange() {
        return lastChange;
    }

    public void setLastChange(final Date lastChange) {
        this.lastChange = lastChange;
    }

    public void addAlarm(AlarmType alarmType) {
        alarms.add(alarmType);
    }
    public void removeAlarm(AlarmType alarmType) {
        alarms.remove(alarmType);
    }

    public void cleanAlarm() {
        alarms.clear();
    }

    public List<AlarmType> getAlarms() {
        List<AlarmType> result = new ArrayList<AlarmType>();
        result.addAll(alarms);
        return result;
    }

    public Coordinate getCoordinate() {
        return coordinate;
    }

    public void setCoordinate(final Coordinate coordinate) {
        this.coordinate = coordinate;
    }
}
