package com.navi.core.client;

import java.io.Serializable;

public class Coordinate implements Serializable {

    private Long longitude;

    private Long latitude;

    private Integer height = 0;

    public Coordinate(Long latitude, Long longitude, Integer height) {
        this.longitude = longitude;
        this.latitude = latitude;
        this.height = height;
    }

    public Long getLongitude() {
        return longitude;
    }

    public void setLongitude(Long longitude) {
        this.longitude = longitude;
    }

    public Long getLatitude() {
        return latitude;
    }

    public void setLatitude(Long latitude) {
        this.latitude = latitude;
    }

    public Integer getHeight() {
        return height;
    }

    public void setHeight(Integer height) {
        this.height = height;
    }

    public String getCoordinateAsString() {
        String s;
        if (latitude != null) {
            Double f = latitude * 0.000001;
            s = f.toString();
        } else {
            s = "null";
        }

        s =s+", ";
        if (longitude != null) {
            Double f = longitude * 0.000001;
            s = s+f.toString();

        } else {
            s = s + "null";
        }
        return s;

    }

    @Override
    public String toString() {
        if (height == null) {
            return "Coordinate{" +
                    getCoordinateAsString() +
                    ", height=null" +
                    '}';

        } else {
            return "Coordinate{" +
                    getCoordinateAsString() +
                    ", height=" + height +
                    '}';
        }
    }
}
