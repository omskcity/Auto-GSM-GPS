package com.navi.core.client.messages.toClient;


import java.util.HashSet;
import java.util.Set;
import com.navi.core.client.AlarmType;

public class AlarmMessage extends FromDeviceMessage {

    private Set<AlarmType> alarmSources = new HashSet<AlarmType>();


    public Set<AlarmType> getAlarmSources() {
        return alarmSources;
    }

    public void setAlarmSources(final Set<AlarmType> alarmSources) {
        this.alarmSources = alarmSources;
    }
}
