package com.navi.core.client.messages.toClient;

import com.navi.core.client.messages.ToClientMessage;

public abstract class FromDeviceMessage extends ToClientMessage {
    private Integer deviceNum;

    public Integer getDeviceNum() {
        return deviceNum;
    }

    public void setDeviceNum(Integer deviceNum) {
        this.deviceNum = deviceNum;
    }

}
