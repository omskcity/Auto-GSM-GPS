package com.navi.core.client.messages;

import java.io.Serializable;

public abstract class ClientMessage implements Serializable {

}
