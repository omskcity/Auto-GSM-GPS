package com.navi.core.client.messages;

import com.navi.core.client.messages.ClientRequestMessage;

public class GetDeviceListRequest extends ClientRequestMessage {

}
