package com.navi.core.client.messages.toDevice;


public class AlarmOnRequest extends ToDeviceRequest {


    @Override
    public String toString() {
        return "AlarmOnRequest{" +
                "deviceNum=" + getDeviceNum() +
                '}';
    }
}
