package com.navi.core.client.messages.toDevice;

import com.navi.core.client.messages.FromClientMessage;

public abstract class ToDeviceRequest extends FromClientMessage {
    private Integer deviceNum;

    public Integer getDeviceNum() {
        return deviceNum;
    }

    public void setDeviceNum(Integer deviceNum) {
        this.deviceNum = deviceNum;
    }

}
