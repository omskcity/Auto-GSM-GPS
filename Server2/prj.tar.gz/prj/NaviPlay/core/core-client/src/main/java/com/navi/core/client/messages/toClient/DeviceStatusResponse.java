package com.navi.core.client.messages.toClient;


public class DeviceStatusResponse extends FromDeviceMessage {

    private Boolean isAlarm;
    private Boolean lowVoltage;

    public Boolean getAlarm() {
        return isAlarm;
    }

    public void setAlarm(Boolean alarm) {
        isAlarm = alarm;
    }

    public Boolean getLowVoltage() {
        return lowVoltage;
    }

    public void setLowVoltage(final Boolean lowVoltage) {
        this.lowVoltage = lowVoltage;
    }
}
