package com.navi.core.client.messages.toClient;



public class AlarmStatusMessage extends FromDeviceMessage {

    private boolean status = false;

    public boolean isStatus() {
        return status;
    }

    public void setStatus(final boolean status) {
        this.status = status;
    }
}
