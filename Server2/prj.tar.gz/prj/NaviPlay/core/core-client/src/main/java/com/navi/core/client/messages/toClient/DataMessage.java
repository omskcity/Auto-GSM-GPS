package com.navi.core.client.messages.toClient;

import com.navi.core.client.Coordinate;

import java.util.Date;

public class DataMessage extends FromDeviceMessage {

    private Date date;

    private Coordinate coordinate;

    private Integer speed;

    private Boolean isMove;

    private Boolean isAlarm;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Coordinate getCoordinate() {
        return coordinate;
    }

    public void setCoordinate(Coordinate coordinate) {
        this.coordinate = coordinate;
    }

    public Integer getSpeed() {
        return speed;
    }

    public void setSpeed(Integer speed) {
        this.speed = speed;
    }

    public Boolean getMove() {
        return isMove;
    }

    public void setMove(Boolean move) {
        isMove = move;
    }

    public Boolean getAlarm() {
        return isAlarm;
    }

    public void setAlarm(Boolean alarm) {
        isAlarm = alarm;
    }

}
