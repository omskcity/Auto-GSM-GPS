package com.navi.core.client.messages.toDevice;

public class DeviceStatusRequest extends ToDeviceRequest {


    @Override
    public String toString() {
        return "DeviceStatusRequest{" +
                "deviceNum=" + getDeviceNum() +
                '}';
    }
}
