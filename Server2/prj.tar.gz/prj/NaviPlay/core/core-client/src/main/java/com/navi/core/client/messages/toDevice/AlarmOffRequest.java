    package com.navi.core.client.messages.toDevice;

public class AlarmOffRequest extends ToDeviceRequest {

    @Override
    public String toString() {
        return "AlarmOffRequest{" +
                "deviceNum=" + getDeviceNum() +
                '}';
    }
}
