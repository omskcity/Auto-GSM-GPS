package com.navi.core.client.messages.toClient;

import com.navi.core.client.messages.ClientResponseMessage;

public class GetDeviceStatusResponse extends ClientResponseMessage {

    private Integer deviceNumber;
    private Integer firmware;
    private Integer protocolType;
    private Integer status;
    private Integer internalVoltage;
    private Integer externalVoltage;
    private Integer temp;
    private Integer levelGSM;

    private Boolean lowVoltage;
    private Boolean isMove;
    private Boolean isAlarm;
    private Boolean isActiveGSM1;
    private Boolean isActiveGSM2;
    private Boolean problemGPRS;
    private Boolean problemGPS;

}
