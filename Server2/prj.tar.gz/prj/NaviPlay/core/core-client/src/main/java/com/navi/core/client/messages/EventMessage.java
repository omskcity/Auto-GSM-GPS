package com.navi.core.client.messages;

import com.navi.core.client.messages.toClient.FromDeviceMessage;

public class EventMessage extends FromDeviceMessage {

    private Integer  eventType;

    public Integer getEventType() {
        return eventType;
    }

    public void setEventType(Integer eventType) {
        this.eventType = eventType;
    }
}
