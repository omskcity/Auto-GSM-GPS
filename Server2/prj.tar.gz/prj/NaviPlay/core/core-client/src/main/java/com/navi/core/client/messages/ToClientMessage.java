package com.navi.core.client.messages;

public abstract class ToClientMessage extends ClientMessage  {

}
