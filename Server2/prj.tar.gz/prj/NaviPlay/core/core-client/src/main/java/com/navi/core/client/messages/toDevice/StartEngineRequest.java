package com.navi.core.client.messages.toDevice;

public class StartEngineRequest extends ToDeviceRequest {

    @Override
    public String toString() {
        return "StartEngineRequest{" +
                "deviceNum=" + getDeviceNum() +
                '}';
    }
}
