package com.navi.core.client;

/**
 * Type alarm type for client.
 *
 * @author <a href="mailto:vbelokon@luxoft.com">Vasily Belokon</a>
 * @version 1.0
 */
public enum AlarmType {
    LOW_EXTERNAL_VOLTAGE,
    MOVE_SENSOR

}
