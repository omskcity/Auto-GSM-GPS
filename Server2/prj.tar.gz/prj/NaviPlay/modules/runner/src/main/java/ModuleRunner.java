import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class ModuleRunner {



    public static void main(String[] args) {
        final Logger log = Logger.getLogger("main");
        if (args.length > 0) {
            for (String arg : args) {
                log.info("Load context " + arg + "Context.xml");
                new ClassPathXmlApplicationContext(arg + "Context.xml");
            }

        } else {
            log.warn("need arguments list of modules for start");
        }


    }
}