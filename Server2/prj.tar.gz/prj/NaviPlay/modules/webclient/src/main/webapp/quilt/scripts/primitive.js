function nvl(str1, str2) {
    if (hasStrValue(str1)) {
        return str1;
    } else {
        return str2;
    }
}
function hasValue(data) {
    return data != undefined && data != null;
}
function reslaceAll(source, from ,to) {
    var patern =  new RegExp(from.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&"), 'g');
    if (!hasStrValue(source)) {
        return source;
    }
    return source.replace(patern, to);
}

function reslaceAllIgnoreCase(source, from ,to) {
    var patern =  new RegExp(from.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&"), 'gi');
    if (!hasStrValue(source)) {
        return source;
    }
    return source.replace(patern, to);
}

function hasStrValue(str) {
    return hasValue(str) && str != '';
}

function isTrue(str) {
    return hasStrValue(str) && (
            str == true ||
            strEqualsIgnoreCase(str, 'true') ||
            strEqualsIgnoreCase(str, 'yes') ||
            strEqualsIgnoreCase(str, 'on') ||
            strEqualsIgnoreCase(str, '1')
            );
}

function strEquals(str1 ,str2) {
    return hasStrValue(str1) && hasStrValue(str2) && str1 == str2;
}


function strStartWith(str , needle){
    return str.substr( 0, needle.length ) == needle;

}

function strEqualsIgnoreCase(str1 ,str2) {
    return hasStrValue(str1) && hasStrValue(str2) && str1.toString().toLowerCase() == str2.toString().toLowerCase();
}

