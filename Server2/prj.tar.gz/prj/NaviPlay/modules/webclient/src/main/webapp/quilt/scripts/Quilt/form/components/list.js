Ext.require([
    'Ext.data.*',
    'Ext.grid.*',
    'Ext.panel.Panel'
]);

function QComponentList (dialog, prm) {

    var _init_prm = prm;
    var _dialog = dialog;
    var _id = _init_prm.valueStr(PRM_DLG_COMPONENT_ID);
    var _url = _init_prm.valueStr(PRM_DLG_URL);
    var _listData;
    var _columnList;
    var _component;
    var _button_panel;
    var _extDataModel;
    var _extDataStore;
    var _grid;
    var _grid_key_binding;
    var _width = 0 + _init_prm.valueStr(PRM_DLG_COMPONENT_WIDTH);
    var _height = 0 + _init_prm.valueStr(PRM_DLG_COMPONENT_HEIGHT);
    var _height_diff = 25;
    var _width_diff = 10;

    this.component = function() {
        return _component;
    };

    function QListToolbarBtn(title, executor, icon) {
        var _btn;
        var _for_selection;
        var _handler;

        this.for_selection = function (value) {
            if (value == undefined) {
                return _for_selection;
            } else {
                _for_selection = value;
            }
            return true;
        };

        this.executor = function(value) {
            if (value != undefined) {
                _handler = value;
                _btn.setHandler(value);
            } else {
                return _handler;
            }
            return true;
        };

        this.extBtn = function() {
            return _btn;
        };

        this.label = function(value) {
            if (value == undefined) {
                return _btn.getText();
            } else {
                _btn.setText(value);
            }
            return true;
        };

        this.icon = function(value) {
            if (value == undefined) {
                return 'def';
            } else {
            }
            return true;
        };

        this.disable = function() {
            _btn.setDisabled(true);
        };

        this.enable = function() {
            _btn.setDisabled(false);
        };

        var create  = function(title, executor /*, icon*/) {
            _btn = Ext.create('Ext.Button', {
                text    : title,
                handler : executor
            });
        };

        create(title, executor, icon);


    }

    function QListToolbar() {
        var _toolbar;
        var _btns = [];

        this.add = function(btn) {
            _btns.push(btn);
            _toolbar.add(btn.extBtn());
        };

        this.calcBtnEnable = function () {
            var s = _grid.getSelectionModel().getSelection();
            jQuery.each(_btns, function(i, btn) {
                try {

                    //console.log('btn ' + btn.label() + ' ' +btn.for_selection());
                    if (isTrue(btn.for_selection())) {
                        //console.log('for_selection');
                       if (s.length > 0) {
                           btn.enable();
                       } else {
                           btn.disable();
                       }
                    } else {
                        //console.log('not for_selection');
                        btn.enable();
                    }
                } catch (ex) {
                    //console.log(ex);
                }
            });
        };

        this.getMenuItems = function () {
            var s = _grid.getSelectionModel().getSelection();
            var  result = [{
                text: "Обновить",
                handler: refreshList
                }/*,{
                "На печать"

            }*/, {
                xtype: 'menuseparator'
            }];

            jQuery.each(_btns, function(i, btn) {
                try {
                    var active = false;
                    //console.log('btn ' + btn.label() + ' ' +btn.for_selection());
                    if (isTrue(btn.for_selection())) {
                        //console.log('for_selection');
                        active = s.length > 0;
                    } else {
                        active = true;
                    }
                    if (active) {
                        result.push({
                            text: btn.label(),
                            handler: btn.executor()
                        });
                    }
                } catch (ex) {
                    //console.log(ex);
                }
            });
            return result;
        };

        var create = function () {
            _toolbar = new Ext.toolbar.Toolbar({anchor :'100%' });
            var btn = new QListToolbarBtn();
            btn.label("Обновить");
            btn.executor(refreshList);
            btn.icon("ui-icon-refresh");
            _toolbar.add(btn.extBtn());
/*            btn = new  QListToolbarBtn();
            btn.label("На печать");
            btn.executor(null);
            btn.icon("ui-icon-print");
            _toolbar.add(btn.extBtn());*/
            _toolbar.add(new Ext.toolbar.Separator());

            _component.add(_toolbar);
        };
        create();

    }

    this.id = function () {
        return _id;
    };

    this.bindValue2Data = function() {
    };

    this.bindData2Value = function() {
    };

    this.clear = function() {
    };
    this.focus = function() {
        tableFocus();
    };

    this.componentWidth = function() {
        return _component.getWidth();
    };

    var create = function (object_params) {
        _component = Ext.create('Ext.panel.Panel', {
            title: object_params.valueStr(PRM_DLG_COMPONENT_LABEL),
            width: _width,
            height: _height,
            minWidth: _width,
            minHeight: _height,
            maxHeight: _height,
            layout: 'anchor'
        });

        _button_panel = new QListToolbar();

        initColumnList();
        _extDataModel = Ext.define(_dialog.name() + '_data_model',{
            extend: 'Ext.data.Model',
            fields: []
        });

        _extDataStore = Ext.create('Ext.data.Store', {
            model: _dialog.name() + '_data_model',
            autoLoad: true,
            data : new QNode(),
            proxy: {
                // load using HTTP
                type: 'memory',
                // the return will be XML, so lets set up a reader
                reader: {
                    type: 'qnode'
                }
            }
        });
        _grid = Ext.create('Ext.grid.Panel', {
            store: _extDataStore,
            stateful: true,
            collapsible: false,
            multiSelect: true,
            stateId: 'stateGrid',
            columns: getPreparedColumns(),
//                    title: 'Array Grid',
//                    renderTo: 'grid-example',
            viewConfig: {
                stripeRows: true,
                enableTextSelection: false
            },
            listeners: {
                beforeitemcontextmenu: function(view, record, item, index, e)
                {
                    e.stopEvent();
                    var menu = Ext.create('Ext.menu.Menu', {
                        items : _button_panel.getMenuItems()
                    });
                    menu.showAt(e.getXY());
                }
            },
            width: _width - _width_diff,
            height: _height - _height_diff,
            minWidth: _width - _width_diff,
            minHeight: _height - _height_diff,
            maxHeight: _height - _height_diff,
            anchor :'100% 100%'

        });
        _grid_key_binding = new Ext.util.KeyMap({
            target: _grid.view,
            eventName: 'itemkeydown',
            processEvent: function(view, record, node, index, event) {
                // Load the event with the extra information needed by the mappings
                event.view = view;
                event.store = view.getStore();
                event.record = record;
                event.index = index;
                return event;
            },
            binding: [{
                key: Ext.EventObject.F2,
                fn: _dialog.keydown
                      }]
        });
        prepareButtons();
        _component.add(_grid);

        _dialog.addOnShowEvent(function () {
            fillList();
        });
    };

    var getPreparedColumns = function () {
        var aoColumns = [];
        jQuery.each(_columnList.asArrayValue(), function(i, val) {
            var aoColumn = {
                text     : val.valueStr('title'),
                flex     : 0,
                sortable : false,
                width : val.valueStr('width'),
                dataIndex: val.valueStr('field')
            };
            aoColumns.push(aoColumn);
            var as_icon = val.valueStr('as_icon');
            if (!hasStrValue(val.valueStr('width'))) {
                aoColumn.flex = 1;
            }
            if (isTrue(as_icon)) {
                aoColumn['renderer'] = function ( data) {
                    return '<span class="ui-button-icon-primary ui-icon ' + data + '"></span>';
                };
            }
        });
        return aoColumns;
    };

    var fetchData = function (callback) {
        var script = _init_prm.valueStr('script');
        var script_param = _init_prm.valueStr('script_param');
        script = _dialog.replaceParam(script);
        script_param = _dialog.replaceParam(script_param);

        var data = new QNode('<script_param>' +script_param + '</script_param>');
        get_xml_data({
            object: script,
            data:  data,
            url: nvl(_url, DATA_DEFAULT_URL),
            ok_callback: function (data) {
                _listData = data;
                prepareDataModel();
                prepareDataStore();
                callback();
            },
            error_callback: function (data) {
                showError('Ошибка получения данных для списка по скрипту', data);
            }

        });
    };

    var initColumnList = function () {
        _columnList = _init_prm.value('columns');
        if (_listData instanceof QNode) {
            if (!hasValue(_columnList)) {
                _columnList = new QNode();
                var row0 = _listData.asArrayValue()[0];
                jQuery.each(row0.asArrayValue(), function(i, field) {
                    var col = new QNode();
                    col.name('col');
                    col.value('title', field.name());
                    col.value('field', field.name());
                    col.value('type', 'string');
                    _columnList.add(col);
                });
            }
        }
    };
    var fillList = function () {
        fetchData(function () {
            if (_listData instanceof QNode) {
                _grid.getSelectionModel().on('selectionchange', function() {
                    _button_panel.calcBtnEnable();
                });
                _button_panel.calcBtnEnable();


            }
        });
    };

    var tableFocus = function () {
        console.log('tableFocus');
//        _grid.focus(false, 10);
        _grid.getSelectionModel().select(0);
        _grid.getView().focus(false, 10);
    };

    var refreshList = function () {
        fetchData(function () {
            tableFocus();
        });
    };

    var prepareDataModel = function () {
        var fields = getListDataRowColumns();
        _extDataModel.setFields(fields, _dialog.name() + '_data_model');
    };

    var prepareDataStore = function () {
        if (!hasValue(_extDataStore)) {
        } else {
            _extDataStore.setProxy(new Ext.data.proxy.Memory({
                data : _listData,
                reader: {
                    type: 'qnode'
                }
            }));
            _extDataStore.load();
        }
    };

    var getListDataRowColumns = function () {
        var result = [];
        if (_listData instanceof QNode) {
            var rows =  _listData.asArrayValue();
            if (rows.length > 0) {
                var row = rows[0];
                if (row instanceof QNode) {
                    jQuery.each(row.asArrayValue(), function(i, val) {
                        result.push(val.name());
                    });
                    result.push('_row');
                }

            }
        }
        return result;
    };

    var commandResult = function (result) {
        console.log('on command result' + result);
        if (isTrue(result)) {
            refreshList();
        }
        _grid.getView().focus(false, 100);
    };

    var prepareButtons = function () {

        var cmds = _init_prm.value('commands');
        if (_init_prm instanceof QNode) {

            jQuery.each(cmds.asArrayValue(), function(i, cmd) {
                if (cmd instanceof QNode) {

                    var btn = new  QListToolbarBtn();
                    btn.label(cmd.valueStr('title'));
                    btn.icon(cmd.valueStr('icon'));
                    var for_action = cmd.valueStr('for_action');
                    var executor;
                    if (hasStrValue(cmd.valueStr('command'))) {
                        executor = function () {
                            var str = cmd.valueStr('command');
                            var selected = _grid.getSelectionModel().getSelection();
                            var curr_row;
                            if (selected.length > 0) {
                                var f = selected[0];
                                curr_row = f.get('_row');
                            }
                            str = strReplaceWrap(str, curr_row , '#');
                            str = _dialog.replaceParam(str);
                            executeCommandList(str, commandResult);
                        };
                    }
                    btn.for_selection(isTrue(cmd.valueStr('for_selection')) ||strEqualsIgnoreCase(cmd.valueStr('for_selection'), 'single'));

                    btn.executor( executor);
                    _button_panel.add(btn);
                    if (isTrue(for_action)) {
                        _grid_key_binding.addBinding({
                             key: Ext.EventObject.ENTER,
                             fn: executor,
                             scope: this
                        });
                    }
                    if (hasStrValue(cmd.valueStr('key'))) {
                        var binding = util.getBindingByStr(cmd.valueStr('key'));
                        binding.fn = executor;
                        binding.scope = this;
                        _grid_key_binding.addBinding(binding);
                    }
                }
            });
        }
    };

    var executeCommandList = function (cmd, callback) {
        executeCommand(cmd, callback);
    };

    create(prm);

}
