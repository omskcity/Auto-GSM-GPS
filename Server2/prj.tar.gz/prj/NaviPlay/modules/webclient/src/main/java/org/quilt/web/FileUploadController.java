/**
 * This code contains copyright information which is the proprietary property
 * of SITA Information Network Computing Limited (SITA). No part of this
 * code may be reproduced, stored or transmitted in any form without the prior
 * written permission of SITA.
 *
 * Copyright (C) SITA Information Network Computing Limited 2009-2012.
 * All rights reserved.
 */
package org.quilt.web;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.util.List;

/**
 * File uploading implementation.
 *
 * @author <a href="mailto:vbelokon@luxoft.com">Vasily Belokon</a>
 * @version 1.0
 */
public class FileUploadController implements Controller {
    @Override
    public ModelAndView handleRequest(final HttpServletRequest request, final HttpServletResponse response)
        throws Exception {

        // Create a factory for disk-based file items
        DiskFileItemFactory factory = new DiskFileItemFactory();

        // Set factory constraints
//        factory.setSizeThreshold(yourMaxMemorySize);
//        factory.setRepository(yourTempDirectory);

        // Create a new file upload handler
        ServletFileUpload upload = new ServletFileUpload(factory);

        // Set overall request size constraint
//        upload.setSizeMax(yourMaxRequestSize);

        // Parse the request
        List /* FileItem */ items = upload.parseRequest(request);
        String folder = "";
        for (final Object item1 : items) {
            FileItem item = (FileItem) item1;

            if (item.isFormField()) {
                String name = item.getFieldName();
                String value = item.getString();
                if ("folder".equalsIgnoreCase(name)) {
                    folder = value;
                }

            }
        }
        File parent = new File("/tmp" + File.separator + folder + File.separator);
        parent.mkdirs();
        for (final Object item1 : items) {
            FileItem item = (FileItem) item1;
            if (!item.isFormField()) {
                //                String fieldName = item.getFieldName();
                String fileName = item.getName();
                //                String contentType = item.getContentType();
                //                boolean isInMemory = item.isInMemory();
                //                long sizeInBytes = item.getSize();
                File uploadedFile = new File(parent, fileName);
                item.write(uploadedFile);
            }
        }

        return null;
    }
}
