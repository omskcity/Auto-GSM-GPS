package org.quilt.dao;


import java.util.EnumSet;

public enum DAOExceptionType {

    DataUnknownException("DataUnknownException", "Некласифицированная ошибка данных"),
    DataIntegrityViolationException("DataIntegrityViolationException", "Существует связанная информация"),
    DataSourceLookupFailureException("DataSourceLookupFailureException", "Отсутствует соединение с базой данных");

    private String code;
    private String message;

    DAOExceptionType(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public String getCode() {
        return code;
    }

    public static DAOExceptionType getByCode(String code){
        DAOExceptionType returnValue = null;
        for (final DAOExceptionType element : EnumSet.allOf(DAOExceptionType.class)) {
            if (element.getCode().equals(code)) {
                returnValue = element;
            }
        }
        return returnValue;
    }

}
