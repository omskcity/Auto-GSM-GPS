
function showMessage(message ,callback) {
    Ext.MessageBox.show({
        title: 'Внимание',
        msg: message,
        buttons: Ext.MessageBox.OK,
//        animateTarget: 'mb9',
        fn: callback,
        icon: 'x-message-box-info'
    });
}

function showError(message, data, callback) {
    var strMsg = message;
    if (hasValue(data)) {
        if (data instanceof QNode ) {
            var str = '<div id="error-description">';
            jQuery.each(data.asArrayValue(), function(i, val) {
                var code = val.valueStr('code');
                var message = val.valueStr('message');
                var detail = val.valueStr('detail');
                str = str +  '<div><p>';
                if (hasStrValue(code)) {
                    str = str + code + ' : ';
                }
                if (hasStrValue(message)) {
                    str = str + message ;
                }
                str = str + '</p></div>';
                if (hasStrValue(detail)) {
                    str = str + '<div><p>' + detail+ '</p></div>' ;
                }
            });
            str = str + '</div>';
            strMsg = str;
            //_err_div.accordion();
//            _err_div.height(_err_div.height() + 100);
        } else {
//            dialog.html(message);
        }

    } else {
//        dialog.html(message);
    }

    Ext.MessageBox.show({
        title: 'Ошибка',
        msg: message,
        buttons: Ext.MessageBox.OK,
//        animateTarget: 'mb9',
        fn: callback,
        icon: 'x-message-box-error'
    });

}