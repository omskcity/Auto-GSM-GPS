var progress_div;

function hideInProgress() {
    if (hasValue(progress_div)) {
        progress_div.hide();
    }

}

function showInProgress() {
    if (!hasValue(progress_div)) {
        progress_div = $('<div class="in_progress" style="display: none">Идет загрузка данных</div>' ).appendTo("#art-main");
    }
    progress_div.show();

}


function loadData(url, data) {
    showInProgress();
//    var mainContent = $.find('#main-content');
//    var options = { percent: 0 };
//    $(mainContent).hide('blind', options, 1000);
    try {
    q_ajax({
               url: url,
               data: data,
               ok_callback : function(html) {
                   var mainContent = $.find('#main-content');
                   $(mainContent ).html(html);
                   hideInProgress();
                   describe_dishs();
               },
               error_callback: function() {
                   hideInProgress();
                   showError('Ошибка получения данных из '+url);
               }

           });

    } catch (Exception) {

    }
}

function _execUrl(url) {
    var str;
    if (url instanceof Object) {
        str = url.href;
    } else {
        str = url;
    }
    var parts = str.split('?');
    var url_new;
    if (parts.length < 2) {
        url_new = '';
    } else {
        var param_Str = parts[1];
        var params = nvl(param_Str,'').split('&');
        var param1 = nvl(params[0],'');
        url_new = param1.split('=')[1];
    }
    // url_new = nvl(url_new, 'user-menu.php');
    if (hasStrValue(url_new)) {
        loadData(url_new, nvl(param_Str,''));
    }

}

function showDialog(dlg_name, callback) {
    var str = '<dlg>'
                      + '<name>' + dlg_name + '</name>'
                      + '<operation>edit</operation>'
            + ' </dlg> ';
    executeCommand(str, callback);
}

function showList(dlg_name, callback) {
    var str = '<dlg>'
                      + '<name>' + dlg_name + '</name>'
                      + '<operation>show</operation>'
            + ' </dlg> ';
    executeCommand(str, callback);
}

function execUrl(url) {
    _execUrl(url);
    history.pushState( null, null, url);
}

function execUrlOnStart(url) {
    _execUrl(url);

}