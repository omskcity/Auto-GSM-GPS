function QComponentLabel (dialog, prm) {
    var _dialog = dialog;
    var _component;
    var _label;
    var _value;
    var _id = prm.valueStr(PRM_DLG_COMPONENT_ID);

    this.id = function () {
        return _id;
    };

    this.bindValue2Data = function() {
    };

    this.bindData2Value = function() {
        var str = _dialog.replaceParam(_value);
        _label.text(str);
    };
    this.clear = function() {
    };

    this.componentWidth = function() {
        return _component.width();
    };
    var create = function (object_params) {
        var QNode = [PRM_DLG_COMPONENT_VALUE, PRM_DLG_COMPONENT_WIDTH];
        _value = object_params.valueStr('value');
        var str = '';
        str = str + '<div class="dialog-element">';
        str = str + '<div class="dialog-element-content" style=\"width: ${width}\">';
        str = str + '<label>${value}</label>';
        str = str + '</div>';
        str = str + '</div>';
        jQuery.each(QNode, function(i, val) {
            var param_value = object_params.valueStr(val);
            if (!hasStrValue(param_value)) {
                param_value = '';
            }
            str = str.replace(new RegExp('\\$\\{' + val +'\\}', 'g'), param_value);
        });

        _component = $(str).appendTo(_dialog.getHTMLDiv());
        _label = _component.find('label');
    };

    create(prm);

}
