function QComponentUpload (dialog, prm) {
    var _dialog = dialog;
    var _component;
    var _input;
    var _id = prm.valueStr(PRM_DLG_COMPONENT_ID);
    var _label_div;
    var _label;
    var _value;
    var _based_label_width;

    this.id = function () {
        return _id;
    };

    this.bindValue2Data = function() {
        _dialog.getData().value(_id, _value);
    };

    this.bindData2Value = function() {

        _value = _dialog.getData().valueStr(_id);
        _label.text(_value);
    };

    this.clear = function() {
        _input.val('');
    };

    this.componentWidth = function() {
        return _component.width();
    };

    this.labelWidth = function(pvalue) {
        if (pvalue == undefined) {
            if (hasValue(_label_div)) {
                if (!hasValue(_based_label_width))  {
                    _based_label_width = _label_div.width();
                }
                return _based_label_width;
            }
            return 0;
        } else {
            _label_div.width(pvalue);
            _label_div.height(10);
        }
    };

    var _enabled = !isTrue(prm.valueStr(PRM_DLG_DISABLED));
    this.enabled = function(pvalue) {
        if (pvalue == undefined) {
            return _enabled;
        } else {
            _enabled = pvalue;
            if (_enabled) {
                _input.removeAttr('disabled');
                _component.removeClass('disabled');
            } else {
                _component.addClass('disabled');
                _input.attr('disabled','disabled');
            }
        }
    };

    var create = function (object_params) {
        var QNode = [PRM_DLG_COMPONENT_ID ,PRM_DLG_COMPONENT_LABEL, PRM_DLG_COMPONENT_VALUE, 'spr_name', PRM_DLG_COMPONENT_WIDTH];
        var str = '';
        str = str + '<div class="dialog-element">';
        str = str + '<div>';
        str = str + '<div class="dialog-element-label">';
        str = str + '</div>';
        str = str + '<div class="dialog-element-content">';
        str = str + '<input id="fileupload" type="file" >';
        str = str + '</div>';
        str = str + '<label>${value}</label>';
        str = str + '</div>';
        jQuery.each(QNode, function(i, val) {
            var param_value = object_params.valueStr(val);
            if (!hasStrValue(param_value)) {
                param_value = '';
            }
            str = str.replace(new RegExp('\\$\\{' + val +'\\}', 'g'), param_value);
        });
        _component = $(str).appendTo(_dialog.getHTMLDiv());
        _input = _component.find('input');
        _label_div = _component.find('.dialog-element-label');
        _label = _component.find('label');
        _input.attr('accept', object_params.valueStr('accept'));
        var folderName = object_params.valueStr('folder');

        _input.fileupload({
            url: 'fileupload.do',
            sequentialUploads: true,
            formData: {
                folder: folderName
            }

        });
        _input.bind('fileuploadadd', function (e, data) {
            _value = data.files[0].name;
            _label.text(_value);
        });
    };

    create(prm);

}
