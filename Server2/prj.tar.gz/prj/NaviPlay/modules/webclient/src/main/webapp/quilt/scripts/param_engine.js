function QAttr(arg1, arg2) {
    var _name = undefined;
    var _value = undefined;
    this.name = function(pname) {
        if (pname == undefined) {
            return _name;
        } else {
            _name = pname;
        }
    };

    this.value = function(pvalue) {
        if (pvalue == undefined) {
            return _value;
        } else {
            _value = pvalue;
        }
    };

    this.toString = function () {
        if (hasStrValue(_name)) {
            var tmp_val = _value;
            if (_value == undefined) {
                tmp_val = '';
            }
            return ' ' + _name + '=\"' + tmp_val + '\"';
        }
        return '';
    };

    if (arg2 == undefined) {
        if (arg1 instanceof QAttr) {
            this.name(arg1.name());
            this.value(arg1.value());
        } else if (arg1 instanceof String) {
            this.name(arg1);
        }
    } else {
        this.name(arg1);
        this.value(arg2);
    }


}

function QText (arg) {
    var _value = undefined;
    this.value = function(pvalue) {
        if (pvalue == undefined) {
            return _value;
        } else {
            _value = pvalue;
        }
    };
    this.toString = function () {
        var tmp_val = _value;
        if (_value == undefined) {
            tmp_val = '';
        }
        return  tmp_val;
    };

    if (arg != undefined) {
        _value = arg;
    }
}

function QNode(arg1, arg2) {
    var that = this;
    var _name = '';
    var _attr = new Array();
    var _child = new Array();

    this.toString = function () {
        var hasChild = _child.length > 0;
        var hasAttr = _attr.length > 0;
        var str = '';
        str += '<' + _name;

        if (hasAttr) {
            jQuery.each(_attr, function(i, val) {
                str += val.toString();
            });
        }
        if (hasChild) {
            str += '>';
            jQuery.each(_child, function(i, val) {
                str += val.toString();
            });
        }
        if (hasAttr || hasChild) {
            if (hasChild) {
                str += '</' + _name + '>';
            } else {
                str += '/>';
            }
        } else {
            str += '/>';
        }
        return  str;
    };

    this.getStringValue = function () {
        var hasChild = _child.length > 0;
        var str = '';
        if (hasChild) {
            jQuery.each(_child, function(i, val) {
                str += val.toString();
            });
        } else {
            jQuery.each(_attr, function(i, val) {
                if (strEquals(val.name(),'value')) {
                    str = val.value();
                }
            });

        }
        return  str;
    };

    var _traverse = function (current, parentnode) {
        if (current == null) {
            return;
        }
        var currnode;
        if (!hasValue(parentnode)) {
            currnode = that;
            currnode.name(current.nodeName);
        } else {
            currnode = new QNode();
            currnode.name(current.nodeName);
            parentnode.add(currnode);
        }
        var attr_node;
        var i;
        //Аттрибуты
        if (hasValue(current.attributes) && current.attributes.length > 0 ) {
            for (i =0; i < current.attributes.length; i++) {
                attr_node = current.attributes[i];
                currnode.add(new QAttr(attr_node.nodeName, attr_node.nodeValue));
            }
        }

        var element = current.firstChild;
        var IE='\v'=='v';
        if (IE) {
            if (hasValue(element)) {
                do {
                    if (strEqualsIgnoreCase(element.nodeTypeString, 'text')) {
                        currnode.add(new QText(element.nodeValue));
                    } else {
                        _traverse(element, currnode);
                    }
                    element = element.nextSibling;
                } while (element != null)
            }
        } else {
            if (hasValue(element)) {
                do {
                    if (element instanceof Text) {
                        currnode.add(new QText(element.textContent));
                    } else {
                        _traverse(element, currnode);
                    }
                    element = element.nextSibling;
                } while (element != null)
            }
        }

    };

    var _parseXml = function (xml_str) {
        var xmlDoc;
        var docElement;
        var wrapped_str;
        var IE='\v'=='v';
        if (IE) {
            if (strEqualsIgnoreCase(xml_str.nodeTypeString, 'document')) {
                xmlDoc = xml_str;
                docElement = xmlDoc.documentElement;
            } else {
                if (strStartWith(xml_str,'<?xml')) {
                    wrapped_str = xml_str;
                    xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
                    xmlDoc.async=false;
                    xmlDoc.loadXML(wrapped_str);
                    docElement = xmlDoc.documentElement;
                } else {
                    wrapped_str = '<root>'+xml_str+'</root>';
                    xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
                    xmlDoc.async=false;
                    xmlDoc.loadXML(wrapped_str);
                    docElement = xmlDoc.documentElement.firstChild;
                }
            }
        }
        else {
            var parser = new DOMParser();
            if (xml_str instanceof Object) {
                xmlDoc = xml_str;
                docElement = xmlDoc.documentElement;
            } else {
                if (strStartWith(xml_str,'<?xml')) {
                    wrapped_str = xml_str;
                    xmlDoc=parser.parseFromString(wrapped_str,"text/xml");
                    docElement = xmlDoc.documentElement;
                } else {
                    wrapped_str = '<root>'+xml_str+'</root>';
                    xmlDoc=parser.parseFromString(wrapped_str,"text/xml");
                    docElement = xmlDoc.documentElement.firstElementChild;
                }
            }
        }
       _traverse(docElement);
    };


    this.name = function(pname) {
        if (pname == undefined) {
            return _name;
        } else {
            _name = pname;
        }
    };

    this.value = function(pname, pvalue){
        if (pvalue == undefined) {
            if (pname == undefined) {
                throw Error("Не верное обращение следует использовать value(name) для получения или value(name, value) для установки значения.");
            } else {
                var res = null;
                jQuery.each(_attr, function(i, val) {
                    if (strEquals(val.name(), pname)) {
                        res = val.value();
                    }
                });
                jQuery.each(_child, function(i, val) {
                    if(val instanceof QNode) {
                        if (strEquals(val.name(), pname)) {
                            res = val;
                        }
                    }
                });
                return res;
            }
        } else {
            var need_add;
            if (pvalue instanceof QNode) {
                need_add = true;
                jQuery.each(_child, function(i, val) {
                    if(val instanceof QNode) {
                        if (strEquals(val.name(), pname)) {
                            val.set(pvalue);
                            val.name(pname);
                            need_add = false;
                        }
                    }
                });
                if(need_add) {
                        pvalue.name(pname);
                        _child.push(pvalue);
                }

            } else {
                need_add = true;
                jQuery.each(_attr, function(i, val) {
                    if (strEquals(val.name(), pname)) {
                        val.value(pvalue);
                        need_add = false;
                    }
                });
                jQuery.each(_child, function(i, val) {
                    if(val instanceof QNode) {
                        if (strEquals(val.name(), pname)) {
                            val.clean();
                            val.name(pname);
                            val.add(new QText(pvalue));
                            need_add = false;
                        }
                    }
                });
                if(need_add) {
                    if (!(pvalue instanceof Object)) {
                        _attr.push(new QAttr(pname, pvalue));
                    } else {
                        that.add(new QNode(pname, pvalue));
                    }
                }

            }
        }
    };

    this.valueStr = function(pname){
        if (pname == undefined) {
            throw  new Error("Не верное обращение следует использовать valueStr(name).");
        } else {
            var res = null;
            jQuery.each(_attr, function(i, val) {
                if (strEquals(val.name(), pname)) {
                    res = val.value();
                }
            });
            jQuery.each(_child, function(i, val) {
                if(val instanceof QNode) {
                    if (strEquals(val.name(), pname)) {
                        res = val.getStringValue();
                    }
                }
            });
            return res;

        }
    };

    this.count = function () {
        var cnt = 0;
        jQuery.each(_child, function(i, val) {
            if ( val instanceof QNode) {
                cnt ++;
            }
        });
        return cnt;
    };

    this.empty = function () {
        return that.count() == 0 && _attr.length == 0;
    };


    this.attrArray = function(){
        return _attr;
    };
    this.childArray = function(){
        return _child;
    };

    this.asArrayValue = function(){
        var arr = new Array();
        jQuery.each(_attr, function(i, val) {
            var n = new QNode();
            n.name(val.name());
            n.add(new QText(val.value()));
            arr.push(n);
        });
        jQuery.each(_child, function(i, val) {
            if(val instanceof QNode) {
                arr.push(val);
            }
        });
        return arr;
    };

    /*
    this.asArrayStrValue = function(){
        var arr = new Array();
        jQuery.each(_attr, function(i, val) {
            if (strEquals(val.name(), pname)) {
                arr.push(val.value());
            }
        });
        jQuery.each(_child, function(i, val) {
            if(val instanceof QNode) {
                if (strEquals(val.name(), pname)) {
                    arr.push(val.getStringValue());
                }
            }
        });
        return arr;
    };
    */
    this.merge = function(prm){
        if(prm instanceof QNode) {
            that.name(prm.name());
            jQuery.each(prm.attrArray(), function(i, val) {
                if (val instanceof QAttr) {
                    _attr.push(new QAttr(val));
                }
            });
            jQuery.each(prm.childArray(), function(i, val) {
                that.add(val);
            });
        }
    };

    this.add = function(pname, pvalue){
        if (pname == undefined) {
        } else {
            if (pvalue == undefined) {
                if(pname instanceof QAttr) {
                    _attr.push(pname);
                } else if(pname instanceof QNode) {
                    _child.push(pname);
                } else if(pname instanceof QText) {
                    _child.push(pname);
                } else if(pname instanceof Array) {
                    jQuery.each(pname, function(i, val) {
                        that.add(val);
                    });
                } else {
                    _parseXml(pname);
                }
            } else {
                if (!(pvalue instanceof Object)) {
                    _attr.push(new QAttr(pname, pvalue));
                } else {
                    that.add(new QNode(pname, pvalue));
                }
            }

        }
    };

    this.clean = function(){
        _attr = new Array();
        _child = new Array();
        _name = '';
    };

    this.set= function(pname, pvalue){
        that.clean();
        if (pname == undefined) {
        } else {
            if (pvalue == undefined) {
                if(pname instanceof QNode) {
                    that.name(pname.name());
                    jQuery.each(pname.attrArray(), function(i, val) {
                        if (val instanceof QAttr) {
                            _attr.push(new QAttr(val));
                        }
                    });
                    jQuery.each(pname.childArray(), function(i, val) {
                        that.add(val);
                    });
                } else {
                    _parseXml(pname);
                }
            } else {
                that.name(pname);
                that.add(pvalue);
            }

        }
    };

    if (arg2 == undefined) {
        if (arg1 != undefined) {
            this.set(arg1);
        }
    } else {
        this.set(arg1, arg2);
    }
}
