function QColumn (arg) {
    var _field_name = '';
    var _title = '';
    var _width = '100px';

    this.field = function (val){
        if (val == undefined) {
            return _field_name;
        } else {
            _field_name = val;
        }
    };

    this.title = function (val){
        if (val == undefined) {
            return _title;
        } else {
            _title = val;
        }
    };

    this.width = function (val){
        if (val == undefined) {
            return _width;
        } else {
            _width = val;
        }
    };

    var init =function (arg) {
        if (arg != undefined) {
            if (arg instanceof QNode) {
                _field_name = arg.valueStr('field');
                _title = arg.valueStr('title');
                _width = arg.valueStr('width');
            }
        }
    };

    init(arg)
}

function QTree () {
    var _parent_div;
    var _data;
    var _id_field = 'id';
    var _parent_field = 'parent_id';
    var _on_row_click;
    var _width = 100;
    var _columns = [new QColumn(new QNode(
                            + '<col>'
                            + '<name value="name"/>'
                            + '<title>Название</title>'
                            + '</col>'
            ))];
    var _table;

    this.data = function (val){
        if (val == undefined) {
            return _data;
        } else {
            _data = val;
        }
    };

    this.on_row_click = function (val){
        if (val == undefined) {
            return _on_row_click;
        } else {
            _on_row_click = val;
        }
    };

    this.id_field = function (val){
        if (val == undefined) {
            return _id_field;
        } else {
            _id_field = val;
        }
    };

    this.parent_field = function (val){
        if (val == undefined) {
            return _parent_field;
        } else {
            _parent_field = val;
        }
    };

    this.columns = function (val){
        if (val == undefined) {
            return _columns;
        } else {
            _columns = val;
        }
    };

    this.parent = function (val){
        if (val == undefined) {
            return _parent_div;
        } else {
            _parent_div = val;
        }
    };


    this.show = function (){
        if (hasValue(_table )) {
            _table.remove();
        }
        _table = $('<table>').appendTo(_parent_div);
        _table.addClass("KeyTable");

        var tbody = $('<tbody>').appendTo(_table);
         var thead = $('<thead>').appendTo(_table);
        thead.hide();
         var tr =  $('<tr>').appendTo(thead);
         jQuery.each(_columns, function(i, col) {
            var th = $('<th>'+nvl(col.title(),'') +'</th>').appendTo(tr);
            tr.width(col.width());
         });

        jQuery.each(_data.asArrayValue(), function(i, row) {
            var tr =  $('<tr id=\"' + row.valueStr(_id_field) + '\">').appendTo(tbody);
            if (hasStrValue(_parent_field)) {
                tr.addClass('child-of-' + row.valueStr(_parent_field));
            }
            jQuery.each(_columns, function(i, col) {
                var td = $('<td>'+ row.valueStr(col.field())+'</td>').appendTo(tr);
                td['row'] = row;
            });
            if (hasValue(_on_row_click)) {
                tr.click(function() {
                    if (tr.hasClass("focus"))
                        _on_row_click(row);
                });

            }
        });
        var otable = $(_table).dataTable({
                                             'bRetrieve':true,
                                             'bServerSide':false,
                                             'bStateSave': true,
                                             'bFilter': false,
                                             "sScrollY":  _width + 'px',
                                             "bPaginate": false,
                                             "bSort": false,
                                             'oTableTools': {
                                                 "aButtons": []
                                             }
                                         }

        );
        var keys = new KeyTable({
                                    "table": _table[0],
                                    "datatable": otable

                                });

        keys.event.action( null, null, function( nNode) {
            nNode.parentElement.click();
        } );

        keys.block = true;
        setTimeout(function() {
            keys.block = false;
            keys.fnSetPosition(0,0);
        }, 50);

    };

}