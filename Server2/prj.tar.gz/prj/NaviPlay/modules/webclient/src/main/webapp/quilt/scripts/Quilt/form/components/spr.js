function QComponentSpr (dialog, prm) {
    var that = this;
    var _id = prm.valueStr(PRM_DLG_COMPONENT_ID);
    var _dialog = dialog;
    var _component;
    var _input;
    var _spr_name = prm.valueStr('spr_name');
    var _spr_dialog = null;
    var _need_select = false;
    var _was_changed = false;
    var _text_val;
    var _code;
    var _text;
    var _dropdown_show = false;
    var _based_label_width;
    var _select_window;
    var _extDataStore;
    var _extDataModel;
    var _grid;

    this.id = function () {
        return _id;
    };

    this.bindValue2Data = function() {
        _dialog.getData().value(_id, _code);
    };

    this.bindData2Value = function() {
        value(_dialog.getData().valueStr(_id));
    };

    var value = function (arg) {
        if (arg == undefined) {
            return _code;
        } else {
            _code = arg;
            if (hasStrValue(_code)) {
                get_xml_data({
                    url: SPR_DEFAULT_URL,
                    data: {
                        '@action': 'code',
                        '@spr_name': _spr_name,
                        '@id': _code
                    },
                    ok_callback: function(data) {
                        _text = data.valueStr('value');
                    }
                });
            } else {
                _text = '';
            }
            selectSprValue(_code, _text);
        }
    };

    this.clear = function() {
        value('');
    };

    this.focus = function() {
        _component.focus(true, 10);
    };

    this.labelWidth = function(pvalue) {
        if (pvalue == undefined) {
            if (!hasValue(_based_label_width))  {
                _based_label_width = _component.labelWidth;
            }
            return _based_label_width;
        } else {
            _component.labelWidth = pvalue
        }
    };

    this.componentWidth = function() {
        return _component.getWidth();
    };

    var _enabled = !isTrue(prm.valueStr(PRM_DLG_DISABLED));
    this.enabled = function(pvalue) {
        if (pvalue == undefined) {
            return _enabled;
        } else {
            _enabled = pvalue;
            _component.setDisabled(!_enabled);
        }
    };

    /** not used
     var selectSprValueKey = function (event, code, value) {
        if (event.keyCode == 13) {
            selectSprValue(code,value);
        }
    };
     */

    var selectSprValue = function (code,value){
        _code = code;
        _text = value;
        //_spr_dialog = create_ui_div("spr_dropdown", _spr_name);
        if (_select_window != null) {
            _select_window.hide();
        }
//        _component.select();
//        _component.focus();
        _component.setValue(_text);
        _need_select = false;
        _was_changed = false;

    };

    var getDataRowColumns = function (data) {
        var result = [];
        if (data instanceof QNode) {
            var rows =  data.asArrayValue();
            if (rows.length > 0) {
                var row = rows[0];
                if (row instanceof QNode) {
                    jQuery.each(row.asArrayValue(), function(i, val) {
                        result.push(val.name());
                    });
                }

            }
        }
        return result;
    };
    var selectRow = function(record) {
        var code =  record.get('code');
        selectSprValue(record.get('code'), record.get('value'));
        console.log('select item ' + record.get('code') );
        _was_changed = false;
        _select_window.close();

    };
    var showSprDropDown = function (data) {

        if (hasValue(data)) {
            if (!hasValue(_select_window)) {
                _select_window = Ext.create('Ext.window.Window', {
                    closeAction: 'hide',
                    title: 'Выберите значение',
                    modal: true,
                    width: _component.getWidth(),
                    height: _component.getWidth(),
                    layout: 'fit'
                });
            }
            if (!hasValue(_extDataModel)) {
                _extDataModel = Ext.define('spr_' + _spr_name + '_data_model',{
                    extend: 'Ext.data.Model',
                    fields: getDataRowColumns(data)
                });
            }
            if (!hasValue(_extDataStore)) {
                _extDataStore = Ext.create('Ext.data.Store', {
                    model: 'spr_' + _spr_name + '_data_model',
                    autoLoad: true,
                    data : new QNode(),
                    proxy: {
                        type: 'memory',
                        reader: {
                            type: 'qnode'
                        }
                    }
                });
            }

            _extDataStore.setProxy(new Ext.data.proxy.Memory({
                data : data,
                reader: {
                    type: 'qnode'
                }
            }));
            _extDataStore.load();

            if (!hasValue(_grid)) {
                _grid = Ext.create('Ext.grid.Panel', {
                    store: _extDataStore,
                    stateful: false,
                    focusOnToFront: true,
                    collapsible: false,
                    hideHeaders: true,
                    multiSelect: false,
                    stateId: 'stateGrid'+_spr_name,
                    columns: [
                        {
                            flex     : 1,
                            sortable : false,
                            dataIndex: 'value'
                        }
                    ],
                    //                    title: 'Array Grid',
                    //                    renderTo: 'grid-example',
                    viewConfig: {
                        stripeRows: true,
                        enableTextSelection: false
                    }
                });
                _grid.on('itemdblclick', function (that, record) {
                    selectRow(record);
                });
                _select_window.on('close', function () {
                    if (_was_changed) {
//                        _component.select();
                    }
                });
                _select_window.add(_grid);
            }
            var map = new Ext.util.KeyMap({
                target: _grid.view,
                eventName: 'itemkeydown',
                processEvent: function(view, record, node, index, event) {
                    // Load the event with the extra information needed by the mappings
                    event.view = view;
                    event.store = view.getStore();
                    event.record = record;
                    event.index = index;
                    return event;
                },
                binding: [{
                    key: Ext.EventObject.RETURN,
                    fn: function(keyCode) {
                        var selected = _grid.getSelectionModel().getSelection();
                        if (selected.length > 0) {
                            var f = selected[0];
                            selectRow(f);
                        }
                    }
                }]
            });
            var map_w = new Ext.util.KeyMap({
                                              target: _select_window,
                                              eventName: 'itemkeydown',
                                              processEvent: function(view, record, node, index, event) {
                                                  // Load the event with the extra information needed by the mappings
                                                  event.view = view;
                                                  event.store = view.getStore();
                                                  event.record = record;
                                                  event.index = index;
                                                  return event;
                                              },
                                              binding: [{
                                                            key: Ext.EventObject.RETURN,
                                                            fn: function(keyCode) {
                                                                var selected = _grid.getSelectionModel().getSelection();
                                                                if (selected.length > 0) {
                                                                    var f = selected[0];
                                                                    selectRow(f);
                                                                }
                                                            }
                                                        },
                                                        {
                                                            key: Ext.EventObject.UP,
                                                            fn: function(keyCode) {
                                                                console.log('up');
                                                            }
                                                        },
                                                        {
                                                            key: Ext.EventObject.DOWN,
                                                            fn: function(keyCode) {
                                                                console.log('down');
                                                            }
                                                        }
                                              ]
                                          });
            _grid.on('show', function () {
//                _grid.getView().focus();
//                _grid.getSelectionModel().select(0);
            } );

            _grid.getView().on('viewready', function () {
                                  _grid.getView().focus();
                                  _grid.getSelectionModel().select(0);
                              }

            );
            _select_window.show();

            _grid.getSelectionModel().select(0);
            _grid.getView().focus(false, 10);


            //            _grid.getSelectionModel().selectFirstRow();
        }
    };

    var showSprView = function (text_val) {
        if (_was_changed) {
            if (!hasStrValue(text_val)) {
                _code = '';
                _text = '';
                _was_changed = false;
                return;
            }
            get_xml_data({
                url:SPR_DEFAULT_URL,
                data :  {
                    '@action' : 'find',
                    '@spr_name' : _spr_name,
                    '@value':text_val
                },
                ok_callback : function (data) {
                    if (data instanceof QNode) {
                        if (data.count() == 1) {
                            _need_select = false;
                            var row = data.value('row');
                            selectSprValue(row.valueStr('code'), row.valueStr('value'));
                            _dropdown_show = false;
                            return;
                        }
                        showSprDropDown(data);
                    } else {
                        _input.select();
                        _input.focus();
                        _dropdown_show = false;
                    }

                }
            });
            return;
        }
        if (_need_select) {
            get_xml_data({
                url: SPR_DEFAULT_URL,
                data :  {
                    '@action' : 'select',
                    '@spr_name' : _spr_name
                },
                ok_callback: function (data) {
                    if (data instanceof QNode) {
                        showSprDropDown(data);
                    }
                }
            });
        }
    };

    var on_spr_text_change = function () {
      console.log('on_spr_text_change');
        _was_changed = true;
    };

    var on_spr_text_blur = function () {
        console.log('on_spr_text_blur');
        if (_dropdown_show) {
            return;
        }
        if (_was_changed) {
            _text_val = _component.getValue();
            if (hasStrValue(_text_val)) {
                showSprView(_text_val);
            } else {
                selectSprValue('', '');
            }

        }
    };

    var on_spr_btn_click = function () {
        console.log('on_spr_btn_click');
        _need_select = true;
        _text_val = _component.getValue();
        showSprView(_text_val);
    };

    var on_spr_key_press = function (event) {
        console.log('on_spr_key_press');
        if (event.altKey && event.keyCode == 40) {
            _need_select = true;
            _text_val = _component.getValue();
            _dropdown_show = true;
            showSprView(_text_val);
        }
    };
    this.component = function() {
        return _component;
    };
    var create = function (object_params) {
        _component = new Ext.form.field.ComboBox({
            labelAlign: "right",
            enableKeyEvents: true
        });
        _component.setWidth(object_params.valueStr(PRM_DLG_COMPONENT_WIDTH));
        _component.setFieldLabel(object_params.valueStr(PRM_DLG_COMPONENT_LABEL));
        that.enabled(_enabled);
        _based_label_width = _component.labelWidth;
        _component.on('keyup', on_spr_key_press);
        _component.on('change', on_spr_text_change);
        _component.on('blur', on_spr_text_blur);
        _component.on('expand', on_spr_btn_click);

    };

    create(prm);

}
