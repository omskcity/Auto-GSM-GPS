/**
 * This code contains copyright information which is the proprietary property
 * of SITA Information Network Computing Limited (SITA). No part of this
 * code may be reproduced, stored or transmitted in any form without the prior
 * written permission of SITA.
 *
 * Copyright (C) SITA Information Network Computing Limited 2009-2012.
 * All rights reserved.
 */
package org.quilt.web;

import org.quilt.dao.AbstractDAOItem;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Abstract controller.
 *
 * @author <a href="mailto:vbelokon@luxoft.com">Vasily Belokon</a>
 * @version 1.0
 */
public abstract class AbstractController extends AbstractDAOItem implements Controller {
    protected static final String PARAM_NAME_ACTION = "@action";
    protected static final String PARAM_NAME_OBJECT = "@object";
    protected static final String ACTION_SAVE = "save";
    protected static final String ACTION_DISPLAY = "display";
    protected static final String ACTION_DEFAULT = "default";
    protected static final String ACTION_DELETE = "delete";
    protected static final String NULL_VALUE = "null";

    protected String getString(Object obj) {
        if (obj != null) {
            if (obj instanceof String) {
                return (String) obj;
            } else if (obj instanceof Integer) {
                return Integer.toString ((Integer) obj);

            } else {
                return obj.toString();
            }
        }
        return null;
    }

    @Override
    public abstract ModelAndView handleRequest(final HttpServletRequest request, final HttpServletResponse response)
        throws Exception;
}
