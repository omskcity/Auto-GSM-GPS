package org.quilt.web;

import org.apache.commons.lang.StringUtils;
import org.quilt.dao.DAOException;
import org.quilt.dao.DAOObject;
import org.quilt.dao.QueryHelper;
import org.quilt.security.UserInfo;

import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Map;

/**
 * Controller for access to data from dialog.
 *
 * @author vbelokon
 */
public final class DataDBController extends AbstractDataControllerEx {
    @Override
    public DataResult doAction(final Map<String, Object> params, HttpSession session) throws Exception {
        final String action = getString(params.get(PARAM_NAME_ACTION));
        final String object = getString(params.get(PARAM_NAME_OBJECT));
        final String id = getString(params.get(DAOObject.PARAM_NAME_ID));
        if (!UserInfo.hasRight(object, action)) {
            throw new AuthorityException();
        }
        DataResult result = new DataResult();
        if (ACTION_SAVE.equalsIgnoreCase(action)) {
            if (StringUtils.isNotBlank(object)) {
                try {
                    DAOObject.findObject(object).saveRow(params);
                    result.setOk(true);
                } catch (DAOException e) {
                    result.addError(e.createError4Result());
                }
            }
            return result;
        } else if (ACTION_DELETE.equalsIgnoreCase(action)) {
            if (StringUtils.isNotBlank(id)) {
                if (StringUtils.isNotBlank(object)) {
                    try {
                        DAOObject.findObject(object).deleteRow(params);
                        result.setOk(true);
                    } catch (DAOException e) {
                        result.addError(e.createError4Result());
                    }
                }
            }
            return result;
        } else if (ACTION_DISPLAY.equalsIgnoreCase(action)) {
            if (StringUtils.isNotBlank(id)) {
                if (StringUtils.isNotBlank(object)) {
                    try {
                        String newObject = UserInfo.prepareScript(object, session);
                        Map<String, Object> row = DAOObject.findObject(newObject).getRow(params);
                        if (row != null) {
                            for (String param_name : row.keySet()) {
                                result.addData(new ResultNode(param_name, row.get(param_name)));
                            }
                            result.setOk(true);
                        }
                    } catch (DAOException e) {
                        result.addError(e.createError4Result());
                    }
                }
                return result;
            }
        } else if (ACTION_DEFAULT.equalsIgnoreCase(action)) {
            if (StringUtils.isNotBlank(object)) {
                try {
                    String newObject = UserInfo.prepareScript(object, session);
                    Map<String, Object> row = DAOObject.findObject(newObject).getRow(params);
                    if (row != null) {
                        for (String param_name : row.keySet()) {
                            result.addData(new ResultNode(param_name, row.get(param_name)));
                        }
                        result.setOk(true);
                    }
                } catch (DAOException e) {
                    result.addError(e.createError4Result());
                }
            }
            return result;
        } else {
            if (StringUtils.isNotBlank(object)) {
                try {
                    String newObject = object;
                    String storedQuery = QueryHelper.findQuery(object);

                    if (StringUtils.isNotBlank(storedQuery)) {
                        newObject = storedQuery;
                    }
                    newObject = UserInfo.prepareScript(newObject, session);
                    List<Map<String, Object>> rows = DAOObject.findObject(newObject).getRowList(params);
                    for (Map<String, Object> row : rows) {
                        ResultNode rowNode = new ResultNode("row");
                        result.addData(rowNode);
                        for (String param_name : (row).keySet()) {
                            rowNode.addNested(new ResultNode(param_name, row.get(param_name)));
                        }

                    }
                    result.setOk(true);
                } catch (DAOException e) {
                    result.addError(e.createError4Result());
                }
            }
            return result;
        }
        return result;
    }

}
