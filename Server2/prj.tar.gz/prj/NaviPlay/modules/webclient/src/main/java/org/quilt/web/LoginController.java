package org.quilt.web;

import org.quilt.security.UserInfo;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LoginController implements Controller {

    public ModelAndView handleRequest(HttpServletRequest request,
        HttpServletResponse response) throws Exception {
        if (UserInfo.getUserId() == null) {
            response.getWriter().print("need_auth");
            response.getWriter().flush();
        } else {
            response.getWriter().print("auth ok");
            response.getWriter().flush();
        }

        return null;
    }
}
