Ext.Error.handle = function(err) {
    console.log(err);
    return true;
};
Ext.require([
    'Ext.window.MessageBox',
    'Ext.container.Viewport',
    'Ext.layout.container.Absolute',
    'Ext.panel.Panel',
    'Ext.grid.Panel'
]);
Ext.onReady(function(){

    Ext.MessageBox.show({
        msg: 'Загрузка портала',
        progressText: 'Загрузка...',
        width:300,
        wait:true,
        waitConfig: {interval:200},
        icon:'ext-mb-download'//, //custom class in msg-box.html
//    animateTarget: 'mb7'
    });
//    Ext.FocusManager.enable({focusFrame: true});
    mineVP = Ext.create('Ext.container.Viewport', {
        renderTo: Ext.getBody(),
        layout: 'anchor'});
    mainTaskBar = Ext.create('Ext.panel.Panel', {
            anchor: '100%',
            height:30

        }
    );
    mainDesktop = Ext.create('Ext.panel.Panel', {
            anchor: '100% -30'
        }
    );
    mineVP.add(mainDesktop);
    mineVP.add(mainTaskBar);
    $LAB.setGlobalDefaults({
//        CacheBust: true,
        Debug: true
    })
        .script("quilt/third-party/jquery/jquery-1.8.2.js").wait()
        .script("quilt/scripts/Quilt/QNodeReader.js")
        .script("quilt/scripts/primitive.js")
        .script("quilt/scripts/param_engine.js")
        .script("quilt/scripts/Quilt/executor.js")
        .script("quilt/scripts/Quilt/core/utils.js")
        .script("quilt/scripts/Quilt/core/toolbar.js")
        .script("quilt/scripts/Quilt/core/list.js")
        .script("quilt/scripts/Quilt/ajax.js")
        .script("quilt/scripts/Quilt/list/list.js")
        .script("quilt/scripts/Quilt/form/form.js")
        .script("quilt/scripts/Quilt/form/components/string.js")
        .script("quilt/scripts/Quilt/form/components/text.js")
        .script("quilt/scripts/Quilt/form/components/date.js")
        .script("quilt/scripts/Quilt/form/components/list.js")
        .script("quilt/scripts/Quilt/form/components/spr.js")
        .script("quilt/scripts/Quilt/form/components/checkbox.js")
        .script("quilt/scripts/common.js")
        .script("quilt/scripts/Quilt/message.js").wait()
        .script("quilt/scripts/Quilt/launcher.js").wait()
        .script("quilt/scripts/Quilt/websocket.js").wait()
        .wait(function () {
            Ext.MessageBox.hide();
            Ext.require([
                'Ext.tip.QuickTipManager',
                'Ext.menu.*',
                'Ext.form.field.ComboBox',
                'Ext.layout.container.Table',
                'Ext.container.ButtonGroup'
            ]);
            Ext.onReady(function(){


            });
        });

});
