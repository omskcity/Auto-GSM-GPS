package org.quilt.dao;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.quilt.config.Context;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DAOObject {

    private final static Logger log = Logger.getLogger(DAOObject.class);
    private static Map<String,DAOObject> objects = null;
    public static String PARAM_NAME_ID = "@id";
    /** JDBC template */
    private static final NamedParameterJdbcTemplate db = new NamedParameterJdbcTemplate(Context
            .getInstance().getDataSource());

    private List<DAOObjectAttribute> attrs = null;
    private String name;
    private String primaryFieldName;
    private String orderedFieldName;
    private String script;
    private String listScript;
    private String displayScript;
    private String insertScript;
    private String updateScript;
    private String deleteScript;
    private DAOObjectType objType;
    private DAOObject () {}
//    private String comment;

    private static DAOObject findTable(String objName) {
        DAOObject result = null;
        try {
            final Connection connection = Context.getInstance().getDataSource().getConnection();
            try {
                final DatabaseMetaData dbMD = connection.getMetaData();
                ResultSet tables = dbMD.getTables(null,null,objName,null);
                if (tables.next()) {
                    result = new DAOObject();
                    result.setObjType(DAOObjectType.getByValue(tables.getString("TABLE_TYPE")));
                    //                        result.setComment(tables.getString("REMARKS"));
                    result.setName(tables.getString("TABLE_NAME"));
                    ResultSet cols = dbMD.getColumns(null,null,objName,null);
                    int i = 0;
                    while(cols.next()) {
                        DAOObjectAttribute attr = new DAOObjectAttribute();
                        attr.setFirst(i==0);
                        if (i==0) {
                            result.setPrimaryFieldName(cols.getString("COLUMN_NAME"));
                        }
                        if (cols.getInt("COLUMN_SIZE")>10 && StringUtils.isBlank(result.getOrderedFieldName()) ) {
                            result.setOrderedFieldName(cols.getString("COLUMN_NAME"));
                        }
                        attr.setSize(cols.getInt("COLUMN_SIZE"));

                        i++;
                        attr.setName(cols.getString("COLUMN_NAME"));
                        try {
                            if (cols.getString("DATA_TYPE").length()>2) {
                                attr.setType(Class.forName(cols.getString("DATA_TYPE")));
                            } else {
                                attr.setType(String.class);
                            }
                        } catch (ClassNotFoundException e){
                            attr.setType(String.class);
                            log.error(e.getMessage(), e);
                        }
                        attr.setTypeName(cols.getString("TYPE_NAME"));
                        attr.setSize(cols.getInt("COLUMN_SIZE"));
                        attr.setNullable(cols.getBoolean("NULLABLE"));
                        attr.setAutoIncrement(cols.getBoolean("IS_AUTOINCREMENT"));
                        result.getAttrs().add(attr);
                    }
                    generateScripts(result);
                }
            } finally {
                connection.close();
            }
        } catch (SQLException e){
            log.error(e.getMessage(), e);
        }
        return result;
    }

    private static DAOObject findProcedure(String objName) {
        DAOObject result = null;
        try {
            final Connection connection = Context.getInstance().getDataSource().getConnection();
            try {
                final DatabaseMetaData dbMD = connection.getMetaData();
                ResultSet procedures = dbMD.getProcedures(null,null,objName);
                if (procedures.next()) {
                    result = new DAOObject();
                    result.setObjType(DAOObjectType.Procedure);
                    result.setName(procedures.getString("PROCEDURE_NAME"));
                    //                        result.setComment(tables.getString("REMARKS"));
                    String procType = procedures.getString("PROCEDURE_TYPE");
                    ResultSet cols = dbMD.getProcedureColumns(null,null,objName,null);
                    int i = 0;
                    while(cols.next()) {
                        DAOObjectAttribute attr = new DAOObjectAttribute();
                        result.getAttrs().add(attr);
                        attr.setFirst(i==0);
                        if (i==0) {
                            result.setPrimaryFieldName(cols.getString("COLUMN_NAME"));
                        }
                        attr.setParamType(cols.getString("COLUMN_TYPE"));
/*                        if (cols.getInt("COLUMN_SIZE")>10 && StringUtils.isBlank(result.getOrderedFieldName()) ) {
                            result.setOrderedFieldName(cols.getString("COLUMN_NAME"));
                        }*/
                        attr.setSize(cols.getInt("LENGTH"));

                        i++;
                        attr.setName(cols.getString("COLUMN_NAME"));
                        try {
                            if (cols.getString("DATA_TYPE").length()>2) {
                                attr.setType(Class.forName(cols.getString("DATA_TYPE")));
                            } else {
                                attr.setType(String.class);
                            }
                        } catch (ClassNotFoundException e){
                            attr.setType(String.class);
                            log.error(e.getMessage(), e);
                        }
                        attr.setTypeName(cols.getString("TYPE_NAME"));
                        attr.setSize(cols.getInt("LENGTH"));
//                        attr.setNullable(cols.getBoolean("NULLABLE"));
                    }
                    generateProcedureScripts(result);
                }
            } finally {
                connection.close();
            }
        } catch (SQLException e){
            log.error(e.getMessage(), e);
        }
        return result;
    }

    public static DAOObject findObject(String objName) {
        DAOObject result;
        objName = StringUtils.trim(objName);
        if (objects == null) {
            objects = new HashMap<String,DAOObject>();
        }
        if (objects.keySet().contains(objName)) {
            result = objects.get(objName);
        } else {
            result = findTable(objName);
            if (result == null) {
                result = findProcedure(objName);
            }
            if (result == null) {
                result = new DAOObject();
                if (objName.toLowerCase().trim().startsWith("select ")) {
                    result.setObjType(DAOObjectType.SQL);
                    result.setScript(objName);
                } else {
                    result.setObjType(DAOObjectType.Script);
                    result.setScript(objName);
                }
            }
            objects.put(objName,result);
        }
        return result;
    }
    private static String trimParamList(String params) {
        params = params.trim();
        params = params.substring(0,params.length()-1);
        return params;
    }
    private static void generateScripts(DAOObject object) {
        String insFieldsList = "";
        String insVarsList = "";
        String updList = "";
        String selList = "";
        String whereCond = "";

        for (DAOObjectAttribute attr: object.getAttrs()) {
            if (attr.getFirst()) {
                whereCond = "where "+attr.getName()+" = :"+PARAM_NAME_ID;
            } else {
                insFieldsList = insFieldsList + " "+ attr.getName()+",";
                insVarsList = insVarsList + " :"+ attr.getName()+",";
                updList = updList+"  "+attr.getName()+"=:"+attr.getName()+",\n";
            }
            selList = selList+" t."+attr.getName()+",\n";

        }
        insFieldsList = trimParamList(insFieldsList);
        insVarsList = trimParamList(insVarsList);
        updList = updList.substring(0,updList.length()-2)+"\n";
        selList = selList.substring(0,selList.length()-2)+"\n"; 
        object.setInsertScript("insert into "+object.getName()+" ("+insFieldsList+")\nvalues ("+insVarsList+")");
        object.setUpdateScript("update "+object.getName()+" set\n"+updList+whereCond);
        object.setDisplayScript("select\n"+selList+"  from "+object.getName()+" t\n "+whereCond);
        object.setDeleteScript("delete from "+object.getName()+" "+whereCond);
        object.setListScript("select\n"+selList+"  from "+object.getName()+" t\n");
    }

    private static void generateProcedureScripts(DAOObject object) {
        String params = "";
        String delParams = "";
        String insParams = "";
        for (DAOObjectAttribute attr: object.getAttrs()) {
            params = params + " :"+ attr.getName()+",";
            if (attr.getFirst()) {
                delParams = delParams + " :"+ PARAM_NAME_ID+",";
                insParams = insParams + " null,";
            } else {
                insParams = insParams + " :"+ attr.getName()+",";
                delParams = delParams + " :"+ attr.getName()+",";
            }

        }

        params = trimParamList(params);
        delParams = trimParamList(delParams);
        insParams = trimParamList(insParams);

        object.setDeleteScript("call " + object.getName() + "(" + delParams + ")");
        object.setInsertScript("call " + object.getName() + "(" + insParams + ")");
        object.setUpdateScript("call " + object.getName() + "(" + params + ")");
        object.setScript("call " + object.getName() + "(" + params + ")");
    }

    public String getName() {
        return name;
    }

    public String getDisplayScript() {
        return displayScript;
    }

    public String getUpdateScript() {
        return updateScript;
    }

    public String getDeleteScript() {
        return deleteScript;
    }

    public String getInsertScript() {
        return insertScript;
    }
    public void setName(String name) {
        this.name = name;
    }

    public void setDisplayScript(String displayScript) {
        this.displayScript = displayScript;
    }

    public void setInsertScript(String insertScript) {
        this.insertScript = insertScript;
    }

    public void setUpdateScript(String updateScript) {
        this.updateScript = updateScript;
    }

    public void setDeleteScript(String deleteScript) {
        this.deleteScript = deleteScript;
    }

    public void setObjType(DAOObjectType objType) {
        this.objType = objType;
    }
    public boolean isScript() {
        return objType == DAOObjectType.SQL || objType == DAOObjectType.Script;
    }

    public boolean isSQL() {
        return objType == DAOObjectType.SQL;
    }

/*    public String getComment() {
        return comment;
    }
    public void setComment(String comment) {
        this.comment = comment;
    }
*/

    public List<DAOObjectAttribute> getAttrs() {
        if (attrs == null) {
            attrs = new ArrayList<DAOObjectAttribute>();
        }
        return attrs;
    }

    public DAOObjectType getObjType() {
        return objType;
    }

    public String getListScript() {
        return listScript;
    }

    public void setListScript(String listScript) {
        this.listScript = listScript;
    }


    public String getPrimaryFieldName() {
        return primaryFieldName;
    }
    public void setPrimaryFieldName(String primaryFieldName) {
        this.primaryFieldName = primaryFieldName;
    }

    public String getOrderedFieldName() {
        return orderedFieldName;
    }

    public void setOrderedFieldName(String orderedFieldName) {
        this.orderedFieldName = orderedFieldName;
    }

    public String getScript() {
        return script;
    }

    public void setScript(String script) {
        this.script = script;
    }

    /**
     * Extracts single T element from data base.
     *
     * @param args Map named params
     * @return Map of field values by name of fields.
     */
    public Map<String, Object> getRow(final Map<String, Object> args) throws DAOException {
        Map<String, Object> resultObject = null;
        try{
            switch (getObjType()) {
                case Table: case  View:  {
                    try {
                        resultObject = db.queryForMap(getDisplayScript(), args);
                    } catch (EmptyResultDataAccessException e){
                        log.info(
                            "Empty result for query \"" + getScript() + "\""
                        );
                    } catch (Exception e) {
                        log.error(
                            "Errors occured for query \"" + getDisplayScript() + "\"",
                            e
                        );
                    }
                    break;
                }
                case SQL: {
                    try {
                        resultObject = db.queryForMap(getScript(), args);
                    } catch (EmptyResultDataAccessException e){
                        log.info(
                            "Empty result for query \"" + getScript() + "\""
                        );
                    } catch (Exception e) {
                        log.error(
                            "Errors occured for query \"" + getScript() + "\"",
                            e
                        );
                    }
                    break;
                }
//                default: monthString = "Invalid month";
//                    break;
            }
        } catch (DataAccessException e) {
            handleException(e);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        processRow(resultObject);
        return resultObject;
    }

    /**
     * Extracts single T element from data base.
     *
     * @return Map of field values
     */
    public Map<String, Object> getRow() throws DAOException {
        return getRow(null);
    }

    /**
     * Extracts list of T elements from data base with specified parameters
     *
     * @param args map of named parameters
     * @return List of row
     */
    public List<Map<String,Object>> getRowList(final Map<String, Object> args) throws DAOException {
        List<Map<String,Object>> result = null;

        try {
            switch (getObjType()) {
                case Table: case  View:  {
                    String whereCond ="";
                    String orderCond ="";
                    if (args != null) {
                        for (String arg_name : args.keySet()) {
                            for (DAOObjectAttribute attr : attrs) {
                                if (StringUtils.isNotBlank(attr.getName())) {
                                    if (attr.getName().equalsIgnoreCase(arg_name)) {
                                        whereCond = whereCond + " and t." + attr.getName() + "=:" + attr.getName() + "\n";
                                    } else if ("like_".concat(attr.getName()).equalsIgnoreCase(arg_name)) {
                                        whereCond = whereCond + " and t." + attr.getName() + " like :" + arg_name + "\n";
                                    }
                                }
                            }
                        }
                        if (whereCond.startsWith(" and")) {
                            whereCond = " where "+whereCond.substring(" and".length());
                        }
                        if (StringUtils.isNotBlank(orderedFieldName)) {
                            orderCond = " order by "+orderedFieldName;
                        }
                    }
                    result = db.queryForList(getListScript()+whereCond+orderCond, args);
                    break;
                }
                case SQL: case Script: {
                    result = db.queryForList(getScript(), args);
                    break;
                }
            }
        } catch (DataAccessException e) {
            handleException(e);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        if (result == null) {
            result = new ArrayList<Map<String, Object>>();
        }
        processRowList(result);
        return result;
    }

    public void saveRow(final Map<String, Object> row) throws DAOException {
        try{
            switch (getObjType()) {
                case Table:case Procedure: {
                    if (row.containsKey(PARAM_NAME_ID)) {
                        db.update(getUpdateScript(),new MapSqlParameterSource(row)
                        {
                            public Object getValue(String paramName) {
                                if (!hasValue(paramName)) {
                                    return null;
                                }
                                return this.getValues().get(paramName);
                            }
                        });
                    } else {
                        KeyHolder keyHolder = new GeneratedKeyHolder();
                        db.update(getInsertScript(), new MapSqlParameterSource(row)
                        {
                            public Object getValue(String paramName) {
                                if (!hasValue(paramName)) {
                                    return null;
                                }
                                return this.getValues().get(paramName);
                            }

                        }, keyHolder);
                        row.put(PARAM_NAME_ID,keyHolder.getKeys().get(getPrimaryFieldName()));
                    }
                    break;
                }
            }
        } catch (DataAccessException e) {
            handleException(e);
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
    }

    public int deleteRow(final Map<String, Object> row) throws DAOException {
        int result = 0;
        try {
            switch (getObjType()) {
                case Script: {
                    if (row.containsKey(PARAM_NAME_ID)) {
                        result = db.update(getScript(),row);
                        log.info(result + "rows affected with " + getScript());
                    }
                    break;
                }
                case Procedure: {
                    if (row.containsKey(PARAM_NAME_ID)) {
                        result = db.update(getDeleteScript(), row);
                        log.info(result + "rows affected with " + getDeleteScript());
                    }
                    break;
                }
                case Table: {
                    if (row.containsKey(PARAM_NAME_ID)) {
                        result = db.update(getDeleteScript(), row);
                        log.info(result + "rows affected with " + getDeleteScript());
                    }
                }
                default: {
                    log.error("Can't delete row for " + getObjType().getValue());
                    break;
                }
            }

        } catch (DataAccessException e) {
            handleException(e);
        }
        return result;
    }

    public int execute(final Map<String, Object> args) throws DAOException {
        int result = 0;
        try {
            switch (getObjType()) {
                case Script: {
                    result = db.update(getScript(),args);
                    log.info(result + "rows affected with " + getScript());
                    break;
                }
                default: {
                    log.error("Can't execute " + getObjType().getValue());
                    break;
                }
            }
        } catch (DataAccessException e) {
            handleException(e);
        }
        return result;
    }

    private void handleException(DataAccessException e) throws DAOException {
        Class cl = e.getClass();
        DAOExceptionType type = DAOExceptionType.DataUnknownException;
        while (!cl.equals(DataAccessException.class)) {
            if (DAOExceptionType.getByCode(cl.getSimpleName()) != null) {
                type = DAOExceptionType.getByCode(cl.getSimpleName());
                break;
            }
            cl = cl.getSuperclass();
        }
        log.warn(e.getMessage());
        throw new DAOException(type, e.getMessage());
    }

    private void processRowList(List<Map<String, Object>> rows) {
        if (rows != null) {
            for(Map<String, Object> row: rows) {
                processRow(row);
            }
        }
    }

    private void processRow(Map<String, Object> row) {
        if (row != null) {
            for (String name : row.keySet()) {
                Object obj = row.get(name);
                if (obj != null) {
                    if (obj instanceof byte[]) {
                        String s = new String((byte[] )obj);
                        row.put(name, s);
                    }
                }
            }
        }
    }

}
