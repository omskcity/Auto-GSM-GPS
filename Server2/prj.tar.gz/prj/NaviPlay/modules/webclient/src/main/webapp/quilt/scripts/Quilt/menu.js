function QLaunchers (container) {
    var _container = container;
    var _items = [];
    this.addItem = function (pname, pexecutor) {
        var item = new QMenuItem(pname, pexecutor);
        _items.push(item)
        return item;
    };

    this.init = function () {
        _container.clear();
        jQuery.each(_items, function(i, item) {
            var btn = Ext.create('Ext.Button', {
                text    : item.name(),
                handler : item.executor()
            });
            _container.add(btn);
            btn.show();
        });
    };
}

function QMenuItem (pname, pexecutor) {
    var _name;
    var _executor;
    var _btn;
    var _container = container;


    this.name = function (pvalue) {
        if (pvalue == undefined) {
            return _name;
        } else {
            _name = pvalue;
        }
        return true;
    };

    this.executor = function (pvalue) {
        if (pvalue == undefined) {
            return _executor;
        } else {
            _executor = pvalue;
        }
        return true;
    };

    this.name(pname);
    this.executor(pexecutor);

    this.addMenu = function (pname, pexecutor, container) {
        var newItem = new QMenuItem(pname, pexecutor,  container);
        return newItem;
    };

}

var rootMenu  ;

function initMenu(container) {
    rootMenu = new QMenuItem();
    rootMenu.addMenu(
        'Выйти'
        ,function () {
            showDialog('dlg_q_logout', function () {
                execUrl('?')
            });
            return false;
        }

        ,container
    );
    rootMenu.addMenu(
        'Войти'
        ,function () {
            relogin( function () {
                execUrl(window.location.href)
            });
            return false;
        }
        ,container
    );

    get_xml_data({
        object: 'available_launchers',
        data:  {},
        ok_callback: function (data) {
            if (data instanceof QNode) {
                jQuery.each(data.asArrayValue(), function(i, row) {

                    rootMenu.addMenu(
                        row.valueStr('name')
                        ,function () {

                        executeCommand(row.valueStr('data'));

                        return false;
                    }
                        ,container
                    );

                });
            }
            rootMenu.createMenu();

        },
        error_callback: function (data) {
            showError('Ошибка получения списка ярлыков', data);
        }

    });

}
