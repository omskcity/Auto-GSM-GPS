package org.quilt.config;

import org.apache.velocity.app.VelocityEngine;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;

import javax.mail.internet.MimeMessage;
import javax.sql.DataSource;

/**
 * General configuration class
 * 
 * @author sandro
 */
public final class Context {

    /** Instance */
    private static Context _instance;

    private String smtpFrom = "noreply@localhost";

    private String emailFeedback = "noreply@localhost";

    /** Data source */
    private DataSource dataSource;

    private VelocityEngine velocityEngine;
    private JavaMailSender mailSender;

    /**
     * Singleton instance
     * 
     * @return instance
     */
    public static Context getInstance() {
        if (_instance == null) {
            _instance = new Context();
        }
        return _instance;
    }

    /**
     * @param dataSource
     *            the dataSource to set
     */
    public void setDataSource(final DataSource dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * @return the dataSource
     */
    public DataSource getDataSource() {
        return dataSource;
    }

    public String getSmtpFrom() {
        return smtpFrom;
    }

    public void setSmtpFrom(String smtpFrom) {
        this.smtpFrom = smtpFrom;
    }

    public VelocityEngine getVelocityEngine() {
        return velocityEngine;
    }

    public void setVelocityEngine(VelocityEngine velocityEngine) {
        this.velocityEngine = velocityEngine;
    }

    public JavaMailSender getMailSender() {
        return mailSender;
    }

    public void setMailSender(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public String getEmailFeedback() {
        return emailFeedback;
    }

    public void setEmailFeedback(String emailFeedback) {
        this.emailFeedback = emailFeedback;
    }

    public void sendEmail(
            final String to,
            final String from,
            final String subj,
            final String messageTxt,
            final Boolean asHtml
    ) {

        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            public void prepare(MimeMessage mimeMessage) throws Exception {
                MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage);
                messageHelper.setTo(to);
                messageHelper.setFrom(from);
                messageHelper.setText(messageTxt, asHtml);
                messageHelper.setSubject(subj);
            }
        };
        getMailSender().send(preparator);
    }

    public void sendEmail(
        final String[] to,
        final String from,
        final String subj,
        final String messageTxt,
        final Boolean asHtml
    ) {

        MimeMessagePreparator preparator = new MimeMessagePreparator() {
            public void prepare(MimeMessage mimeMessage) throws Exception {
                MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage);
                messageHelper.setTo(to);
                messageHelper.setFrom(from);
                messageHelper.setText(messageTxt, asHtml);
                messageHelper.setSubject(subj);
            }
        };
        getMailSender().send(preparator);
    }

}
