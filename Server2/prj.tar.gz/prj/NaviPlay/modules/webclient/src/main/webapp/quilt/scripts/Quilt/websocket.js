var loc = 'ws://localhost/websocket';
//    document.location.toString();
//loc = loc.replace('http://', 'ws://').replace('https://', 'wss://')+ "websocket";
var _ws = new WebSocket(loc);
_ws.onopen = function (data) {
    alert("onopen" + data);
};
_ws.onmessage = function (data) {
    alert("onmessage" + data);
};
_ws.onclose = function (data) {
    //alert("onclose" + data);
};