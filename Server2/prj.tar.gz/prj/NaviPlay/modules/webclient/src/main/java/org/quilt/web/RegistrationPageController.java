package org.quilt.web;

import org.quilt.config.Context;
import org.quilt.dao.DAOException;
import org.quilt.dao.DAOObject;
import org.quilt.security.UserInfo;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.security.authentication.encoding.PasswordEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class RegistrationPageController extends AbstractDataController {
    final private static String USER_TABLE= "q_user";
    final private static String recoveryPassTemplate = "Your username: :login\nYour Password: :newpass";
    final private static String FIND_USER_BY_EMAIL = "SELECT * FROM " + USER_TABLE+ " WHERE email=:email";

    public DataResult doAction(Map<String, Object> params){
        DataResult result = new DataResult();
        final String mode = getString(params.get("mode"));
        if ("registration".equalsIgnoreCase(mode)) {
            String pass = getString(params.get("pass"));
            String pass_confirm = getString(params.get("pass_confirm"));
            if (pass.equals(pass_confirm)) {
                PasswordEncoder encoder = new Md5PasswordEncoder();
                String hashedPass = encoder.encodePassword(pass, null);

                params.put("hash", hashedPass);
                params.put("enabled", 1);
                try {
                    DAOObject.findObject(USER_TABLE).saveRow(params);
                } catch (DAOException e) {
                    result.addError(e.createError4Result());
                }
                result.setOk(true);
            }
        }else if ("change_pass".equalsIgnoreCase(mode)) {
            String new_pass = getString(params.get("new_pass"));
            String new_pass_confirm = getString(params.get("new_pass_confirm"));
            if (new_pass.equals(new_pass_confirm)) {
                PasswordEncoder encoder = new Md5PasswordEncoder();
                String hashedPass = encoder.encodePassword(new_pass, null);
                params.put(DAOObject.PARAM_NAME_ID, UserInfo.getUserId().toString());
                try {
                    params = DAOObject.findObject(USER_TABLE).getRow(params);
                } catch (DAOException e) {
                    result.addError(e.createError4Result());
                }
                params.put(DAOObject.PARAM_NAME_ID, UserInfo.getUserId().toString());
                params.put("hash",hashedPass);
                try {
                    DAOObject.findObject(USER_TABLE).saveRow(params);
                } catch (DAOException e) {
                    result.addError(e.createError4Result());
                }
            }
            result.setOk(true);
        } else if ("recoverypass".equalsIgnoreCase(mode)) {
            final String passStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
            String email = getString(params.get("email"));
            if (email != null) {
                email = email.trim();
            } else {
                email = "";
            }
            if (!email.isEmpty()) {
                //search email in data base
                Map<String, Object> args = new HashMap<String, Object>();
                args.put("email", email);
                try {
                    args = DAOObject.findObject(FIND_USER_BY_EMAIL).getRow(args);
                } catch (DAOException e) {
                    result.addError(e.createError4Result());
                }

                //generate new pass
                String newPass = "";
                Random random = new Random();
                for (int i = 0; i < 6; i++) {
                    int rnd = random.nextInt(passStr.length() - 2);
                    newPass += passStr.substring(rnd, rnd + 1);
                }
                PasswordEncoder encoder = new Md5PasswordEncoder();
                String hashedPass = encoder.encodePassword(newPass, null);

                //update record
                args.put(DAOObject.PARAM_NAME_ID, args.get("id"));
                args.put("hash", hashedPass);
                try {
                    DAOObject.findObject(USER_TABLE).saveRow(args);
                } catch (DAOException e) {
                    result.addError(e.createError4Result());
                }

                //send email;
                Map<String, Object> params2 = new HashMap<String, Object>();
                params2.put("login", args.get("login"));
                params2.put("newpass", newPass);
                String message = recoveryPassTemplate;
                for (String aKey : params2.keySet()) {
                    message = message.replace(":" + aKey, getString(params2.get(aKey)));
                }
                Context.getInstance().sendEmail(email, Context.getInstance().getSmtpFrom(),  "The pass reminder", message, false);
                result.setOk(true);
            }

        }

        return result;
    }

}
