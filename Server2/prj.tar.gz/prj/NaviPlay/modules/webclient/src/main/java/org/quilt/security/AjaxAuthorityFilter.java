/**
 * This code contains copyright information which is the proprietary property
 * of SITA Information Network Computing Limited (SITA). No part of this
 * code may be reproduced, stored or transmitted in any form without the prior
 * written permission of SITA.
 *
 * Copyright (C) SITA Information Network Computing Limited 2009-2012.
 * All rights reserved.
 */
package org.quilt.security;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Filter provide authorities information into response
 *
 * @author <a href="mailto:vbelokon@luxoft.com">Vasily Belokon</a>
 * @version 1.0
 */
public class AjaxAuthorityFilter extends GenericFilterBean {
    @Override

    public void doFilter(final ServletRequest request, final ServletResponse response, final FilterChain chain)
        throws IOException, ServletException {
        StringBuilder roles = new StringBuilder();
        for (GrantedAuthority auth: SecurityContextHolder.getContext().getAuthentication().getAuthorities()) {
            if (roles.length() > 0) {
                roles.append(",");
            }
            roles.append(auth.getAuthority());
        }
        if (response instanceof HttpServletResponse) {
            HttpServletResponse httpServletResponse = (HttpServletResponse) response;
            httpServletResponse.addHeader("roles", roles.toString());
            httpServletResponse.addHeader("user", SecurityContextHolder.getContext().getAuthentication().getName());
        }
        chain.doFilter(request, response);
    }

}
