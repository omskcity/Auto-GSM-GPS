package org.quilt.dao;

public class DAOObjectAttribute {

    private String name;
    private Class type;
    private String typeName;
    private Integer size;
    private Boolean isNullable;
    private String comment;
    private String devaultValue;
    private Boolean isAutoIncrement;
    private Boolean isFirst;
    private String paramType;

    public Boolean getFirst() {
        return isFirst;
    }

    public void setFirst(Boolean first) {
        isFirst = first;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Class getType() {
        return type;
    }

    public void setType(Class type) {
        this.type = type;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public Boolean getNullable() {
        return isNullable;
    }

    public void setNullable(Boolean nullable) {
        isNullable = nullable;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getDevaultValue() {
        return devaultValue;
    }

    public void setDevaultValue(String devaultValue) {
        this.devaultValue = devaultValue;
    }

    public Boolean getAutoIncrement() {
        return isAutoIncrement;
    }

    public void setAutoIncrement(Boolean autoIncrement) {
        isAutoIncrement = autoIncrement;
    }

    public String getParamType() {
        return paramType;
    }

    public void setParamType(final String paramType) {
        this.paramType = paramType;
    }
}
