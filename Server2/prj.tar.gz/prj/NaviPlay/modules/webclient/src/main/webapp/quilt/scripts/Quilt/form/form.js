Ext.require([
    'Ext.window.Window',
    'Ext.layout.container.Form',
    'Ext.layout.container.Absolute'
]);


var PRM_DLG = 'dialog';
var PRM_DLG_NAME = 'name';

var PRM_DLG_COMPONENT_ID = 'id';
var PRM_DLG_COMPONENT_LABEL = 'label';
var PRM_DLG_COMPONENT_WIDTH = 'width';
var PRM_DLG_COMPONENT_HEIGHT = 'height';
var PRM_DLG_COMPONENT_VALUE = 'value';

var PRM_DLG_DISABLED = 'disabled';

var PRM_DLG_URL = 'url';
var PRM_DLG_OK_MESSAGE = 'success_message';
var PRM_DLG_FAIL_MESSAGE = 'error_message';
var PRM_DLG_REQUIRED_PARAMS = 'required_params';

var PRM_DLG_SAVE_BTN_TEXT = 'save_button_text';
var PRM_DLG_CANCEL_BTN_TEXT = 'cancel_button_text';

var PRM_DLG_ID = 'id';

var PRM_DLG_TITLE = 'title';
var PRM_DLG_WIDTH = 'width';
var PRM_DLG_OBJ =  'object';
var PRM_DLG_DEFAULT_OBJ =  'default_object';
var PRM_DLG_DISPLAY_OBJ =  'display_object';
var PRM_DLG_UPDATE_OBJ =  'update_object';
var PRM_DLG_INSERT_OBJ =  'insert_object';
var PRM_DLG_DELETE_OBJ =  'delete_object';

var PRM_DLG_OPERATION = 'operation';
var PRM_DLG_OPERATION_EDIT = 'edit';
var PRM_DLG_OPERATION_ADD = 'add';
var PRM_DLG_OPERATION_DELETE = 'del';
var PRM_DLG_OPERATION_INPUT = 'input';

var PRM_DLG_ACTION = 'action';
var PRM_DLG_OK_CALLBACK = '@ok_event';
var PRM_DLG_RECREATE = 'recreate';
var PRM_DLG_CONSTANTS =  'constants';


/** QDialog static class implement dialog storage and executor logic */
var QDialogManager = {};
QDialogManager.dialogs = {};
QDialogManager.cmd = 'dlg';


QDialogManager.execute = function(exec_param, callback) {
    var prm;
    if (exec_param != undefined ) {
        if (exec_param instanceof QNode) {
            prm = exec_param;
        } else {
            prm = new QNode(exec_param);
        }
    }

    var dlg_name = prm.valueStr(PRM_DLG_NAME);
    var recreate = prm.valueStr(PRM_DLG_RECREATE);
    var dialog = QDialogManager.dialogs[dlg_name];
    if (hasValue(dialog) && isTrue(recreate)) {
        dialog.destroy();
        dialog = null;
    }
    if (!hasValue(dialog)) {
        dialog = new QDialog(dlg_name);
        QDialogManager.dialogs[dlg_name] = dialog;
    }
    dialog.execute(prm, callback);
};

/** QDialog class implement dialog logic */
function QDialog (init_prm) {
    var _before_show_callback;
    var that = this;
    var _dialog_name;
    var _extWindow;
    var _init_prm;
    var _dlg_descr;
    var _data;
    var _known_params = [];
    var _obj;
    var _obj_default;
    var _obj_display;
    var _obj_insert;
    var _obj_update;
    var _obj_delete;
    var _operation;
    var _action;
    var _data_id;
    var _components;
    var _result_callback;
    var _result;
    var _title;
    var _btn_toolbar;
    var _main_panel;
    //var _form_keymap;

    //var _lastX = 0;
    //var _lastY = 0;
    //var _diffY = 20;

    this.addOnShowEvent = function (call) {
        _before_show_callback.add(call);
    };

    this.getWindow = function () {
        return _extWindow;
    };

    this.getData = function () {
        return _data;
    };

    this.name = function () {
        return _dialog_name;
    };

    this.replaceParam = function (str) {
        var wrap = '%';
        bindInput2Data();
        str = strReplaceWrap(str, _data, wrap);
        jQuery.each(_known_params, function(i, val) {
            str = reslaceAllIgnoreCase(str, wrap+val+wrap, '');
        });

        return str;
    };

    this.execute = function(exec_param, callback) {
        _data = new QNode();
        _init_prm.set(exec_param);
        _data.set(_init_prm.value('params'));
        _result_callback = callback;
        initDialogDescr(
            function () {
                initDBObjects();
                initOperation();
                if (!hasValue(_extWindow) && hasValue(_dlg_descr)) {
                    if (hasStrValue(_dlg_descr.valueStr('know_params'))) {
                        var params = _dlg_descr.valueStr('know_params').split(",");
                        jQuery.each(params, function(i, param) {
                            _known_params.push(param);
                        });
                    }
                    buildDialog();
                }
                initBtnToolbar();
                initDataFromDB(
                    function () {
                        if (_operation == PRM_DLG_OPERATION_DELETE) {
                            _result = true;
                            deleteParam(result_callback);
                            return;
                        }
                        if (hasValue(_dlg_descr)) {
                            showDialog();
                        }
                    }
                );
            }
        );
    };

    var createDialog = function (dlg_name) {
        _before_show_callback = $.Callbacks();
        _init_prm = new QNode();
        _data = new QNode();
        _components = [];

        if (!hasStrValue(dlg_name)) {
            throw new Error('Не указано имя диалога');
        }
        _dialog_name = dlg_name;
    };

    var initDialogDescr = function (callback) {
        if (!hasValue(_dlg_descr)) {
            _dlg_descr = _init_prm.value(PRM_DLG);
        }
        if (hasValue(_dlg_descr)) {
            callback();
        } else {
            var type = 'form';
            get_xml_data({
                url:"object.do",
                data: {
                    '@name' :_dialog_name,
                    '@type': type
                },
                ok_callback : function (data) {
                    var qdata = new QNode(data);
                    var dlg_data = qdata.valueStr('data');
                    _dlg_descr = new QNode(dlg_data);
                    callback();

                },
                error_callback: function (data) {
                    showError('Ошибка получения диалога с именем ' + _dialog_name, data);
                }
            });
        }
    };

    var result_callback = function() {
        if (hasValue(_result_callback)) {
            _result_callback(_result);
        }
    };

    var dialog_save = function() {
        if (strEqualsIgnoreCase(_operation, PRM_DLG_OPERATION_ADD) || strEqualsIgnoreCase(_operation, PRM_DLG_OPERATION_EDIT)) {
            saveParam(function () {
                _result = true;
                _extWindow.close();
            });
        } else {
            bindInput2Data();
            _result = _data;
            _extWindow.close();
        }
    };

    var dialog_cancel = function() {
        _result = false;
        _extWindow.close();
    };

    var initBtnToolbar = function () {
        if (!strEquals(nvl(_operation,'show'),'show')) {
            var save_btn_text = nvl(_dlg_descr.valueStr(PRM_DLG_SAVE_BTN_TEXT), "Сохранить");
            var cancel_btn_text = nvl(_dlg_descr.valueStr(PRM_DLG_CANCEL_BTN_TEXT), "Отмена");

            if (hasValue(_btn_toolbar)) {
                _btn_toolbar.destroy();
            }
            _btn_toolbar = new Ext.toolbar.Toolbar({
                anchor: '100%',
                height:30
            });
            _extWindow.add(_btn_toolbar);

            _btn_toolbar.remove('myPanelId', false);
            _btn_toolbar.add(['->',{text:save_btn_text, handler: dialog_save}, {text:cancel_btn_text , handler: dialog_cancel}]);

        } else {
            if (hasValue(_btn_toolbar)) {
                _btn_toolbar.destroy();
            }
        }
    };

    var buildDialog = function () {
        if(isTrue(_init_prm.valueStr(PRM_DLG_RECREATE)) && hasValue(_extWindow)) {
            _extWindow.destroy()
        }
        if (!hasValue(_extWindow)) {
            _title = _dlg_descr.valueStr(PRM_DLG_TITLE);
            _extWindow = Ext.create('Ext.window.Window', {
                closeAction: 'hide',
                title: _title,
                modal: true,
                width: _dlg_descr.valueStr(PRM_DLG_WIDTH),
                layout: 'anchor'
            });
            _main_panel = Ext.create('Ext.panel.Panel', {
                    anchor: '100% -30',
                    layout: 'form'
                }
            );

            _extWindow.add(_main_panel);
            _extWindow.setWidth(400);
            _extWindow.on('close' , result_callback);
            buildDialogContent();
        }
    };

    this.destroy = function () {
        _extWindow.destroy();
    };

    var initDBObjects = function () {

        _obj = _dlg_descr.valueStr(PRM_DLG_OBJ);

        _obj_default = _dlg_descr.valueStr(PRM_DLG_DEFAULT_OBJ);

        _obj_display = nvl(_dlg_descr.valueStr(PRM_DLG_DISPLAY_OBJ), _obj);
        _obj_insert = nvl(_dlg_descr.valueStr(PRM_DLG_INSERT_OBJ), _obj);
        _obj_update = nvl(_dlg_descr.valueStr(PRM_DLG_UPDATE_OBJ), _obj);
        _obj_delete = nvl(_dlg_descr.valueStr(PRM_DLG_DELETE_OBJ), _obj);
    };

    var initOperation = function () {
        _data_id = _init_prm.valueStr(PRM_DLG_ID);
        _operation = _init_prm.valueStr(PRM_DLG_OPERATION);
        if (!hasStrValue(_operation)) {
            _operation = _dlg_descr.valueStr(PRM_DLG_OPERATION);
        }
        if (!hasStrValue(_operation)) {
            if (hasStrValue(_obj_insert)) {
                _operation = PRM_DLG_OPERATION_ADD;
            } else {
                _operation = PRM_DLG_OPERATION_INPUT;
            }

        }
        _action = _init_prm.valueStr(PRM_DLG_ACTION);

        if ( _operation == PRM_DLG_OPERATION_EDIT) {
            if (! hasStrValue(_data_id)) {
                _operation = PRM_DLG_OPERATION_ADD;
            }
        }
    };

    var initDataFromDB = function (callback) {
        if ( _operation == PRM_DLG_OPERATION_EDIT) {
            clearInput();
            getParamById( function () {
                bindData2Input();
                enableComponents();
                callback();
            });

        } else  if ( _operation == PRM_DLG_OPERATION_ADD || _operation == PRM_DLG_OPERATION_INPUT) {
            clearInput();
            getDefaultParam( function () {
                bindData2Input();
                enableComponents();
                callback();
            });
        } else {
            bindData2Input();
            enableComponents();
            callback();
        }
    };

    var focusComponent = function () {
        if (_components.length > 0) {
            var first = _components[0];
            try {
                first.focus();
            } catch (e) {
                console.log(e);
            }
        }
    };

    var showDialog = function () {
        _before_show_callback.fire(_data);
        _extWindow.doLayout();
        _extWindow.show();

        recalcSizes();
        _extWindow.center();
        focusComponent();
    };

    var buildDialogContent = function () {
        jQuery.each(_dlg_descr.asArrayValue(), function(i, val) {
            addDialogComponent(val);
        });
        _extWindow.doLayout();
    };

    var getUrl = function () {
//      //console.log('url=' + nvl(nvl(_init_prm.valueStr(PRM_DLG_URL), _dlg_descr.valueStr(PRM_DLG_URL)), 'data.do'));
        return nvl(nvl(_init_prm.valueStr(PRM_DLG_URL), _dlg_descr.valueStr(PRM_DLG_URL)), 'data.do');
    };

    var getParamById = function (callback) {
        get_xml_data({
            url: getUrl(),
            data: {
                '@action' : 'display',
                '@object' : _obj_display,
                '@id' : _data_id
            },
            ok_callback : function (data) {
                _data.set(data);
                callback();
            },
            error_callback: function (data) {
                showError('Ошибка получения данных по идентификатору', data);
            }

        });

    };

    createDialog(init_prm);

    var getDefaultParam = function (callback) {
        if (hasStrValue(_obj_default)) {
            get_xml_data({
                url: getUrl(),
                data: {
                    '@action' : 'default',
                    '@object' : _obj_default
                },
                ok_callback : function (data) {
                    _data.set(data);
                    callback();
                },
                error_callback: function (data) {
                    showError('Ошибка получения данных поумолчанию', data);
                }

            });
        } else {
            callback();
        }
    };

    var clearInput = function() {
        jQuery.each(_components, function(i, component) {
            component.clear();
        });
    };

    var bindData2Input =function () {
        clearInput();
        if (hasValue(_dlg_descr.value(PRM_DLG_CONSTANTS))) {
            jQuery.each(_dlg_descr.value(PRM_DLG_CONSTANTS).asArrayValue(), function(i, constant) {
                _data.add(constant);
            });
        }
        if (hasValue(_init_prm.value(PRM_DLG_CONSTANTS))) {
            jQuery.each(_init_prm.value(PRM_DLG_CONSTANTS).asArrayValue(), function(i, constant) {
                _data.add(constant);
            });
        }
        jQuery.each(_components, function(i, component) {
            component.bindData2Value();
        });
    };


    var bindInput2Data = function () {
        jQuery.each(_components, function(i, component) {
            component.bindValue2Data();
        });
        //initConstants
        if (hasValue(_dlg_descr.value(PRM_DLG_CONSTANTS))) {
            jQuery.each(_dlg_descr.value(PRM_DLG_CONSTANTS).asArrayValue(), function(i, constant) {
                _data.add(constant);
            });
        }
        if (hasValue(_init_prm.value(PRM_DLG_CONSTANTS))) {
            jQuery.each(_init_prm.value(PRM_DLG_CONSTANTS).asArrayValue(), function(i, constant) {
                _data.add(constant);
            });
        }
    };

    var recalcSizes = function () {
        var maxLabelWidth = 0;
        var maxComponentWidth = 0;
        jQuery.each(_components, function(i, component) {
            if (hasValue(component.labelWidth) && $.isFunction(component.labelWidth)) {
                var labelWidhtCurr = component.labelWidth();
                console.log(component);
                console.log('label width' + labelWidhtCurr);
                if (hasValue(labelWidhtCurr) && labelWidhtCurr > maxLabelWidth) {
                    maxLabelWidth = labelWidhtCurr;
                }

            }
        });
        jQuery.each(_components, function(i, component) {
            if (hasValue(component.labelWidth) && $.isFunction(component.labelWidth)) {
                component.labelWidth(maxLabelWidth);
            }
        });

        jQuery.each(_components, function(i, component) {
            if (hasValue(component.componentWidth) && $.isFunction(component.componentWidth)) {
                var curr = component.componentWidth();
                console.log(component);
                console.log('width' + curr);
                if (hasValue(curr) && curr > maxComponentWidth) {
                    maxComponentWidth = curr;
                }

            }
        });
        if (maxComponentWidth < 200) {
            maxComponentWidth = 210;
        }
        if (maxComponentWidth > 150) {
            _extWindow.setWidth(maxComponentWidth + 26 +5 );
        }
    };

    var getComponentIds = function () {
        var res = [];
        jQuery.each(_components, function(i, component) {
            if (hasValue(component.id) && $.isFunction(component.id)) {
                var c_id = component.id();
                if (jQuery.inArray( c_id, res) < 0) {
                    res.push(c_id);
                }
            }
        });
        return res;
    };

    var getDisableIds = function () {
        var res = [];
        var disableInDialog = _dlg_descr.valueStr(PRM_DLG_DISABLED);
        if (hasStrValue(disableInDialog)) {
            jQuery.each(disableInDialog.split(','), function(i, c_id) {
                if (jQuery.inArray( c_id, res) < 0) {
                    res.push(c_id);
                }
            });
        }
        var disableInPrm = _init_prm.valueStr(PRM_DLG_DISABLED);
        if (hasStrValue(disableInPrm)) {
            jQuery.each(disableInPrm.split(','), function(i, c_id) {
                if (jQuery.inArray( c_id, res) < 0) {
                    res.push(c_id);
                }
            });
        }
        return res;
    };

    var enableComponents = function () {
        var allIds = getComponentIds();
        var disableIds = getDisableIds();
        jQuery.each(allIds, function(i, id) {
            var components = findComponentsById(id);
            jQuery.each(components, function(i, component) {
                if (hasValue(component.enabled) && $.isFunction(component.enabled)) {
                    if (jQuery.inArray(id, disableIds) < 0) {
                        component.enabled(true);
                    } else {
                        component.enabled(false);
                    }

                }
            });
        });
    };

    var findComponentsById = function (id) {
        var res = [];
        jQuery.each(_components, function(i, component) {
            if (hasValue(component.id) && $.isFunction(component.id)) {
                var c_id = component.id();
                if (strEqualsIgnoreCase(c_id, id)) {
                    res.push(component);
                }
            }
        });
        return res;
    };

    var checkRequiredParam;
    checkRequiredParam = function (ok_callback) {
        var req = _dlg_descr.value(PRM_DLG_REQUIRED_PARAMS);
        var names = [];
        var messages = [];
        if (hasValue(req) && req.asArrayValue().length > 0) {
            var arr = req.asArrayValue();
            jQuery.each(arr, function (i, val) {
                names.push(val.name());
                messages.push(val.getStringValue());
            });
        } else {
            var reqStr = _dlg_descr.valueStr(PRM_DLG_REQUIRED_PARAMS);
            if (hasStrValue(reqStr)) {
                jQuery.each(reqStr.split(','), function (i, val) {
                    names.push(val);
                    messages.push(null);
                });
            }
        }
        var errors = new QNode();
        jQuery.each(names, function (i, val) {
            if (!hasStrValue(_data.valueStr(val))) {
                var message = messages[i];
                if (!hasStrValue(message)) {
                    message = 'Не указан параметр ' + val;
                }
                var error = new QNode("error");
                //error.add("code", new QText(val));
                error.add("message", new QText(message));
                errors.add(error);
            }

        });

        if (errors.empty()) {
            ok_callback();
        } else {
            showError("Не указано", errors);
        }

    };

    var saveParam = function (ok_callback) {
        bindInput2Data();

        var data = {};
        if (hasStrValue(_action)) {
            data['@action'] = _action;
        } else {
            data['@action'] = 'save';
        }
        if (strEquals(_operation, 'edit')){
            data['@object'] = _obj_update;
            data['@id'] = _data_id;
        } else {
            data['@object'] = _obj_insert;
        }
        checkRequiredParam(
            function () {
                jQuery.each(_data.asArrayValue(), function(i, val) {
                    data[val.name()] = val.getStringValue();
                });
                get_xml_data({
                    url: getUrl(),
                    data: data,
                    ok_callback: function() {
                        if (hasStrValue(_dlg_descr.valueStr(PRM_DLG_OK_MESSAGE))) {
                            showMessage(_dlg_descr.valueStr(PRM_DLG_OK_MESSAGE));
                        }
                        ok_callback();
                    },
                    error_callback: function (data) {
                        if (hasStrValue(_dlg_descr.valueStr(PRM_DLG_FAIL_MESSAGE))) {
                            showError(_dlg_descr.valueStr(PRM_DLG_FAIL_MESSAGE), data);
                        } else {
                            showError('Ошибка сохранения параметров', data);
                        }
                    }
                });
            }
        );
    };

    var deleteParam = function (callback) {
        var data_str = "@action=delete&@object="+_obj_delete+"&@id="+_data_id;
        get_xml_data({
            url: getUrl(),
            data: data_str,
            ok_callback: function() {
                callback();
                if ( _init_prm.valueStr(PRM_DLG_OK_CALLBACK) != null ) {
                    eval(_init_prm.valueStr(PRM_DLG_OK_CALLBACK));
                }
            },
            error_callback: function () {
                showError('Ошибка удаления');
            }
        });
    };
    this.keydown = function(target, e){
        if (e.getKey() == e.F2 ) {
            e.stopEvent();
//            console.log('press f2');
            dialog_save();
        }else if (e.getKey() == e.F10) {
            e.stopEvent();
//            console.log('press f10');
            dialog_cancel();
        }
    };

    var add = function (object) {
        _components.push(object);
        var extComponent = object.component();
        _main_panel.add(extComponent);
        extComponent.on('keydown', that.keydown);
    };

    var addDialogComponent = function (object) {
        if (object instanceof QNode) {
            var object_type = object.name();
            if (object_type == 'string') {
                add(new QComponentString(that, object));
            } else if (object_type == 'text') {
                add(new QComponentText(that, object));
            } else if (object_type == 'date') {
                add(new QComponentDate(that, object));
            } else if (object_type == 'list') {
                add(new QComponentList(that, object));
            } else if (object_type == 'spr') {
                add(new QComponentSpr(that, object));
            } else if (object_type == 'checkbox') {
                add(new QComponentCheckbox(that, object));
            } /*else if (object_type == 'select') {
             _components.push(new QComponentSelect(that, object));
             } else if (object_type == 'commands') {
             _components.push(new QComponentCommands(that, object));
             } else if (object_type == 'label') {
             _components.push(new QComponentLabel(that, object));
             } else if (object_type == 'upload') {
             _components.push(new QComponentUpload(that, object));
             }*/
        }
    };

}

