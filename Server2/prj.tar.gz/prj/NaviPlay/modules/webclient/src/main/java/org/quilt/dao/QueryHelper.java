package org.quilt.dao;

/**
 * Provide access to query stored into db.
 *
 * @author <a href="mailto:vbelokon@luxoft.com">Vasily Belokon</a>
 * @version 1.0
 */
public class QueryHelper {

    public static String findQuery(String fullName) {
        return QuiltObjectHelper.fetchObject(fullName, "query");
    }

}
