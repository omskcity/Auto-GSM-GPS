package org.quilt.web;

import com.navi.core.client.DeviceStatus;
import com.navi.core.jms.Sender;
import com.navi.core.client.messages.GetDeviceListRequest;
import com.navi.core.client.messages.toClient.GetDeviceListResponse;
import com.navi.core.client.messages.toDevice.ToDeviceRequest;
import org.apache.log4j.Logger;

import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.servlet.http.HttpSession;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.io.Serializable;
import java.util.Map;

/**
 * Controller for get information from naviPlay client server and send command.
 *
 * @author vbelokon
 */
public final class NaviController extends AbstractDataControllerEx {

    private final Logger log = Logger.getLogger(NaviController.class);
    private final static String DEVICE = "device";
    private final static String ACTION_GET_LIST = "get_list";
    private final static String ACTION_SEND_COMMAND = "send_command";
    private final static String PARAM_NAME_COMMAND = "command";
    private final static String PARAM_NAME_DEVICE = "device";
    private final static String PARAM_NAME_ACTION_ = "action";
    private Sender clientServer;


    public NaviController(Sender clientServer) {
        this.clientServer = clientServer;
    }


    @Override
    public DataResult doAction(final Map<String, Object> params, HttpSession session) throws Exception {

        DataResult result = new DataResult();
        final String object = getString(params.get(PARAM_NAME_OBJECT));
        final String action = getString(params.get(PARAM_NAME_ACTION_));
        if (DEVICE.equalsIgnoreCase(object)) {
            if (ACTION_GET_LIST.equalsIgnoreCase(action)) {
                GetDeviceListRequest request = new GetDeviceListRequest();
                Message message = clientServer.request(request);
                if (message != null) {
                    if (message instanceof ObjectMessage) {
                        Object obj = ((ObjectMessage) message).getObject();
                        if (obj != null) {
                            if (obj instanceof GetDeviceListResponse) {
                                GetDeviceListResponse response = (GetDeviceListResponse) obj;
                                result.setOk(true);
                                for (DeviceStatus data : response.getData()) {
                                    ResultNode device = new ResultNode("device");
                                    for (PropertyDescriptor pd : Introspector.getBeanInfo(data.getClass()).getPropertyDescriptors()) {
                                        if (pd.getReadMethod() != null && !"class".equals(pd.getName()))
                                            if (pd.getReadMethod().invoke(data) == null) {
                                                device.addNested(new ResultNode(pd.getName(), ""));
                                            } else {
                                                device.addNested(new ResultNode(pd.getName(), pd.getReadMethod().invoke(data)));
                                            }
                                    }
                                    result.addData(device);
                                }
                            }

                        }
                    }
                }
                return result;
            } else if (ACTION_SEND_COMMAND.equalsIgnoreCase(action)) {
                final String command = getString(params.get(PARAM_NAME_COMMAND));
                final String device = getString(params.get(PARAM_NAME_DEVICE));
                Object  obj = Class.forName(command).newInstance();
                Integer deviceNum = null;
                try {
                    deviceNum = Integer.valueOf(device);
                } catch (Exception e) {
                    log.error(e.getMessage(), e);
                }
                if (obj instanceof ToDeviceRequest) {
                    ((ToDeviceRequest)obj).setDeviceNum(deviceNum);
                }
                if (obj instanceof Serializable) {
                    clientServer.sendNow((Serializable)obj);
                    result.setOk(true);
                }
            }
        }
        return result;
    }

}
