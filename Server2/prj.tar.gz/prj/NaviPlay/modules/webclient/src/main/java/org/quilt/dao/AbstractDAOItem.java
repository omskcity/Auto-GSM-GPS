/**
 * This code contains copyright information which is the proprietary property
 * of SITA Information Network Computing Limited (SITA). No part of this
 * code may be reproduced, stored or transmitted in any form without the prior
 * written permission of SITA.
 *
 * Copyright (C) SITA Information Network Computing Limited 2009-2012.
 * All rights reserved.
 */
package org.quilt.dao;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;

/**
 * Class implement casts methods for objects from DB.
 *
 * @author <a href="mailto:vbelokon@luxoft.com">Vasily Belokon</a>
 * @version 1.0
 */
public class AbstractDAOItem {

    protected Date getDate(Object obj) {
        if (obj instanceof Timestamp) {
            return new Date(((Timestamp) obj).getTime());
        }
        return null;
    }

    protected Boolean getBoolean(Object obj) {
        if (obj != null) {
            if (obj instanceof Boolean) {
                return (Boolean) obj;
            } else if (obj instanceof String) {
                return Boolean.getBoolean ((String) obj) ;
            } else if (obj instanceof Number) {
                return ((Integer) obj) == 1;
            }
        }
        return false;
    }

    protected String getString(Object obj) {
        if (obj != null) {
            if (obj instanceof String) {
                return (String) obj;
            } else if (obj instanceof Integer) {
                return Integer.toString ((Integer) obj);

            } else {
                return obj.toString();
            }
        }
        return null;
    }

    protected Integer getInteger(Object obj) {
        if (obj != null) {
            if (obj instanceof Integer) {
                return (Integer) obj;
            } else if (obj instanceof String) {
                return (Integer.decode( (String) obj));

            }
        }
        return null;
    }

    protected BigDecimal getBigDecimal(Object obj) {
        if (obj != null) {
            if (obj instanceof Integer) {
                return  new BigDecimal((Integer) obj);
            } else if (obj instanceof String) {
                return ( new BigDecimal( (String) obj));

            } else if (obj instanceof BigDecimal) {
                return ( (BigDecimal)  obj);

            }
        }
        return null;
    }

}
