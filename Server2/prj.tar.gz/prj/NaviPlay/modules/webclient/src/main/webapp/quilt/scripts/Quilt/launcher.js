function QLaunchers (container) {
    var _container = container;
    var _items = [];
    var addItem = function (pname, pexecutor) {
        var item = new QLauncherItem(pname, pexecutor);
        _items.push(item);
        return item;
    };

    this.init = function () {
        clean();
        load();
        jQuery.each(_items, function(i, item) {
            var btn = Ext.create('Ext.Button', {
                text    : item.name(),
                handler : item.executor()
            });
            _container.add(btn);
            btn.show();
        });
    };
    var clean = function () {
        _container.removeAll();
        _items = [];
    };

    var load = function () {
        get_xml_data({
            object: 'available_launchers',
            data:  {},
            ok_callback: function (data) {
                if (data instanceof QNode) {
                    jQuery.each(data.asArrayValue(), function(i, row) {
                        addItem(
                            row.valueStr('name')
                            ,function () {

                                executeCommand(row.valueStr('data'));

                                return false;
                            }
                        );
                    });
                }
            },
            error_callback: function (data) {
                showError('Ошибка получения списка ярлыков', data);
            }

        });
    };
    this.init();
}

function QLauncherItem (pname, pexecutor) {
    var _name;
    var _executor;
    this.name = function (pvalue) {
        if (pvalue == undefined) {
            return _name;
        } else {
            _name = pvalue;
        }
        return true;
    };

    this.executor = function (pvalue) {
        if (pvalue == undefined) {
            return _executor;
        } else {
            _executor = pvalue;
        }
        return true;
    };

    this.name(pname);
    this.executor(pexecutor);
}

var launchers = new QLaunchers(mainTaskBar) ;


