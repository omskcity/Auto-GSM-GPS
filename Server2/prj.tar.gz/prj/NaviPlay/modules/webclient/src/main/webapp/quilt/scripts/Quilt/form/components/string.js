Ext.require([
    'Ext.layout.container.Absolute'
]);
function QComponentString (dialog, prm) {

    var _dialog = dialog;
    var _component;
    var that=this;
    var _based_label_width;

    var _id = prm.valueStr(PRM_DLG_COMPONENT_ID);

    this.id = function () {
        return _id;
    };

    this.bindValue2Data = function() {
        _dialog.getData().value(_id, _component.getValue());
    };

    this.bindData2Value = function() {
        _component.setValue(_dialog.getData().valueStr(_id));
    };
    this.clear = function() {
        _component.setValue();
    };

    this.focus = function() {
        _component.focus(true, 10);
    };

    this.labelWidth = function(pvalue) {
        if (pvalue == undefined) {
            if (!hasValue(_based_label_width))  {
                _based_label_width = _component.labelWidth;
            }
            return _based_label_width;
        } else {
            _component.labelWidth = pvalue
        }
    };

    var _enabled = !isTrue(prm.valueStr(PRM_DLG_DISABLED));
    this.enabled = function(pvalue) {
        if (pvalue == undefined) {
            return _enabled;
        } else {
            _enabled = pvalue;
            _component.setDisabled(!_enabled);
        }
    };

    this.componentWidth = function() {
        return _component.getWidth();
    };

    this.component = function() {
        return _component;
    };
    var create = function (object_params) {
        var type = object_params.valueStr('type');
        if (strEqualsIgnoreCase(type, 'password')) {
            _component = new Ext.form.field.Text({
                inputType: 'password',
                labelAlign: "right",
                enableKeyEvents: true
            });

        } else {
            _component = new Ext.form.field.Text({
                labelAlign: "right",
                enableKeyEvents: true
            });
        }

        _component.setWidth(object_params.valueStr(PRM_DLG_COMPONENT_WIDTH));
        _component.setFieldLabel(object_params.valueStr(PRM_DLG_COMPONENT_LABEL));
        that.enabled(_enabled);
        _based_label_width = _component.labelWidth;
        console.log('created string');
    };

    create(prm);

}
