package org.quilt.web;

import org.quilt.dao.DAOObject;
import org.springframework.util.StringUtils;
import javax.servlet.http.HttpSession;
import java.util.Map;

/**
 * Controller for access to data from dialog. 
 * 
 * @author vbelokon
 * 
 */
public final class SessionDataController extends AbstractDataControllerEx {

    private static final String PARAM_NAME_ACTION = "@action";
    private static final String ACTION_SAVE = "save";
    private static final String ACTION_DISPLAY = "display";

    public DataResult doAction(Map<String, Object> params, HttpSession session) throws Exception {
        
        final String action = getString(params.get(PARAM_NAME_ACTION));
        final String param_name = getString(params.get(DAOObject.PARAM_NAME_ID));
        final String param_value = getString(params.get(param_name));
        DataResult result = new DataResult();
        if (ACTION_SAVE.equalsIgnoreCase(action)) {
            if (StringUtils.hasLength(param_name)){
                if (StringUtils.hasLength(param_value)) {
                    session.setAttribute(param_name, param_value);
                } else {
                    session.removeAttribute(param_name);
                }
            }
            result.setOk(true);
            return result;
        } else if (ACTION_DISPLAY.equalsIgnoreCase(action)) {
            if (StringUtils.hasLength(param_name)) {
                result.addData(new ResultNode(param_name, session.getAttribute(param_name)));
                result.setOk(true);
                return result;
            } else {
                result.addError(new ResultNode("error", "Не указан параметр " + DAOObject.PARAM_NAME_ID));
            }
        }

        return result;
    }

}
