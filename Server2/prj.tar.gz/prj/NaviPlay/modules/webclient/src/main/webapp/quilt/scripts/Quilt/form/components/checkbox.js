Ext.require([
    'Ext.layout.container.Absolute', 'Ext.form.field.Checkbox'
]);
function QComponentCheckbox (dialog, prm) {

    var _dialog = dialog;
    var _component;
    var that=this;
    var _based_label_width;
    var _value_checked = 1;
    var _value_unchecked = 0;

    var _id = prm.valueStr(PRM_DLG_COMPONENT_ID);

    this.id = function () {
        return _id;
    };

    this.bindValue2Data = function() {
        if (isTrue(_component.getValue())) {
            _dialog.getData().value(_id, _value_checked);
        } else {
            _dialog.getData().value(_id, _value_unchecked);
        }
    };

    this.bindData2Value = function() {

        var val = _dialog.getData().valueStr(_id);
        if (strEqualsIgnoreCase(val, _value_checked)) {
            _component.setValue(true);
        } else {
            _component.setValue(false);
        }
    };
    this.clear = function() {
        _component.setValue();
    };

    this.focus = function() {
        _component.focus(true, 10);
    };

    this.labelWidth = function(pvalue) {
        if (pvalue == undefined) {
            if (!hasValue(_based_label_width))  {
                _based_label_width = _component.labelWidth;
            }
            return _based_label_width;
        } else {
            _component.labelWidth = pvalue
        }
        return true;
    };

    var _enabled = !isTrue(prm.valueStr(PRM_DLG_DISABLED));
    this.enabled = function(pvalue) {
        if (pvalue == undefined) {
            return _enabled;
        } else {
            _enabled = pvalue;
            _component.setDisabled(!_enabled);
        }
        return true;
    };

    this.componentWidth = function() {
        return _component.getWidth();
    };

    this.component = function() {
        return _component;
    };
    var create = function (object_params) {
        _component = new Ext.form.field.Checkbox({
            labelAlign: "right",
            enableKeyEvents: true
        });

        _component.setWidth(object_params.valueStr(PRM_DLG_COMPONENT_WIDTH));
        _component.setFieldLabel(object_params.valueStr(PRM_DLG_COMPONENT_LABEL));
        that.enabled(_enabled);
        _based_label_width = _component.labelWidth;
        console.log('created checkbox');
    };

    create(prm);

}

/*
function QComponentCheckBox (dialog, prm) {
    var _dialog = dialog;
    var _value_checked = 1;
    var _value_unchecked = 0;
    var _component;

    var _input;
    var _id = prm.valueStr(PRM_DLG_COMPONENT_ID);

    this.id = function () {
        return _id;
    };

    this.bindValue2Data = function() {
        if (hasValue(_input.attr("checked"))) {
            _dialog.getData().value(_id, _value_checked);
        } else {
            _dialog.getData().value(_id, _value_unchecked);
        }
    };

    this.bindData2Value = function() {
        var val = _dialog.getData().valueStr(_id);
        if (strEqualsIgnoreCase(val, _value_checked)) {
            _input.attr("checked", "checked");
        } else {
            _input.removeAttr("checked");
        }
    };

    this.clear = function() {
        if (strEqualsIgnoreCase('', _value_checked)) {
            _input.attr("checked", "checked");
        } else {
            _input.removeAttr("checked");
        }
    };

    var _enabled = !isTrue(prm.valueStr(PRM_DLG_DISABLED));
    this.enabled = function(pvalue) {
        if (pvalue == undefined) {
            return _enabled;
        } else {
            _enabled = pvalue;
            if (_enabled) {
                _input.removeAttr('disabled');
                _component.removeClass('disabled');
            } else {
                _component.addClass('disabled');
                _input.attr('disabled','disabled');
            }
        }
    };

    var create = function (object_params) {
        var param_names = [PRM_DLG_COMPONENT_ID, PRM_DLG_COMPONENT_LABEL, PRM_DLG_COMPONENT_VALUE, PRM_DLG_COMPONENT_WIDTH];
        var str = '';
        str = str + '<div class=\"dialog-element\">';
        str = str + '<div class=\"dialog-element-label\">';
        str = str + '<label for=\"${id}\">${label}</label>';
        str = str + '</div>';
        str = str + '<div class=\"dialog-element-content\">';
        str = str + '<input class=\"text ui-widget-content ui-corner-all\" type=\"checkbox" id=\"${id}\" name=\"${id}\" value=\"${value}\" size=\"${size}\" style=\"width: ${width}\"/>';
        str = str + '</div>';
        str = str + '</div>';
        jQuery.each(param_names, function(i, val) {
            var param_value = object_params.valueStr(val);
            if (!hasStrValue(param_value)) {
                param_value = '';
            }
            str = str.replace(new RegExp('\\$\\{' + val +'\\}', 'g'), param_value);
        });

        _component = $(str).appendTo(_dialog.getHTMLDiv());
        _input = _component.find('input');
    };

    create(prm);

}
*/