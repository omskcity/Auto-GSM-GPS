function QListToolbarBtn(title, executor, icon) {
    var _btn;
    var _for_selection;
    var _handler;

    this.for_selection = function (value) {
        if (value == undefined) {
            return _for_selection;
        } else {
            _for_selection = value;
        }
        return true;
    };

    this.executor = function(value) {
        if (value != undefined) {
            _handler = value;
            _btn.setHandler(value);
        } else {
            return _handler;
        }
        return true;
    };

    this.extBtn = function() {
        return _btn;
    };

    this.label = function(value) {
        if (value == undefined) {
            return _btn.getText();
        } else {
            _btn.setText(value);
        }
        return true;
    };

    this.icon = function(value) {
        if (value == undefined) {
            return 'def';
        } else {
        }
        return true;
    };

    this.disable = function() {
        _btn.setDisabled(true);
    };

    this.enable = function() {
        _btn.setDisabled(false);
    };

    var create  = function(title, executor /*, icon*/) {
        _btn = Ext.create('Ext.Button', {
            text    : title,
            handler : executor
        });
    };

    create(title, executor, icon);


}

function QListToolbar(_component) {
    var _toolbar;
    var _btns = [];

    this.add = function(btn) {
        _btns.push(btn);
        if (btn instanceof QListToolbarBtn) {
            _toolbar.add(btn.extBtn());
        } else {
            _toolbar.add(btn);
        }

    };

    this.calcBtnEnable = function (_grid) {
        var s = _grid.getSelectionModel().getSelection();
        jQuery.each(_btns, function(i, btn) {
            try {
                if (btn instanceof QListToolbarBtn) {
                    if (isTrue(btn.for_selection())) {
                        //console.log('for_selection');
                        if (s.length > 0) {
                            btn.enable();
                        } else {
                            btn.disable();
                        }
                    } else {
                        //console.log('not for_selection');
                        btn.enable();
                    }
                }
                //console.log('btn ' + btn.label() + ' ' +btn.for_selection());
            } catch (ex) {
                //console.log(ex);
            }
        });
    };

    this.getMenuItems = function (_grid) {
        var s = _grid.getSelectionModel().getSelection();
        var  result = [];

        jQuery.each(_btns, function(i, btn) {
            try {
                if (btn instanceof QListToolbarBtn) {
                    var active = false;
                    //console.log('btn ' + btn.label() + ' ' +btn.for_selection());
                    if (isTrue(btn.for_selection())) {
                        //console.log('for_selection');
                        active = s.length > 0;
                    } else {
                        active = true;
                    }
                    if (active) {
                        result.push({
                            text: btn.label(),
                            handler: btn.executor()
                        });
                    }
                } else {
                    result.push({
                        xtype: 'menuseparator'
                    })
                }
            } catch (ex) {
                //console.log(ex);
            }
        });
        return result;
    };

    var create = function () {
        _toolbar = new Ext.toolbar.Toolbar({anchor :'100%' });

        _component.add(_toolbar);
    };
    create();

}
