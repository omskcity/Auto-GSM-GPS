/**
 * This code contains copyright information which is the proprietary property
 * of SITA Information Network Computing Limited (SITA). No part of this
 * code may be reproduced, stored or transmitted in any form without the prior
 * written permission of SITA.
 *
 * Copyright (C) SITA Information Network Computing Limited 2009-2012.
 * All rights reserved.
 */
package org.quilt.web;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

/**
 * Node of data in result DataController
 *
 * @author <a href="mailto:vbelokon@luxoft.com">Vasily Belokon</a>
 * @version 1.0
 */
public class ResultNode  {

    private String name;

    private Object value;

    private List<ResultNode> nested = new ArrayList<ResultNode>();

    public ResultNode (String name) {
        setName(name);
    }

    public ResultNode (String name, Object value) {
        setName(name);
        this.value = value;
    }


    protected String xmlEscapeObject(Object t) {
        if (t != null) {
            return xmlEscapeText(t.toString());
        }
        return "";
    }

    protected String xmlEscapeText(String t) {
        StringBuilder sb = new StringBuilder();
        for(int i = 0; i < t.length(); i++){
            char c = t.charAt(i);
            switch(c){
                case '<': sb.append("&lt;"); break;
                case '>': sb.append("&gt;"); break;
                case '\"': sb.append("&quot;"); break;
                case '&': sb.append("&amp;"); break;
                case '\'': sb.append("&apos;"); break;
                default:
                    if(c>0x7e) {
                        sb.append("&#").append((int) c).append(";");
                    }else
                        sb.append(c);
            }
        }
        return sb.toString();
    }

    public void addNested(ResultNode nestedNode) {
        nested.add(nestedNode);
    }

    public void setName(final String name) {
        this.name = name;
    }

    public void write(Writer out) throws IOException {
        out.write("<" + name + ">");
        if (value != null) {
            out.write(xmlEscapeObject(value));
        }
        for (ResultNode node : nested) {
            node.write(out);
        }
        out.write("</" + name + ">");

    }
}
