package org.quilt.dao;

import org.apache.commons.lang.StringUtils;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import org.apache.log4j.Logger;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Provide access to quilt object stored into db.
 *
 * @author <a href="mailto:vbelokon@luxoft.com">Vasily Belokon</a>
 * @version 1.0
 */
public class QuiltObjectHelper {

    private static final Logger log = Logger.getLogger(QuiltObjectHelper.class);

    private final static Cache<String, String> cached = CacheBuilder.newBuilder()
        .concurrencyLevel(4)
            //        .weakKeys()
        .maximumSize(10000)
//        .expireAfterWrite(Context.getInstance().getPartnerCacheOutdateHour(), TimeUnit.HOURS)
        .build();

    public static String fetchObject(String name, String type) {
        return fetchObject(name, type, true);

    }
    public static String fetchObject(String name, String type, boolean useCache) {
        String res = null;
        if (useCache) {
            res = cached.getIfPresent("type:"+type+"&name:"+name);
        }
        if (res == null) {
            Map<String, Object> args = new HashMap<String, Object>();
            args.put("name", name);
            args.put("type", type);
            Map<String, Object> row = null;
            try {
                row = DAOObject.findObject("select o.data from q_object o, q_object_type ot where "
                                           + "lower(o.name)=lower(:name) "
                                           + "and o.object_type_id=ot.id "
                                           + "and lower(ot.name)=lower(:type) "
                ).getRow(args);
            }
            catch (DAOException e) {
                log.error(e.getMessage(), e);
            }

            if (!StringUtils.isBlank(res)) {
                cached.put("type:"+type+"&name:"+name, res);
            }
            if (row != null) {
                res = row.get("data").toString();
            }
        }
        return res;
    }

}
