Ext.require([
    'Ext.form.field.Date'
]);
function QComponentDate (dialog, prm) {
    var _dialog = dialog;
    var _component;
    var _id = prm.valueStr(PRM_DLG_COMPONENT_ID);
    var _based_label_width;
    var that= this;
    var _enabled = !isTrue(prm.valueStr(PRM_DLG_DISABLED));

    this.id = function () {
        return _id;
    };

    this.bindValue2Data = function() {
        _dialog.getData().value(_id, _component.getValue());
    };

    this.bindData2Value = function() {
        _component.setValue(_dialog.getData().valueStr(_id));
    };
    this.clear = function() {
        _component.setValue();
    };

    this.labelWidth = function(pvalue) {
        if (pvalue == undefined) {
            if (!hasValue(_based_label_width))  {
                _based_label_width = _component.labelWidth;
            }
            return _based_label_width;
        } else {
            _component.labelWidth = pvalue
        }
    };

    this.enabled = function(pvalue) {
        if (pvalue == undefined) {
            return _enabled;
        } else {
            _enabled = pvalue;
            if (_component.isDisabled( ) == _enabled) {
                _component.setDisabled(!_enabled);
            }

        }
    };

    this.componentWidth = function() {
        return _component.getWidth();
    };

    var create = function (object_params) {
        _component = new Ext.form.field.Date({labelAlign: "right"});
        _component.setWidth(object_params.valueStr(PRM_DLG_COMPONENT_WIDTH));
        _component.setFieldLabel(object_params.valueStr(PRM_DLG_COMPONENT_LABEL));
        that.enabled(_enabled);
        _based_label_width = _component.labelWidth;
        _dialog.getWindow().add(_component);
    };

    create(prm);

}
