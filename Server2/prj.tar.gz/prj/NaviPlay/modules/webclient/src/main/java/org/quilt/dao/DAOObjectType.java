/**
 * This code contains copyright information which is the proprietary property
 * of SITA Information Network Computing Limited (SITA). No part of this
 * code may be reproduced, stored or transmitted in any form without the prior
 * written permission of SITA.
 *
 * Copyright (C) SITA Information Network Computing Limited 2009-2012.
 * All rights reserved.
 */
package org.quilt.dao;

import java.util.EnumSet;

/**
 * TODO: describe.
 *
 * @author <a href="mailto:vbelokon@luxoft.com">Vasily Belokon</a>
 * @version 1.0
 */
public enum DAOObjectType {
    Table("table"),
    View("view"),
    Procedure("procedure"),
    Function("function"),
    SQL("sql"),
    Script("script");
    private String value;

    DAOObjectType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static DAOObjectType getByValue(String code){
        DAOObjectType returnValue = null;
        for (final DAOObjectType element : EnumSet.allOf(DAOObjectType.class)) {
            if (element.getValue().equalsIgnoreCase(code)) {
                returnValue = element;
            }
        }
        return returnValue;
    }

}
