function executeCommand(arg1, callback) {
    var prm;
    if (arg1 != undefined ) {
        if (arg1 instanceof QNode) {
            prm = arg1;
        } else {
            prm = new QNode(arg1);
        }
        var command_name = prm.name();
        //console.log("execute command", prm.toString());
        if (hasStrValue(command_name)) {
            if(strEquals(command_name, QDialogManager.cmd)) {
                QDialogManager.execute(prm, callback);
            } else if(strEquals(command_name, QListManager.cmd)) {
                QListManager.execute(prm, callback);
            } else if(strEquals(command_name, QRequestManager.cmd)) {
                QRequestManager.execute(prm, callback);
            }

        }
    }
}

