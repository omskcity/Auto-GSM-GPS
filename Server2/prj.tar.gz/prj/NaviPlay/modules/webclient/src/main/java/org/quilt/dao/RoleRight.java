/**
 * This code contains copyright information which is the proprietary property
 * of SITA Information Network Computing Limited (SITA). No part of this
 * code may be reproduced, stored or transmitted in any form without the prior
 * written permission of SITA.
 *
 * Copyright (C) SITA Information Network Computing Limited 2009-2012.
 * All rights reserved.
 */
package org.quilt.dao;

import org.apache.log4j.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Class bean from role_right.
 *
 * @author <a href="mailto:vbelokon@luxoft.com">Vasily Belokon</a>
 * @version 1.0
 */
public class RoleRight extends AbstractDAOItem {

    private final Logger log = Logger.getLogger(RoleRight.class);

    private String objectMask;
    private Boolean hasS;
    private Boolean hasI;
    private Boolean hasU;
    private Boolean hasD;
    private Boolean hasE;
    private Pattern pattern;

    public String getObjectMask() {
        return objectMask;
    }

    public void setObjectMask(final String objectMask) {
        this.objectMask = objectMask;
    }

    public Boolean getHasS() {
        return hasS;
    }

    public void setHasS(final Boolean hasS) {
        this.hasS = hasS;
    }

    public Boolean getHasI() {
        return hasI;
    }

    public void setHasI(final Boolean hasI) {
        this.hasI = hasI;
    }

    public Boolean getHasU() {
        return hasU;
    }

    public void setHasU(final Boolean hasU) {
        this.hasU = hasU;
    }

    public Boolean getHasD() {
        return hasD;
    }

    public void setHasD(final Boolean hasD) {
        this.hasD = hasD;
    }

    public Boolean getHasE() {
        return hasE;
    }

    public void setHasE(final Boolean hasE) {
        this.hasE = hasE;
    }

    public void setRow(Map<String, Object> row) {
        setObjectMask(getString(row.get("object_mask")));
        setHasS(getBoolean(row.get("for_select")));
        setHasI(getBoolean(row.get("for_insert")));
        setHasU(getBoolean(row.get("for_update")));
        setHasD(getBoolean(row.get("for_delete")));
        setHasE(getBoolean(row.get("for_execute")));
    }

    public Map<String, Object> getRow() {
        Map<String, Object> row = new HashMap<String, Object>();
        row.put("object_mask", getObjectMask());
        row.put("for_select", getHasS());
        row.put("for_insert", getHasI());
        row.put("for_update", getHasU());
        row.put("for_delete", getHasD());
        row.put("for_execute", getHasE());
        return row;
    }

    public static RoleRight getInstanceFromRow(Map<String, Object> row) {
        RoleRight rr = new RoleRight();
        rr.setRow(row);
        return rr;
    }

    public Boolean nameMatched(String name) {
        try {
            if (pattern == null) {
                pattern = Pattern.compile(objectMask, Pattern.MULTILINE | Pattern.DOTALL | Pattern.CASE_INSENSITIVE);
            }
            Matcher m = pattern.matcher(name);
            return m.matches();
        } catch (Exception e) {
            log.error(e.getMessage(), e);
        }
        return false;
    }
}
