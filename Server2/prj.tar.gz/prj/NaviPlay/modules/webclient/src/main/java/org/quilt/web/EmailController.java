package org.quilt.web;

import org.apache.commons.lang.StringUtils;
import org.quilt.dao.QueryHelper;

import javax.servlet.http.HttpSession;
import java.util.Map;

/**
 * Controller for send email message with template.
 *
 * @author vbelokon
 */
public final class EmailController extends AbstractDataControllerEx {
    protected static final String ACTION_SEND_TO = "send_to";
    protected static final String ACTION_SEND_TO_ALL = "send_to_all";
    protected static final String ACTION_SEND_TO_ROLE = "send_to_role";
    protected static final String ACTION_SEND_TO_LOGIN = "send_to_login";

    protected static final String PARAM_SPLIT_MESSAGES = "@split";
    protected static final String PARAM_NAME_EMAIL = "@email";
    protected static final String PARAM_NAME_ROLE = "@role";
    protected static final String PARAM_NAME_LOGIN = "@login";
    protected static final String PARAM_NAME_TEMPLATE = "@template";
    protected static final String PARAM_NAME_FROM = "@from";
    protected static final String PARAM_NAME_SUBJ = "@subj";

    @Override
    public DataResult doAction(final Map<String, Object> params, HttpSession session) throws Exception {
        final String action = getString(params.get(PARAM_NAME_ACTION));
        final String from = getString(params.get(PARAM_NAME_FROM));
        final String subj = getString(params.get(PARAM_NAME_SUBJ));
        final String temlate = getString(params.get(PARAM_NAME_TEMPLATE));
        //TODO change template holder
        QueryHelper.findQuery(temlate);
        DataResult result = new DataResult();
        if (ACTION_SEND_TO.equalsIgnoreCase(action)) {
            String email = getString(params.get(PARAM_NAME_EMAIL));
            if (StringUtils.isNotBlank(email)) {
                try {
                    //TODO implement call meail service
                    result.setOk(true);
                } catch (Exception e) {
                    result.addError(e);
                }
            }
            return result;
        } else {
                result.setOk(false);
        }
        return result;
    }

}
