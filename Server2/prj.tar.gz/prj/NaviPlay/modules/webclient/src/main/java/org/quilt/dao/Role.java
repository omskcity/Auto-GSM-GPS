/**
 * This code contains copyright information which is the proprietary property
 * of SITA Information Network Computing Limited (SITA). No part of this
 * code may be reproduced, stored or transmitted in any form without the prior
 * written permission of SITA.
 *
 * Copyright (C) SITA Information Network Computing Limited 2009-2012.
 * All rights reserved.
 */
package org.quilt.dao;

import org.apache.log4j.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Role entity. for grant system.
 *
 * @author <a href="mailto:vbelokon@luxoft.com">Vasily Belokon</a>
 * @version 1.0
 */
public class Role extends AbstractDAOItem {

    private final static Logger log = Logger.getLogger(Role.class);

    private static final String SQL_ROLE= "select r.* from q_role r where r.name=:role_name";
    private static final String SQL_ROLE_RIGHT= "select rr.* from q_role r, q_role_right rr where rr.role_id = r.id and r.name=:role_name";
    private String name;
    private String descr;
    private List<RoleRight> rights;

    public Role() {
        super();
        rights = new ArrayList<RoleRight>();
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getDescr() {
        return descr;
    }

    public void setDescr(final String descr) {
        this.descr = descr;
    }

    public void setRow(Map<String, Object> row) {
        setName(getString(row.get("name")));
        setDescr(getString(row.get("descr")));
    }

    public Map<String, Object> getRow() {
        Map<String, Object> row = new HashMap<String, Object>();
        row.put("name", getName());
        row.put("descr", getDescr());
        return row;
    }

    public void addRight(RoleRight right) {
        getRights().add(right);
    }

    public List<RoleRight> getRights() {
        return rights;
    }

    public static Role getInstanceByName(String role_name) {
        Map<String, Object> arg = new HashMap<String, Object>();
        arg.put("role_name", role_name);
        Map<String, Object> row = null;
        try {
            row = DAOObject.findObject(SQL_ROLE).getRow(arg);
        } catch (DAOException e) {
            log.error(e.getMessage(), e);
        }
        Role role = new Role();
        if (row != null) {
            role.setRow(row);
            List<Map<String, Object>> rows = null;
            try {
                rows = DAOObject.findObject(SQL_ROLE_RIGHT).getRowList(arg);
            } catch (DAOException e) {
                log.error(e.getMessage(), e);
            }
            if (rows != null) {
                for(Map<String, Object> row_right : rows) {
                    role.addRight(RoleRight.getInstanceFromRow(row_right));
                }
            }
        }
        return role;
    }
}
