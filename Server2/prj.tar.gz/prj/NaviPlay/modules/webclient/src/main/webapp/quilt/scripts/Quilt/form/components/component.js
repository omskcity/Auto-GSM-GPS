Ext.define('Quilt.form.components.Component', {
    /** @readonly */
    isWindow: true,

    var _dialog = dialog;
    var that=this;
    var _id = prm.valueStr(PRM_DLG_COMPONENT_ID);
    var _based_label_width;
    var _enabled = !isTrue(prm.valueStr(PRM_DLG_DISABLED));
    var _component;
    var _value;

    config: {
        initParams: new QNode(),
        dialog: null
    },

    constructor: function(config) {
        this.initConfig(config);

        return this;
    },

    applyTitle: function(title) {
        if (!Ext.isString(title) || title.length === 0) {
            alert('Error: Title must be a valid non-empty string');
        }
        else {
            return title;
        }
    },

    applyBottomBar: function(bottomBar) {
        if (bottomBar && bottomBar.enabled) {
            if (!this.bottomBar) {
                return Ext.create('My.own.WindowBottomBar', bottomBar);
            }
            else {
                this.bottomBar.setConfig(bottomBar);
            }
        }
    }
});

function extend(Child, Parent) {
    var F = function() { };
    F.prototype = Parent.prototype;
    Child.prototype = new F();
    Child.prototype.constructor = Child;
    Child.superclass = Parent.prototype;
}

function QComponent(dialog, prm) {
    var _dialog = dialog;
    var that=this;
    var _id = prm.valueStr(PRM_DLG_COMPONENT_ID);
    var _based_label_width;
    var _enabled = !isTrue(prm.valueStr(PRM_DLG_DISABLED));
    var _component;
    var _value;

    this.id = function () {
        return _id;
    };

    this.bindValue2Data = function() {
        _dialog.getData().value(_id, _value);
    };

    this.bindData2Value = function() {
        _value = _dialog.getData().valueStr(_id);
    };
    this.clear = function() {
        _component.setValue();
    };

    this.labelWidth = function(pvalue) {
        if (pvalue == undefined) {
            if (!hasValue(_based_label_width))  {
                _based_label_width = _component.getLabelWidth();
            }
            return _based_label_width;
        } else {
            _component.setLabelWidth(pvalue);
        }
    };

    this.enabled = function(pvalue) {
        if (pvalue == undefined) {
            return _enabled;
        } else {
            _enabled = pvalue;
        }
    };

    this.componentWidth = function() {
        return 0;
    };

    var create = function (object_params) {
        console.log('not implement create QComponent');
        _component = new Ext.form.field.TextArea({labelAlign: "right"});
        _dialog.add(_component);
        console.log('create width ' + object_params.valueStr(PRM_DLG_COMPONENT_WIDTH) );
        _component.setWidth(object_params.valueStr(PRM_DLG_COMPONENT_WIDTH));
        _component.setHeight(object_params.valueStr(PRM_DLG_COMPONENT_HEIGHT));
        _component.setFieldLabel(object_params.valueStr(PRM_DLG_COMPONENT_LABEL));
        that.enabled(_enabled);
        _based_label_width = _component.labelWidth;
    };

    create(prm);


}