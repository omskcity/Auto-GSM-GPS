var util = {};

util.getBindingByStr = function (str) {
    var binding = {};
    var strParts = str.split('+');
    jQuery.each(strParts, function(i, part) {
        var s = part.trim();
        if ( strEqualsIgnoreCase(s, 'shift')) {
            binding.shift = true;
        } else if ( strEqualsIgnoreCase(s, 'ctrl')){
            binding.ctrl = true;
        } else if ( strEqualsIgnoreCase(s, 'alt')){
            binding.alt = true;
        } else if ( s.length == 1){
            binding.key = Ext.EventObject[s.toUpperCase()];
        } else if ( s.length == 2){
            binding.key = Ext.EventObject[s.toUpperCase()];
        } else {
            binding.key = Ext.EventObject[s.toUpperCase()];
        }
    });
    return binding;
};