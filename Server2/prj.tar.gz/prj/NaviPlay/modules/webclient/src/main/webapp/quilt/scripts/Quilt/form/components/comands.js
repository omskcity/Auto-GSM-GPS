function QComponentCommands (dialog, prm) {
    var _dialog = dialog;
    var _component;
    var _button;
    var _id = prm.valueStr(PRM_DLG_COMPONENT_ID);

    this.id = function () {
        return _id;
    };

    this.bindValue2Data = function() {
    };

    this.bindData2Value = function() {
    };
    this.clear = function() {
    };

    var _enabled = !isTrue(prm.valueStr(PRM_DLG_DISABLED));
    this.enabled = function(pvalue) {
        if (pvalue == undefined) {
            return _enabled;
        } else {
            _enabled = pvalue;
            if (_enabled) {
                _button.removeAttr('disabled');
                _component.removeClass('disabled');
            } else {
                _component.addClass('disabled');
                _button.attr('disabled','disabled');
            }
        }
    };

    var create = function (object_params) {
        var str = '';
        var span;
        span = dialog.getHTMLDiv().find("#dlg-command-toolbar");
        if(!span.get(0)) {
            str =  '<div id="dlg-command-toolbar" class="ui-dialog-buttonset">';
            _component = $(str).appendTo(_dialog.getHTMLDiv());
            span = _dialog.getHTMLDiv().find("#dlg-command-toolbar");
        }
        if (hasStrValue(object_params) && object_params instanceof QNode) {

            jQuery.each(object_params.asArrayValue(), function(i, val) {
                if (hasStrValue(val) && val instanceof QNode) {
                    var cmd_name = val.valueStr('name');
                    var cmd_descr = val.valueStr('cmd');
                    var cmd_icon = val.valueStr('icon');
                    if (!hasStrValue(cmd_icon)) {
                        cmd_icon = "ui-icon-seek-start";
                    }
                    str =   '<button class="q-command-btn">' + cmd_name + '</button>';
                    _button = $(str ).appendTo(span);
                    _button.button({
                        text: false,
                        icons: {
                            primary: cmd_icon
                        }
                    });
                    _button.click(function () {
                        var tmp_prm = new QNode(cmd_descr.toString());
                        paramReplaceWrap(tmp_prm, _dialog.getData() , '%');

                        executeCommand(tmp_prm);
                    });
                }
            });



        }

    };
    create(prm);

}
