function QComponentText (dialog, prm) {
    var that = this;
    var _dialog = dialog;
    var _component;
    var _text;

    var _id = prm.valueStr(PRM_DLG_COMPONENT_ID);
    var _based_label_width;

    this.id = function () {
        return _id;
    };

    this.bindValue2Data = function() {
        _dialog.getData().value(_id, _text.getValue());
    };

    this.bindData2Value = function() {
        _text.setValue(_dialog.getData().valueStr(_id));
    };
    this.clear = function() {
        _text.setValue();
    };

    this.labelWidth = function(pvalue) {
        if (pvalue == undefined) {
            if (!hasValue(_based_label_width))  {
                _based_label_width = _component.labelWidth;
            }
            return _based_label_width;
        } else {
            _component.labelWidth = pvalue
        }
    };

    var _enabled = !isTrue(prm.valueStr(PRM_DLG_DISABLED));
    this.enabled = function(pvalue) {
        if (pvalue == undefined) {
            return _enabled;
        } else {
            _enabled = pvalue;
            if (_enabled) {
                _component.enable();
            } else {
                _component.disable();
            }
        }
    };

    this.componentWidth = function() {
        return _component.getWidth();
    };

    this.component = function() {
        return _component;
    };

    var create = function (object_params) {
        console.log('create text ' + object_params.toString() );
        _component = new Ext.form.field.TextArea({
            grow: true,
            growMax: object_params.valueStr(PRM_DLG_COMPONENT_HEIGHT),
            growMin: object_params.valueStr(PRM_DLG_COMPONENT_HEIGHT),
            width: object_params.valueStr(PRM_DLG_COMPONENT_WIDTH),
            height: object_params.valueStr(PRM_DLG_COMPONENT_HEIGHT),
            enableKeyEvents: true
        });
        _text = _component;
        console.log('create width ' + object_params.valueStr(PRM_DLG_COMPONENT_WIDTH) );
        that.enabled(_enabled);
        _based_label_width = _component.labelWidth;
    };

    create(prm);

}
