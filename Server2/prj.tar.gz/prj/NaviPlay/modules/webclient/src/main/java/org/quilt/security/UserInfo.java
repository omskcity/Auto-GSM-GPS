package org.quilt.security;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.quilt.dao.DAOException;
import org.quilt.dao.DAOObject;
import org.quilt.dao.Role;
import org.quilt.dao.RoleRight;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

public class UserInfo {

    private final static Logger log = Logger.getLogger(UserInfo.class);

    static Map<String,Integer> userIds = new HashMap<String,Integer>();

    private static final String SQL_GET_USER_ID_BY_LOGIN= "select id from q_user where login=:login";
    private static final String SQL_GET_CURR_DATE= "select  {fn CURDATE()} curr_date from dual";



    public static Object getCurrDate(final HttpSession session){
        Object currDate = null;
        if (session.getAttribute("curr_date") != null){
            currDate = session.getAttribute("curr_date").toString();
        } else {
            try {
                currDate = DAOObject.findObject(SQL_GET_CURR_DATE).getRow().get("curr_date");
                setCurrDate(session, currDate);
            } catch (DAOException e) {
                log.error(e.getMessage(), e);
            }
        }
        return currDate;
    }

    public static void setCurrDate(final HttpSession session, final Object currDate) {
        session.setAttribute("curr_date", currDate);
    }

    public static Integer getUserId (){

        User user;
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String login;
        if (principal instanceof String) {
            login = principal.toString();
        } else if (principal instanceof User) {
            user = (User) principal;
            login = user.getUsername();
        } else {
            login = principal.toString();
        }

        Integer result = userIds.get(login);
        if (result == null ){
            Map<String, Object> args = new HashMap<String, Object>();
            args.put("login",login);
            try {
                Map row = DAOObject.findObject(SQL_GET_USER_ID_BY_LOGIN).getRow(args);
                if (row != null) {
                    result = (Integer)row.get("id");
                    userIds.put(login,result);
                } else {
                    result = null;
                }
            } catch (DAOException e) {
                log.error(e.getMessage(), e);
            }

        }
        return result;
    }

    public static void prepareArgs(final Map<String, Object> args, final HttpSession session) {
        for (String key : args.keySet()) {
            if (args.get(key) != null) {
                if ("%CURRENT_USER%".equalsIgnoreCase(args.get(key).toString())) {
                    args.put(key, UserInfo.getUserId().toString());
                }
                if ("%CURRENT_DATE%".equalsIgnoreCase(args.get(key).toString())) {
                    args.put(key, UserInfo.getCurrDate(session));
                }
                if (args.get(key) instanceof String) {
                    String str = (String) args.get(key);
                    if (StringUtils.isBlank(str)) {
                        args.put(key, null);
                    }
                }
            }
        }
    }
    private static String getRolesSqlString() {
        String rolesStr = "";
        for (GrantedAuthority grant : SecurityContextHolder.getContext().getAuthentication().getAuthorities() ) {
            rolesStr = ", \"" + grant.getAuthority() + "\"";
        }

        rolesStr = rolesStr.substring(2);
        return rolesStr;

    }
    public static String prepareScript(final String script, final HttpSession session) {
        String result = script;
        String userId = UserInfo.getUserId() == null ? "" : UserInfo.getUserId().toString();
        result = StringUtils.replace(result, "%CURRENT_USER%", userId);

        result = StringUtils.replace(result, "%ROLES%", getRolesSqlString());
        result = StringUtils.replace(result, "%CURRENT_DATE%", UserInfo.getCurrDate(session).toString());
        return result;
    }

    private static boolean roleHasright(String object, String operation, String role_name) {
        if ("admin".equalsIgnoreCase(role_name)) {
            return true;
        }
        Role role = Role.getInstanceByName(role_name);
        DAOObject daoObject = DAOObject.findObject(object);
        for (RoleRight roleRight : role.getRights()){
            if (roleRight.nameMatched(object)) {
                if (daoObject.isScript()) {
                    if (daoObject.isSQL()) {
                        if (roleRight.getHasS()) {
                            return true;
                        }
                    } else {
                        if (roleRight.getHasE()) {
                            return true;
                        }
                    }
                } else {
                    if ("save".equalsIgnoreCase(operation) && (roleRight.getHasI() || roleRight.getHasU())) {
                        return true;
                    } else if ("display".equalsIgnoreCase(operation) && roleRight.getHasS()) {
                        return true;
                    } else if ("delete".equalsIgnoreCase(operation) && roleRight.getHasD()) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static boolean hasRight(String object, String operation) {
        for (GrantedAuthority grant : SecurityContextHolder.getContext().getAuthentication().getAuthorities() ) {
            if (roleHasright(object, operation, grant.getAuthority())) {
                return true;
            }
        }
        return false;
    }
}

