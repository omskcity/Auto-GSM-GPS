function QComponentSelect (dialog, prm) {
    var _dialog = dialog;
    var _component;
    var _select;
    var _id = prm.valueStr(PRM_DLG_COMPONENT_ID);

    this.id = function () {
        return _id;
    };

    this.bindValue2Data = function() {
        _dialog.getData().value(_id, _select.val());
    };

    this.bindData2Value = function() {
        _select.val(_dialog.getData().valueStr(_id));
    };

    this.clear = function() {
        _select.val('');
    };

    var _enabled = !isTrue(prm.valueStr(PRM_DLG_DISABLED));
    this.enabled = function(pvalue) {
        if (pvalue == undefined) {
            return _enabled;
        } else {
            _enabled = pvalue;
            if (_enabled) {
                _select.removeAttr('disabled');
                _component.removeClass('disabled');
            } else {
                _component.addClass('disabled');
                _select.attr('disabled','disabled');
            }
        }
    };

    var create = function (object_params) {
        var QNode = [PRM_DLG_COMPONENT_ID ,PRM_DLG_COMPONENT_LABEL, PRM_DLG_COMPONENT_VALUE, 'spr_name', PRM_DLG_COMPONENT_WIDTH];
        var str = '';
        str = str + '<div class="dialog-element">';
        str = str + '<div class="dialog-element-label">';
        str = str + '<label for="${id}">${label}</label>';
        str = str + '</div>';
        str = str + '<div class="dialog-element-content">';
        str = str + '<select id="${id}" name="${id}"';
        str = str + 'style=\"width: ${width}\" ';
        str = str + 'class=\"ui-widget-content\">';
        str = str + '</select>';
        str = str + '</div>';
        jQuery.each(QNode, function(i, val) {
            var param_value = object_params.valueStr(val);
            if (!hasStrValue(param_value)) {
                param_value = '';
            }
            str = str.replace(new RegExp('\\$\\{' + val +'\\}', 'g'), param_value);
        });
        _component = $(str).appendTo(_dialog.getHTMLDiv());
        _select = _component.find('select');

        var spr_name = object_params.valueStr('spr_name');
        if (hasStrValue(spr_name)) {
            get_xml_data({
                url : SPR_DEFAULT_URL,
                data : {
                    '@action' : 'select',
                    '@spr_name' : spr_name
                },
                ok_callback: function (data) {

                    jQuery.each(data.asArrayValue(), function(i, val) {
                        var spr_code = val.valueStr('code');
                        var spr_value = val.valueStr('value');
                        str = '<option value=\"' + spr_code + '\">' + spr_value + '</option>';
                        var option = $(str).appendTo(_select);
                    });
                }
            });

        }
    };

    create(prm);

}
