/**
 * This code contains copyright information which is the proprietary property
 * of SITA Information Network Computing Limited (SITA). No part of this
 * code may be reproduced, stored or transmitted in any form without the prior
 * written permission of SITA.
 *
 * Copyright (C) SITA Information Network Computing Limited 2009-2012.
 * All rights reserved.
 */
package org.quilt.web;

import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;

/**
 * Result for DataController
 *
 * @author <a href="mailto:vbelokon@luxoft.com">Vasily Belokon</a>
 * @version 1.0
 */
public class DataResult {

    protected static final String NODE_ERRORS_NAME = "error_list";
    protected static final String NODE_DATA_NAME = "data";
    protected static final String NODE_ROOT_NAME = "response";



    private List<ResultNode> data = new ArrayList<ResultNode>();

    private List<ResultNode> errors = new ArrayList<ResultNode>();
    private boolean ok;


    public boolean isOk() {
        return ok;
    }

    public void setOk(final boolean ok) {
        this.ok = ok;
    }

    public boolean addData(ResultNode node) {
        return data.add(node);
    }

    public boolean addError(ResultNode node) {
        return errors.add(node);
    }

    public boolean addError(Throwable throwable) {
        ResultNode res = new ResultNode("error");
        res.addNested(new ResultNode("code", "exception" ));
        res.addNested(new ResultNode("message", throwable.getMessage()));
        res.addNested(new ResultNode("detail", throwable.getLocalizedMessage()));
        return errors.add(res);
    }

    public boolean addError(String shortDescr, String descr, String  fullDescr) {
        ResultNode res = new ResultNode("error");
        res.addNested(new ResultNode("code", shortDescr));
        res.addNested(new ResultNode("message", descr));
        res.addNested(new ResultNode("detail", fullDescr));
        return errors.add(res);
    }

    public boolean addError(String shortDescr, String fullDescr ) {
        return addError(shortDescr, fullDescr, null);
    }

    public void write(Writer out) throws IOException {
        out.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
        out.write("<" + NODE_ROOT_NAME + ">");
        if (!errors.isEmpty()) {
            ok = false;
        }

        ResultNode result = new ResultNode("result", isOk());
        result.write(out);
        out.write("<" + NODE_ERRORS_NAME + ">");
        for (ResultNode node : errors) {
            node.write(out);
        }
        out.write("</" + NODE_ERRORS_NAME + ">");
        out.write("<" + NODE_DATA_NAME + ">");
        for (ResultNode node : data) {
            node.write(out);
        }
        out.write("</" + NODE_DATA_NAME + ">");
        out.write("</" + NODE_ROOT_NAME + ">");
    }
}
