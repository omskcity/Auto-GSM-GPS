package org.quilt.web;


import org.apache.catalina.websocket.MessageInbound;
import org.apache.catalina.websocket.StreamInbound;
import org.apache.catalina.websocket.WebSocketServlet;
import org.apache.catalina.websocket.WsOutbound;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;

public class NotifyWSServlet extends WebSocketServlet {


    @Override
    protected StreamInbound createWebSocketInbound(String s, HttpServletRequest httpServletRequest) {
        return new TheWebSocket();  //To change body of implemented methods use File | Settings | File Templates.
    }

    public class TheWebSocket extends MessageInbound
    {


        private WsOutbound outbound;

        public void onOpen( WsOutbound outbound )
        {
            this.outbound = outbound;
            System.out.println("socket opened!");
        }

        public void onTextMessage( CharBuffer buffer ) throws IOException
        {
            try
            {
                outbound.writeTextMessage( CharBuffer.wrap( "abc testing".toCharArray() ) );
                System.out.println("Message sent from server.");
            }
            catch ( IOException ioException )
            {
                System.out.println("error opening websocket");
            }

        }

        protected void onBinaryMessage(ByteBuffer arg0) throws IOException {
            // TODO Auto-generated method stub

        }
    }


}