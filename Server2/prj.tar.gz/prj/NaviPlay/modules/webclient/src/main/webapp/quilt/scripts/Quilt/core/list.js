function QList () {

    var _columns = [];
    var _commands = [];

    var _ext_grid;
    var _ext_grid_key_binding;

    this.columns = function () {
        return _columns;
    };
    this.commands = function () {
        return _commands;
    };

    this.parseColumns = function (columns) {
        jQuery.each(columns.asArrayValue(), function(i, column_descr) {
            var column = new QListColumn(column_descr);
            _columns.push(column);
        });
    };

    this.parseCommands = function (commands) {
        jQuery.each(commands.asArrayValue(), function(i, command_descr) {
            var command = new QListCommand(command_descr);
            _commands.push(command);
        });
    };

}


function QListColumn (init_param) {
    var _title = init_param.valueStr('title');
    var _field = init_param.valueStr('field');
    var _width = init_param.valueStr('width');
    var _icon =  init_param.valueStr('icon');
    var _as_icon  =  init_param.valueStr('as_icon');

    this.title = function (value) {
        if (value == undefined) {
            return _title;
        } else {
            _title = value;
        }
    };

    this.field = function (value) {
        if (value == undefined) {
            return _field;
        } else {
            _field = value;
        }
    };

    this.width = function (value) {
        if (value == undefined) {
            return _width;
        } else {
            _width = value;
        }
    };

    this.icon = function (value) {
        if (value == undefined) {
            return _icon;
        } else {
            _icon = value;
        }
    };

    this.as_icon = function (value) {
        if (value == undefined) {
            return _as_icon;
        } else {
            _as_icon = value;
        }
    };
}

function QListCommand () {
    var _title = init_param.valueStr('title');
    var _handler;
    var _for_selection = init_param.valueStr('for_selection');
    var _icon = init_param.valueStr('icon');
    var _command = init_param.valueStr('command');

    this.title = function (value) {
        if (value == undefined) {
            return _title;
        } else {
            _title = value;
        }
    };

    this.handler = function (value) {
        if (value == undefined) {
            return _handler;
        } else {
            _handler = value;
        }
    };

    this.for_selection = function (value) {
        if (value == undefined) {
            return _for_selection;
        } else {
            _for_selection = value;
        }
    };

    this.icon = function (value) {
        if (value == undefined) {
            return _icon;
        } else {
            _icon = value;
        }
    };

    this.command = function (value) {
        if (value == undefined) {
            return _command;
        } else {
            _command = value;
        }
    };

}
