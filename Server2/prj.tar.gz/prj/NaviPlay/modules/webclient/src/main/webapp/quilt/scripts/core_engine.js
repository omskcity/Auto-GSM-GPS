var ui_objects;
var CMD_NAME_DLG = 'dlg';
var DATA_DEFAULT_URL = 'data.do';
var SPR_DEFAULT_URL = 'spr.do';
var roles = [];


function paramReplaceWrap(prm, prm2, wrap) {
    if (prm instanceof QNode && prm2 instanceof QNode && hasStrValue(wrap)) {
        var str = prm.toString();
        jQuery.each(prm2.asArrayValue(), function(i, val2) {
            str = reslaceAllIgnoreCase(str, wrap+val2.name()+wrap, val2.getStringValue());
        });
        prm.set(str);
    }
}

function strReplaceWrap(str, prm2, wrap) {

    if (prm2 instanceof QNode && hasStrValue(wrap)) {
        jQuery.each(prm2.asArrayValue(), function(i, val2) {
            str = reslaceAllIgnoreCase(str, wrap+val2.name()+wrap, val2.getStringValue());
        });
    }
    return str;
}


function q_ajax(obj) {

    if (obj instanceof Object) {
        if (!hasValue(obj.url)) {
            alert('Не верное использование запроса на сервер. Не указан url');
            return;
        }
        if (!hasValue(obj.data)) {
            alert('Не верное использование запроса на сервер. Не указан data');
            return;
        }
        if (!hasValue(obj.async)) {
            obj.async = false;
        }
        var result = true;
        var need_auth = false;
        var vdata;
        $.ajax({
            type: "post",
            async: obj.async,
            url: obj.url,
            data: obj.data,
            dataType: 'text',
            beforeSend: function (xhr) {
               xhr.setRequestHeader("X-Ajax-call", "true");
            },
            statusCode: {
                500: function(XMLHttpRequest, textStatus, errorThrown) {
                    obj.error_callback('Ошибка получения данных' ,XMLHttpRequest, textStatus, errorThrown);
                },
                401: function() {
                    if( !strEqualsIgnoreCase(obj.url,'logout') &&  !strEqualsIgnoreCase(obj.url,'j_spring_security_check')) {
                        need_auth = true;
                    }
                },
                404: function() {
                },
                403: function() {
                    //console.log("error 403");
                    if( !strEqualsIgnoreCase(obj.url,'logout') &&  !strEqualsIgnoreCase(obj.url,'j_spring_security_check')) {
                        need_auth = true;
                    }
                },
                302: function() {
                    ////console.log("error 302");
                    if( !strEqualsIgnoreCase(obj.url,'logout') &&  !strEqualsIgnoreCase(obj.url,'j_spring_security_check')) {
                        need_auth = true;
                    }
                }
            },
            complete : function() {
                //console.log("complete " + obj.url);
                if (need_auth) {
                    //console.log("complete need_auth");
                    relogin(function (need_retry) {
                        if (need_retry) {
                            q_ajax(obj);
                        }
                    });
                } else if (result) {
                    //console.log("complete result true");
                    if (hasValue(obj.ok_callback)) {
                        obj.ok_callback(vdata);
                    }
                } else {
                    //console.log("complete result false");
                    if (hasValue(obj.error_callback)) {
                        obj.error_callback();
                    }
                }
            },
            success: function(data, p1, p2) {
                vdata = data;
                if (strEqualsIgnoreCase(data, 'need_auth')) {
                    if( !strEqualsIgnoreCase(obj.url,'logout') &&  !strEqualsIgnoreCase(obj.url,'j_spring_security_check')) {
                        //console.log("success need_auth " + obj.url);
                        need_auth = true;
                    }
                }
                var rolesStr = p2.getResponseHeader('roles');
                if (hasStrValue(rolesStr))  {
                    setRoles(rolesStr);
                }
            },
            error: function () {
                result = strEqualsIgnoreCase( obj.url, 'j_spring_security_check' );
            }
        });
    } else {
        alert('Не верное использование запроса на сервер');
    }
}

function get_xml_data(obj) {

    if (obj instanceof Object) {
        var data = new Object;
        if (!hasValue(obj.url)) {
            obj.url = DATA_DEFAULT_URL;
        }
        if (!hasValue(obj.data)) {
            obj.data = '';
        }

        if (hasStrValue(obj.object)) {
            data['@object'] = obj.object;
        }

        if (obj.data instanceof QNode) {
            jQuery.each(obj.data.asArrayValue(), function(i, val) {
                data[val.name()] = val.getStringValue();
            });
        } else if (obj.data instanceof Object) {
            jQuery.each(obj.data, function(i, val) {
                data[i] = val;
            });
        } else {
            data = obj.data;
        }

        var _ok_callback = function (data) {
            var fetched = new QNode(data);
            var result = fetched.valueStr('result');
            if (hasStrValue(result) && !isTrue(result)) {
                var errorDescr = fetched.value('error_list');
                if (hasValue(obj.error_callback)) {
                    obj.error_callback(errorDescr);
                }
            } else {
                var resData = fetched.value('data');
                if (hasValue(obj.ok_callback)) {
                    obj.ok_callback(resData);
                }
            }

        };

        var _error_callback = function () {
            if (hasValue(obj.error_callback)) {
                obj.error_callback();
            }
        };

        q_ajax({
            url: obj.url,
            data: data,
            async : obj.async,
            ok_callback: _ok_callback,
            error_callback: _error_callback
        });
    }
}


function create_ui_div(type, id){
    if (id == null) {
        return null;
    }
    if (ui_objects == null) {
        ui_objects = new Object;
    }
    var ui_type = ui_objects[type];
    if (ui_type == null) {
        ui_type = new Object;
        ui_objects[type] = ui_type;
    }
    var div = ui_type[id];
    if (div == null) {
        div = $('<div id="' + id + '"></div>');

        div.hide();
        div.submit()
        div.appendTo("#body");
        ui_type[id] = div;
    }
    return div;
}

function executeCommand(arg1, callback) {
    var prm;
    if (arg1 != undefined ) {
        if (arg1 instanceof QNode) {
            prm = arg1;
        } else {
            prm = new QNode(arg1);
        }
        var command_name = prm.name();
        //console.log("execute command", prm.toString());
        if (hasStrValue(command_name)) {
            if(strEquals(command_name, CMD_NAME_DLG)) {
                QDialogManager.execute(prm, callback);
            }

        }
    }
}

function checkOnLogin(callback) {
    get_xml_data({
    object: "select u.* from q_user u where u.id=:user_id",
        data: {
            user_id:"%CURRENT_USER%"
        },
        ok_callback: function (data) {
            var row = data.value('row');
            var email = row.valueStr('email');
            if (hasStrValue(email)) {
                callback();
            } else {
                showMessage('Внимание, для того чтобы своевременно получать уведомления и чтобы иметь возможность востановить пароль <br><strong>надо указать емайл </strong><br>для этого воспользуйтесь пунктом меню <strong>Личные данные</strong>', callback);

            }
        }
    });
}

function relogin (callback) {
    showDialog('dlg_q_login', function () {
        checkOnLogin(callback)
    });
}

function setRoles (rolesStr) {
    roles = rolesStr.split(',');
    rootMenu.createMenuOld();
}

function hasAdminRole () {
    return hasValue(roles) && roles.indexOf('admin') > -1 ;
}
function hasRole (rolesStr) {
    return hasValue(roles) && (roles.indexOf(rolesStr) > -1 || hasAdminRole() );
}