/**
 * This code contains copyright information which is the proprietary property
 * of SITA Information Network Computing Limited (SITA). No part of this
 * code may be reproduced, stored or transmitted in any form without the prior
 * written permission of SITA.
 *
 * Copyright (C) SITA Information Network Computing Limited 2009-2012.
 * All rights reserved.
 */
package org.quilt.web;

import org.quilt.dao.DAOObject;
import org.quilt.security.UserInfo;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

/**
 * Abstract Controller. provide param mapping. provide access to session.
 *
 * @author <a href="mailto:vbelokon@luxoft.com">Vasily Belokon</a>
 * @version 1.0
 */
public abstract class AbstractDataControllerEx extends AbstractController {

    protected Map<String, Object> getParameters(HttpServletRequest request) {
        Map<String, Object> result = new HashMap<String, Object>();
        final String id = request.getParameter(DAOObject.PARAM_NAME_ID);

        for (Object key: request.getParameterMap().keySet()) {
            if (key instanceof String) {
                String param_name = (String) key;
                if (NULL_VALUE.equals(request.getParameter(param_name))|| !StringUtils.hasText(request.getParameter(
                    param_name))) {
                    result.put(param_name, null);
                } else {
                    result.put(param_name, request.getParameter(param_name));
                }
            }
        }
        if (StringUtils.hasLength(id)) {
            result.put(DAOObject.PARAM_NAME_ID, id);
        }
        UserInfo.prepareArgs(result, request.getSession());
        return result;

    }

    @Override
    public final ModelAndView handleRequest(final HttpServletRequest request, final HttpServletResponse response)
        throws Exception {
        request.setCharacterEncoding("UTF-8");
        DataResult result = null;
        try {
            result = doAction(getParameters(request), request.getSession());
            if (result == null) {
                result = new DataResult();
            }
        } catch (AuthorityException e) {
            response.sendError(401);
            return null;
        } catch (Exception e) {
            if (result == null) {
                result = new DataResult();
            }
            result.setOk(false);
        }
        response.setCharacterEncoding("UTF-8");
        result.write(response.getWriter());
        return null;
    }

    public abstract DataResult doAction(Map<String, Object> params, HttpSession session) throws Exception;

}
