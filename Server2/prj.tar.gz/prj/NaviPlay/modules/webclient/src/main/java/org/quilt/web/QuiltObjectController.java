package org.quilt.web;

import org.apache.commons.lang.StringUtils;
import org.quilt.dao.QuiltObjectHelper;

import javax.servlet.http.HttpSession;
import java.util.Map;

/**
 * Controller for send email message with template.
 *
 * @author vbelokon
 */
public final class QuiltObjectController extends AbstractDataControllerEx {
    protected static final String PARAM_NAME_TYPE = "@type";
    protected static final String PARAM_NAME_NAME = "@name";
    protected static final String PARAM_NAME_FORCE = "@force";

    @Override
    public DataResult doAction(final Map<String, Object> params, HttpSession session) throws Exception {
        final String type = getString(params.get(PARAM_NAME_TYPE));
        final String name = getString(params.get(PARAM_NAME_NAME));
        final Boolean force = getBoolean(params.get(PARAM_NAME_FORCE));
        String objectData = QuiltObjectHelper.fetchObject(name, type, !force);
        DataResult result = new DataResult();
        if (StringUtils.isNotBlank(objectData)) {
            try {
                result.addData(new ResultNode("data", objectData));
                result.setOk(true);
            } catch (Exception e) {
                result.addError(e);
            }
        }
        return result;
    }

}
