package org.quilt.dao;

import org.quilt.web.ResultNode;

import java.sql.SQLException;

public class DAOException extends SQLException {
    private DAOExceptionType exceptionType;
    private String detail;

    public DAOException(DAOExceptionType exceptionType, String detail) {
        this.exceptionType = exceptionType;
        this.detail = detail;
    }

    public ResultNode createError4Result() {
        ResultNode res = new ResultNode("error");
        res.addNested(new ResultNode("code", exceptionType.getCode()));
        res.addNested(new ResultNode("message", exceptionType.getMessage()));
        res.addNested(new ResultNode("detail", detail));
        return res;
    }
}
