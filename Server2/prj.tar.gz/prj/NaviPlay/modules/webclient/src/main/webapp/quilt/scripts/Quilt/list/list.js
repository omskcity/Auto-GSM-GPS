Ext.require([
    'Ext.window.Window',
    'Ext.layout.container.Form',
    'Ext.layout.container.Absolute'
]);


var PRM_LIST = 'list';
var PRM_LIST_NAME = 'name';


var PRM_LIST_URL = 'url';

var PRM_LIST_TITLE = 'title';
var PRM_LIST_WIDTH = 'width';
var PRM_LIST_HEIGHT = 'height';

var PRM_LIST_RECREATE = 'recreate';


/** QList static class implement dialog storage and executor logic */
var QListManager = {};
QListManager.lists = {};
QListManager.cmd = 'list';


QListManager.execute = function(exec_param, callback) {
    var prm;
    if (exec_param != undefined ) {
        if (exec_param instanceof QNode) {
            prm = exec_param;
        } else {
            prm = new QNode(exec_param);
        }
    }

    var list_name = prm.valueStr(PRM_LIST_NAME);
    var recreate = prm.valueStr(PRM_LIST_RECREATE);
    var list = QListManager.lists[list_name];
    if (hasValue(list) && isTrue(recreate)) {
        list.destroy();
        list = null;
    }
    if (!hasValue(list)) {
        list = new QList(list_name);
        QListManager.lists[list_name] = list;
    }
    list.execute(prm, callback);
};

/** QList class implement dialog logic */
function QList (init_prm) {
    var _before_show_callback;
    var that = this;
    var _list_name;
    var _extWindow;
    var _list_descr;
    var _data;
    var _result_callback;
    var _title;
    var _main_panel;
    var _init_prm;
    var _listData;
    var _columnList;
    var _button_panel;
    var _extDataModel;
    var _extDataStore;
    var _grid;
    var _grid_key_binding;
    var _width;
    var _height;
    var _filterPrm;

    this.addOnShowEvent = function (call) {
        _before_show_callback.add(call);
    };

    this.getWindow = function () {
        return _extWindow;
    };

    this.getData = function () {
        return _data;
    };

    this.name = function () {
        return _list_name;
    };

    this.replaceParam = function (str) {
        var wrap = '%';
        bindInput2Data();
        str = strReplaceWrap(str, _data, wrap);
        jQuery.each(_known_params, function(i, val) {
            str = reslaceAllIgnoreCase(str, wrap+val+wrap, '');
        });

        return str;
    };

    this.execute = function(exec_param, callback) {
        _data = new QNode();
        _init_prm.set(exec_param);
        _data.set(_init_prm.value('params'));
        _result_callback = callback;
        initDialogDescr(
            function () {
                _width = _list_descr.valueStr(PRM_LIST_WIDTH);
                _height = _list_descr.valueStr(PRM_LIST_HEIGHT);
                if (!hasValue(_extWindow) && hasValue(_list_descr)) {
                    buildList();
                }
                showList();
            }
        );
    };

    var createList = function (list_name) {
        _before_show_callback = $.Callbacks();
        _init_prm = new QNode();
        _data = new QNode();

        if (!hasStrValue(list_name)) {
            throw new Error('Не указано имя списка');
        }
        _list_name = list_name;


    };

    var initDialogDescr = function (callback) {
        if (!hasValue(_list_descr)) {
            _list_descr = _init_prm.value(PRM_LIST);
        }
        if (hasValue(_list_descr)) {
            callback();
        } else {
            var type = 'list';
            /*if (strStartWith(_dialog_name, 'list_')) {
                type = 'list';
            } */
            get_xml_data({
                url:"object.do",
                data: {
                    '@name' :_list_name,
                    '@type': type
                },
                ok_callback : function (data) {
                    var qdata = new QNode(data);
                    var dlg_data = qdata.valueStr('data');
                    _list_descr = new QNode(dlg_data);
                    callback();

                },
                error_callback: function (data) {
                    showError('Ошибка получения списка с именем ' + _list_name, data);
                }
            });
        }
    };

    var result_callback = function() {
        if (hasValue(_result_callback)) {
            _result_callback();
        }
    };

    var buildList = function () {
        if(isTrue(_init_prm.valueStr(PRM_LIST_RECREATE)) && hasValue(_extWindow)) {
            _extWindow.destroy()
        }
        if (!hasValue(_extWindow)) {
            _title = _list_descr.valueStr(PRM_LIST_TITLE);
            _extWindow = Ext.create('Ext.window.Window', {
                closeAction: 'hide',
                title: _title,
                modal: false,
                layout: 'anchor',
                width: 12 + parseInt(_width),
                height: 44 + parseInt(_height)
            });

            _button_panel = new QListToolbar(_extWindow);


            _extWindow.add(_main_panel);
            _extWindow.on('close' , result_callback);
        }

        initColumnList();
        _extDataModel = Ext.define(_list_name + '_data_model',{
            extend: 'Ext.data.Model',
            fields: []
        });

        _extDataStore = Ext.create('Ext.data.Store', {
            model: _list_name + '_data_model',
            autoLoad: true,
            data : new QNode(),
            proxy: {
                // load using HTTP
                type: 'memory',
                // the return will be XML, so lets set up a reader
                reader: {
                    type: 'qnode'
                }
            }
        });
        _grid = Ext.create('Ext.grid.Panel', {
            store: _extDataStore,
            stateful: true,
            collapsible: false,
            multiSelect: true,
            stateId: 'stateGrid',
            columns: getPreparedColumns(),
//                    title: 'Array Grid',
//                    renderTo: 'grid-example',
            viewConfig: {
                stripeRows: true,
                enableTextSelection: false
            },
            listeners: {
                beforeitemcontextmenu: function(view, record, item, index, e)
                {
                    e.stopEvent();
                    var menu = Ext.create('Ext.menu.Menu', {
                        items : _button_panel.getMenuItems(_grid)
                    });
                    menu.showAt(e.getXY());
                }
            },
            anchor: '100% -27'
//            viewConfig:{forceFit:true},
//            layout: 'fit'
//            width: _width,
//            height: _height,
//            minHeight: _height,
//            maxHeight: _height

        });
        _grid_key_binding = new Ext.util.KeyMap({
            target: _grid.view,
            eventName: 'itemkeydown',
            processEvent: function(view, record, node, index, event) {
                // Load the event with the extra information needed by the mappings
                event.view = view;
                event.store = view.getStore();
                event.record = record;
                event.index = index;
                return event;
            },
            binding: [{
                key: Ext.EventObject.F2,
                fn: that.keydown
            }]
        });
        prepareButtons();
        _extWindow.add(_grid);

        that.addOnShowEvent(function () {
            fillList();
        });

    };

    this.destroy = function () {
        _extWindow.destroy();
    };


    var showList = function () {
        _before_show_callback.fire(_data);
        fillList();
        _extWindow.doLayout();
        _extWindow.show();

        _extWindow.center();
        tableFocus();
    };

    var getUrl = function () {
//      //console.log('url=' + nvl(nvl(_init_prm.valueStr(PRM_LIST_URL), _dlg_descr.valueStr(PRM_LIST_URL)), 'data.do'));
        return nvl(nvl(_init_prm.valueStr(PRM_LIST_URL), _list_descr.valueStr(PRM_LIST_URL)), 'data.do');
    };



    this.keydown = function(target, e){
        if (e.getKey() == e.F11 ) {
            e.stopEvent();
//            console.log('press f2');
//            dialog_save();
        }else if (e.getKey() == e.F10) {
            e.stopEvent();
//            console.log('press f10');
//            dialog_cancel();
        }
    };

    var getPreparedColumns = function () {
        var aoColumns = [];
        jQuery.each(_columnList.asArrayValue(), function(i, val) {
            var aoColumn = {
                text     : val.valueStr('title'),
                flex     : 0,
                sortable : false,
                width : val.valueStr('width'),
                dataIndex: val.valueStr('field')
            };
            aoColumns.push(aoColumn);
            var as_icon = val.valueStr('as_icon');
            if (!hasStrValue(val.valueStr('width'))) {
                aoColumn.flex = 1;
            }
            if (isTrue(as_icon)) {
                aoColumn['renderer'] = function ( data) {
                    return '<span class="ui-button-icon-primary ui-icon ' + data + '"></span>';
                };
            }
        });
        return aoColumns;
    };

    var fillFilters = function (data) {
        var filters = _list_descr.value('filters');
        if (hasValue(filters)) {
            jQuery.each(filters.asArrayValue(), function(i, val) {
                var name = val.valueStr('name');
                if (hasStrValue(name)) {
                    var value = data.valueStr(name);
                    if (!hasStrValue(value)) {
                        data.add(name, '');
                    }
                }
            });
        }
    };

    var fetchData = function (callback) {
        var script = _list_descr.valueStr('script');
        var script_param = _list_descr.valueStr('script_param');
        var filter_form = _list_descr.valueStr('filter_dialog');

        var data = new QNode('<script_param>' +script_param + '</script_param>');
        data.merge(_data);
        if (hasStrValue(filter_form)) {
            var filterExecPrm = new QNode('<dlg><name>' + filter_form+  '</name><operation value="input"/></dlg>');
            executeCommand(filterExecPrm, function (filterData) {
                _filterPrm = filterData;
                data.merge(filterData);
                fillFilters(data);
                get_xml_data({
                    object: script,
                    data:  data,
                    url: getUrl(),
                    ok_callback: function (data) {
                        _listData = data;
                        prepareDataModel();
                        prepareDataStore();
                        callback();
                    },
                    error_callback: function (data) {
                        showError('Ошибка получения данных для списка по скрипту', data);
                    }
                });
            });
        } else {
            fillFilters(data);
            get_xml_data({
                object: script,
                data:  data,
                url: getUrl(),
                ok_callback: function (data) {
                    _listData = data;
                    prepareDataModel();
                    prepareDataStore();
                    callback();
                },
                error_callback: function (data) {
                    showError('Ошибка получения данных для списка по скрипту', data);
                }

            });
        }
    };

    var initColumnList = function () {
        _columnList = _list_descr.value('columns');
        if (_listData instanceof QNode) {
            if (!hasValue(_columnList)) {
                _columnList = new QNode();
                var row0 = _listData.asArrayValue()[0];
                jQuery.each(row0.asArrayValue(), function(i, field) {
                    var col = new QNode();
                    col.name('col');
                    col.value('title', field.name());
                    col.value('field', field.name());
                    col.value('type', 'string');
                    _columnList.add(col);
                });
            }
        }
    };

    var fillList = function () {
        fetchData(function () {
            if (_listData instanceof QNode) {
                _grid.getSelectionModel().on('selectionchange', function() {
                    _button_panel.calcBtnEnable(_grid);
                });
                _button_panel.calcBtnEnable(_grid);


            }
        });
    };

    var tableFocus = function () {
        console.log('tableFocus');
//        _grid.focus(false, 10);
        _grid.getSelectionModel().select(0);
        _grid.getView().focus(false, 10);
    };

    var refreshList = function () {
        fetchData(function () {
            tableFocus();
        });
    };

    var prepareDataModel = function () {
        var fields = getListDataRowColumns();
        _extDataModel.setFields(fields, _list_name + '_data_model');
    };

    var prepareDataStore = function () {
        if (!hasValue(_extDataStore)) {
        } else {
            _extDataStore.setProxy(new Ext.data.proxy.Memory({
                data : _listData,
                reader: {
                    type: 'qnode'
                }
            }));
            _extDataStore.load();
        }
    };

    var getListDataRowColumns = function () {
        var result = [];
        if (_listData instanceof QNode) {
            var rows =  _listData.asArrayValue();
            if (rows.length > 0) {
                var row = rows[0];
                if (row instanceof QNode) {
                    jQuery.each(row.asArrayValue(), function(i, val) {
                        result.push(val.name());
                    });
                    result.push('_row');
                }

            }
        }
        return result;
    };

    var commandResult = function (result) {
        console.log('on command result' + result);
        if (isTrue(result)) {
            refreshList();
        }
        _grid.getView().focus(false, 100);
    };

    var prepareButtons = function () {

        var cmds = _list_descr.value('commands');
        if (_list_descr instanceof QNode) {

            var btn;

            btn = new  QListToolbarBtn();
            btn.label('Выход');
            btn.icon('exit');
            btn.executor( function() {
                _extWindow.close();
            });
            _button_panel.add(btn);
            _button_panel.add(new Ext.toolbar.Separator());
            btn = new  QListToolbarBtn();
            btn.label('Обновить');
            btn.icon('refresh');
            btn.executor( function() {
                fillList();
            });
            _button_panel.add(btn);
            _button_panel.add(new Ext.toolbar.Separator());

            jQuery.each(cmds.asArrayValue(), function(i, cmd) {
                if (cmd instanceof QNode) {

                    btn = new  QListToolbarBtn();
                    btn.label(cmd.valueStr('title'));
                    btn.icon(cmd.valueStr('icon'));
                    var executor;
                    if (hasStrValue(cmd.valueStr('command'))) {
                        executor = function () {
                            var str = cmd.valueStr('command');
                            var selected = _grid.getSelectionModel().getSelection();
                            var curr_row;
                            if (selected.length > 0) {
                                var f = selected[0];
                                curr_row = f.get('_row');
                            }
                            str = strReplaceWrap(str, curr_row , '#');
                            var data = new QNode();
                            data.merge(_data);
                            data.merge(_filterPrm);
                            fillFilters(data);
                            str = strReplaceWrap(str, data, '$');
                            executeCommandList(str, commandResult);
                        };
                    }
                    btn.for_selection(isTrue(cmd.valueStr('for_selection')) ||strEqualsIgnoreCase(cmd.valueStr('for_selection'), 'single'));

                    btn.executor( executor);
                    _button_panel.add(btn);
                    if (hasStrValue(cmd.valueStr('key'))) {
                        var binding = util.getBindingByStr(cmd.valueStr('key'));
                        binding.fn = executor;
                        binding.scope = this;
                        _grid_key_binding.addBinding(binding);
                    }
                }
            });
        }
    };

    var executeCommandList = function (cmd, callback) {
        executeCommand(cmd, callback);
    };

    createList(init_prm);

}
