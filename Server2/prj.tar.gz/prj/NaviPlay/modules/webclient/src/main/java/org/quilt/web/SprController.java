package org.quilt.web;

import org.quilt.dao.DAOException;
import org.quilt.dao.DAOObject;
import org.quilt.dao.DAOObjectAttribute;
import org.springframework.util.StringUtils;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Performs logic for producers screen
 * 
 * @author vbelokon
 * 
 */
public final class SprController extends AbstractDataController {
    @Override
    public DataResult doAction(final Map<String, Object> params) {
        final String action = getString(params.get("@action"));
        final String spr_name = getString(params.get("@spr_name"));
        final String value = getString(params.get("@value"));
        String code_field = getString(params.get("@code_field"));
        String value_field = getString(params.get("@value_field"));
        DataResult result = new DataResult();
        if (DAOObject.findObject(spr_name) != null) {
            List<DAOObjectAttribute> attrs = DAOObject.findObject(spr_name).getAttrs();
            if (!StringUtils.hasLength(code_field)) {
                if (attrs.size()>=1) {
                    code_field =
                        attrs.get(0).getName();
                }
            }
            if (!StringUtils.hasLength(value_field)) {
                for (DAOObjectAttribute attr: attrs) {
                    if ("name".equalsIgnoreCase(attr.getName())) {
                        value_field = attr.getName();
                        break;
                    }
                }
            }
            if (!StringUtils.hasLength(value_field)) {
                for (DAOObjectAttribute attr: attrs) {
                    if ("VARCHAR".equalsIgnoreCase(attr.getTypeName()) && attr.getSize() >= 10) {
                        value_field = attr.getName();
                        break;
                    }
                }
            }
            if (!StringUtils.hasLength(value_field)) {
                if (DAOObject.findObject(spr_name).getAttrs().size()>=2) {
                    value_field =
                        DAOObject.findObject(spr_name).getAttrs().get(1).getName();
                }
            }
        }
        if ("select".equalsIgnoreCase(action)) {
            if (StringUtils.hasLength(spr_name)){
                try {
                    List<Map<String, Object>> rows = DAOObject.findObject(spr_name).getRowList(params);
                    for (Map<String,Object> row: rows) {
                        ResultNode dataRow = new ResultNode("row");
                        result.addData(dataRow);
                        dataRow.addNested(new ResultNode("code", row.get(code_field)));
                        dataRow.addNested(new ResultNode("value", row.get(value_field)));
                    }
                    result.setOk(true);
                } catch (DAOException e) {
                    result.addError(e.createError4Result());
                }

            }
            return result;
        } else if ("find".equalsIgnoreCase(action)) {
            if (StringUtils.hasLength(spr_name)){
                Map<String, Object> args = new HashMap<String, Object>(params);
                args.put("like_".concat(value_field), value + "%");
                try {
                    List<Map<String,Object>> rowList = DAOObject.findObject(spr_name).getRowList(args);
                    for (Map<String,Object> row: rowList) {
                        ResultNode dataRow = new ResultNode("row");
                        result.addData(dataRow);
                        dataRow.addNested(new ResultNode("code", row.get(code_field)));
                        dataRow.addNested(new ResultNode("value", row.get(value_field)));
                    }
                    result.setOk(true);
                } catch (DAOException e) {
                    result.addError(e.createError4Result());
                }
            }
            return result;
        } else if ("code".equalsIgnoreCase(action)) {
            if (StringUtils.hasLength(spr_name)){
                try {
                    Map row = DAOObject.findObject(spr_name).getRow(params);
                    result.addData(new ResultNode("value", row.get(value_field)));
                    result.setOk(true);
                } catch (DAOException e) {
                    result.addError(e.createError4Result());
                }
            }
            return result;
        }
        return result;
    }

}
