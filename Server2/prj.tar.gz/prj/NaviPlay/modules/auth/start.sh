#!/bin/sh

mvn dependency:build-classpath -Dmdep.outputFile=cp.txt
cp=$(cat cp.txt);
nohup java -cp "./target/auth-1.0.jar:$cp" ModuleRunner -DModuleName=auth &