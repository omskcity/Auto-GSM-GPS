package com.navi.modules.auth;

import com.navi.core.jms.Sender;
import org.apache.log4j.Logger;

import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import java.util.HashMap;
import java.util.Map;

public class JMSAuthManagerImpl implements AuthManager {
    private Logger log = Logger.getLogger(JMSAuthManagerImpl.class);
    private Sender sender;
    public static final String DEVICE_NUM = "deviceNum";
    public static final String SOCKET_ID = "socketId";
    public static final String IMEI = "imei";
    public static final String ACTION = "action";
    public static final String ACTION_ADD = "add";
    public static final String ACTION_REMOVE_BY_SOCKET = "remove_by_socket";
    public static final String ACTION_REMOVE_BY_DEVICE = "remove_by_device";
    public static final String ACTION_FOUND_DEVICE = "found_device";
    public static final String ACTION_FOUND_SOCKET = "found_socket";
    public static final String RESULT = "result";

    public JMSAuthManagerImpl(Sender sender) {
        this.sender = sender;
    }


    @Override
    public boolean addDevice(String imei, final Integer deviceNum, final Integer socketId) {
        log.info("registered device " +
                 "deviceNumber=" + deviceNum +
                 ", socketId=" + socketId
        );
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ACTION, ACTION_ADD);
        map.put(IMEI, imei);
        map.put(DEVICE_NUM, deviceNum);
        map.put(SOCKET_ID, socketId);

        Message message = sender.request(map);
        if (message != null && message instanceof MapMessage) {
            try {
                if (((MapMessage) message).itemExists(RESULT)) {
                    return ((MapMessage) message).getBoolean(RESULT);
                }
            } catch (JMSException e) {
                log.error(e.getMessage(), e);
            }
        }

        return false;
    }

    @Override
    public Integer foundDevice(Integer socketId) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ACTION, ACTION_FOUND_DEVICE);
        map.put(SOCKET_ID, socketId);

        Message message = sender.request(map);
        if (message != null && message instanceof MapMessage) {
            try {
                if (((MapMessage) message).itemExists(RESULT)) {
                    return ((MapMessage) message).getInt(RESULT);
                }
            } catch (JMSException e) {
                log.error(e.getMessage(), e);
            }
        }
        return null;
    }

    @Override
    public Integer foundSocket(Integer deviceNum) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ACTION, ACTION_FOUND_SOCKET);
        map.put(DEVICE_NUM, deviceNum);

        Message message = sender.request(map);
        if (message != null && message instanceof MapMessage) {
            try {
                if (((MapMessage) message).itemExists(RESULT)) {
                    return ((MapMessage) message).getInt(RESULT);
                }
            } catch (JMSException e) {
                log.error(e.getMessage(), e);
            }
        }
        return null;
    }

    @Override
    public boolean removeDeviceBySocket(Integer socketId) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ACTION, ACTION_REMOVE_BY_SOCKET);
        map.put(SOCKET_ID, socketId);

        Message message = sender.request(map);
        if (message != null && message instanceof MapMessage) {
            try {
                if (((MapMessage) message).itemExists(RESULT)) {
                    return ((MapMessage) message).getBoolean(RESULT);
                }
            } catch (JMSException e) {
                log.error(e.getMessage(), e);
            }
        }
        return false;
    }

    @Override
    public boolean removeDeviceByDevice(Integer deviceNum) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ACTION, ACTION_REMOVE_BY_DEVICE);
        map.put(DEVICE_NUM, deviceNum);

        Message message = sender.request(map);
        if (message != null && message instanceof MapMessage) {
            try {
                if (((MapMessage) message).itemExists(RESULT)) {
                    return ((MapMessage) message).getBoolean(RESULT);
                }
            } catch (JMSException e) {
                log.error(e.getMessage(), e);
            }
        }
        return false;
    }
}
