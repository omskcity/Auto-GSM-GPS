package com.navi.modules.auth;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * DAO for auth
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class AuthDAO {
    private final static Logger log = Logger.getLogger(AuthDAO.class);

    //private final static String SQL_FOUND_DEVICE = "select d.id from n_device d where d.imei=:imei and d.number=:number";
    private final static String SQL_FOUND_DEVICE = "select d.id from n_device d where d.number=:number";
    private final static String SQL_DEL_DEVICE_SOCKET = "delete from n_device_socket where device_id=:device_id";
    private final static String SQL_ADD_DEVICE_SOCKET = "insert into n_device_socket(device_id, socket_id) values (:device_id, :socket_id)";
    private final static String SQL_LOAD_DEVICE_SOCKET = "select d.number, s.socket_id from n_device d, n_device_socket s where d.id=s.device_id";

    public static Integer foundDevice(DataSource dataSource, String imei, final Integer deviceNum) {
        NamedParameterJdbcOperations operations = new NamedParameterJdbcTemplate(dataSource);
        Map<String,Object> args = new HashMap<String,Object>();
        args.put("imei", imei);
        args.put("number", deviceNum);
        Integer deviceId = null;
        try {
            deviceId = operations.queryForInt(SQL_FOUND_DEVICE, args);
        } catch (DataAccessException e) {
            log.error(e.getMessage(), e);
        }
        return deviceId;
    }

    public static boolean registerDevice(DataSource dataSource, final Integer deviceId, final Integer socketId) {
        NamedParameterJdbcOperations operations = new NamedParameterJdbcTemplate(dataSource);
        Map<String,Object> args = new HashMap<String,Object>();
        args.put("device_id", deviceId);
        args.put("socket_id", socketId);
        try {
            operations.update(SQL_DEL_DEVICE_SOCKET, args);
            operations.update(SQL_ADD_DEVICE_SOCKET, args);
        } catch (DataAccessException e) {
            log.error(e.getMessage(), e);
            return false;
        }
        return true;
    }

    public static boolean unregisterDevice(DataSource dataSource, final Integer deviceId) {
        NamedParameterJdbcOperations operations = new NamedParameterJdbcTemplate(dataSource);
        Map<String,Object> args = new HashMap<String,Object>();
        args.put("device_id", deviceId);
        try {
            operations.update(SQL_DEL_DEVICE_SOCKET, args);
        } catch (DataAccessException e) {
            log.error(e.getMessage(), e);
            return false;
        }
        return true;
    }

    private static Integer getInt(Map<String, Object> map, String str) {
        if (map.containsKey(str)) {
            Object o = map.get(str);
            if (o instanceof Integer) {
                return (Integer)o;
            }
        }
        return null;
    }
    public static Map<Integer, Integer> loadSocketDevices(DataSource dataSource) {
        NamedParameterJdbcOperations operations = new NamedParameterJdbcTemplate(dataSource);
        Map<Integer, Integer> result = new HashMap<Integer, Integer>();
        try {
            List<Map<String, Object>> res = operations.queryForList(SQL_LOAD_DEVICE_SOCKET, new HashMap<String, Object>());
            if (res != null) {
                for(Map<String, Object> map: res) {
                    Integer deviceNum = getInt(map, "number");
                    Integer socketId = getInt(map, "socket_id");
                    if (deviceNum != null && socketId != null) {
                        result.put(deviceNum, socketId);
                    }
                }
            }
        } catch (DataAccessException e) {
            log.error(e.getMessage(), e);
        }
        return result;


    }

}
