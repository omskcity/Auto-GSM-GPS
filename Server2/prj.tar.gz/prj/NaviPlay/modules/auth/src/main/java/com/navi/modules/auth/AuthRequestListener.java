package com.navi.modules.auth;

import com.navi.core.jms.Sender;
import org.apache.log4j.Logger;

import javax.jms.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Prototype of package executor with DataSource and message sender.
 *
 * @author <a href="mailto:basl.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class AuthRequestListener implements MessageListener {

    final Logger log = Logger.getLogger(AuthRequestListener.class);
    private Sender sender;
    private AuthManager authManager;

    public AuthRequestListener(Sender sender, AuthManager authManager) {
        this.sender = sender;
        this.authManager = authManager;
    }

    @Override
    public void onMessage(final Message message) {
        try {
            if (message instanceof MapMessage) {
                MapMessage mapMessage = (MapMessage)message;
                String action = mapMessage.getString(JMSAuthManagerImpl.ACTION);
                if (JMSAuthManagerImpl.ACTION_ADD.equals(action)) {
                    String imei = mapMessage.getString(JMSAuthManagerImpl.IMEI);
                    Integer deviceNum = mapMessage.getInt(JMSAuthManagerImpl.DEVICE_NUM);
                    Integer socketId = mapMessage.getInt(JMSAuthManagerImpl.SOCKET_ID);
                    boolean res =  authManager.addDevice(imei, deviceNum, socketId);
                    Map<String, Object> resMap = new HashMap<String, Object>();
                    resMap.put(JMSAuthManagerImpl.RESULT, res);
                    sender.reply(resMap, message);

                } else if (JMSAuthManagerImpl.ACTION_REMOVE_BY_DEVICE.equals(action)) {
                    Integer deviceNum = mapMessage.getInt(JMSAuthManagerImpl.DEVICE_NUM);
                    boolean res =  authManager.removeDeviceByDevice(deviceNum);
                    Map<String, Object> resMap = new HashMap<String, Object>();
                    resMap.put(JMSAuthManagerImpl.RESULT, res);
                    sender.reply(resMap, message);

                } else if (JMSAuthManagerImpl.ACTION_REMOVE_BY_SOCKET.equals(action)) {
                    Integer socketId = mapMessage.getInt(JMSAuthManagerImpl.SOCKET_ID);
                    boolean res =  authManager.removeDeviceBySocket(socketId);
                    Map<String, Object> resMap = new HashMap<String, Object>();
                    resMap.put(JMSAuthManagerImpl.RESULT, res);
                    sender.reply(resMap, message);

                } else if (JMSAuthManagerImpl.ACTION_FOUND_DEVICE.equals(action)) {
                    Integer socketId = mapMessage.getInt(JMSAuthManagerImpl.SOCKET_ID);
                    Integer res =  authManager.foundDevice(socketId);
                    Map<String, Object> resMap = new HashMap<String, Object>();
                    resMap.put(JMSAuthManagerImpl.RESULT, res);
                    sender.reply(resMap, message);

                } else if (JMSAuthManagerImpl.ACTION_FOUND_SOCKET.equals(action)) {
                    Integer deviceNum = mapMessage.getInt(JMSAuthManagerImpl.DEVICE_NUM);
                    Integer res =  authManager.foundSocket(deviceNum);
                    Map<String, Object> resMap = new HashMap<String, Object>();
                    resMap.put(JMSAuthManagerImpl.RESULT, res);
                    sender.reply(resMap, message);
                }

            }
        } catch (JMSException e) {
            log.error(e.getMessage(),e);
        }
    }
}
