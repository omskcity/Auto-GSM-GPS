package com.navi.modules.auth;

public interface AuthManager {

    public boolean addDevice(String imei, Integer deviceNum, Integer socketId);

    public Integer foundDevice(Integer socketId);

    public Integer foundSocket(Integer deviceNum);

    public boolean removeDeviceBySocket(Integer socketId);

    public boolean removeDeviceByDevice(Integer deviceNum);

}
