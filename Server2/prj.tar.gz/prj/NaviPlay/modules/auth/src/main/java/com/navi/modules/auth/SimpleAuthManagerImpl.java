package com.navi.modules.auth;

import org.apache.log4j.Logger;

import java.util.HashMap;
import java.util.Map;

public class SimpleAuthManagerImpl implements AuthManager {
    private Logger log = Logger.getLogger(SimpleAuthManagerImpl.class);

    private Map<Integer, Integer> socket2device = new HashMap<Integer, Integer>();


    @Override
    public boolean addDevice(String imei, final Integer deviceNum, final Integer socketId) {
        log.info("registered device " +
                "deviceNumber=" + deviceNum +
                ", socketId=" + socketId
        );
        socket2device.put(deviceNum, socketId);

        return true;
    }

    @Override
    public Integer foundDevice(Integer socketId) {
        for (Integer deviceNum : socket2device.keySet()) {
            if (socket2device.get(deviceNum).equals(socketId)) {
                return deviceNum;
            }
        }
        return null;
    }

    @Override
    public Integer foundSocket(Integer deviceNum) {
        return socket2device.get(deviceNum);
    }

    @Override
    public boolean removeDeviceBySocket(Integer socketId) {
        Integer key = null;
        for (Integer tkey: socket2device.keySet()) {
            if (socket2device.get(tkey).equals(socketId)) {
                key = tkey;
                break;
            }
        }

        if (key != null) {
            log.info("unregistered device " +
                    "deviceNumber=" + key+
                    ", socketId=" + socketId
            );
            socket2device.remove(key);
            return true;

        }
        return false;
    }

    @Override
    public boolean removeDeviceByDevice(Integer deviceNum) {
        if (socket2device.containsKey(deviceNum)) {
            log.info("unregistered device " +
                    "deviceNumber=" + deviceNum+
                    ", socketId=" + socket2device.get(deviceNum)
            );
            socket2device.remove(deviceNum);
            return true;
        }
        return false;
    }
}
