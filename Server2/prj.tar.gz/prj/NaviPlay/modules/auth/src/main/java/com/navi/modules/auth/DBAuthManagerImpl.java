package com.navi.modules.auth;

import org.apache.log4j.Logger;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

public class DBAuthManagerImpl implements AuthManager {
    private Logger log = Logger.getLogger(DBAuthManagerImpl.class);

    private DataSource dataSource;

    public DBAuthManagerImpl(DataSource dataSource) {
        this.dataSource = dataSource;
        init();
    }

    private Map<Integer, Integer> socket2device = new HashMap<Integer, Integer>();


    private void init () {
        Map<Integer, Integer> map = AuthDAO.loadSocketDevices(dataSource);
        socket2device.clear();
        socket2device.putAll(map);
    }

    @Override
    public boolean addDevice(String imei, final Integer deviceNum, final Integer socketId) {
        log.info("registered device " +
                 "deviceNumber=" + deviceNum +
                 ", socketId=" + socketId
        );
        Integer deviceId = AuthDAO.foundDevice(dataSource, imei, deviceNum);
        if (deviceId != null) {
            AuthDAO.registerDevice(dataSource, deviceId, socketId);
            socket2device.put(deviceNum, socketId);
            return true;

        } else {
            return false;
        }
    }

    @Override
    public Integer foundDevice(Integer socketId) {
        for (Integer deviceNum : socket2device.keySet()) {
            if (socket2device.get(deviceNum).equals(socketId)) {
                return deviceNum;
            }
        }
        return null;
    }

    @Override
    public Integer foundSocket(Integer deviceNum) {
        return socket2device.get(deviceNum);
    }

    @Override
    public boolean removeDeviceBySocket(Integer socketId) {
        Integer key = null;
        for (Integer tkey: socket2device.keySet()) {
            if (socket2device.get(tkey).equals(socketId)) {
                key = tkey;
                break;
            }
        }

        if (key != null) {
            log.info("unregistered device " +
                     "deviceNumber=" + key+
                     ", socketId=" + socketId
            );
            AuthDAO.unregisterDevice(dataSource, key);
            socket2device.remove(key);
            return true;

        }
        return false;
    }

    @Override
    public boolean removeDeviceByDevice(Integer deviceNum) {
        if (socket2device.containsKey(deviceNum)) {
            log.info("unregistered device " +
                     "deviceNumber=" + deviceNum+
                     ", socketId=" + socket2device.get(deviceNum)
            );
            AuthDAO.unregisterDevice(dataSource, deviceNum);
            socket2device.remove(deviceNum);
            return true;
        }
        return false;
    }
}
