package com.navi.client.dao;

import com.navi.core.client.Coordinate;
import com.navi.core.client.DeviceStatus;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import javax.sql.DataSource;
import java.util.*;

/**
 * DAO for auth
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class DeviceStatusDAO {
    private final static Logger log = Logger.getLogger(DeviceStatusDAO.class);

    private final static String SQL_FOUND_DEVICE_STATUS = "SELECT id  FROM n_device_status WHERE device_id=:device_id";
    private final static String SQL_ADD_DEVICE_SOCKET = "INSERT INTO n_device_status(device_id, date, longitude, latitude, height, alarm) VALUES (:device_id, :date, :longitude, :latitude, :height, :alarm)";
//    private final static String SQL_DEL_DEVICE_STATUS = "delete from n_device_status where device_id=:device_id";
    private final static String SQL_UPDATE_DEVICE_SOCKET = "UPDATE n_device_status SET date = :date, longitude = :longitude, latitude = :latitude, height = :height, alarm = :alarm WHERE device_id = :device_id";
    private final static String SQL_LOAD_DEVICE_STATUS = "SELECT d.number device_num, s.* FROM n_device d, n_device_status s WHERE d.id=s.device_id order by d.id, s.date";

    public static Integer foundDeviceStatus(DataSource dataSource, final Integer deviceId) {
        NamedParameterJdbcOperations operations = new NamedParameterJdbcTemplate(dataSource);
        Map<String,Object> args = new HashMap<String,Object>();
        args.put("device_id", deviceId);
        Integer statusId = null;
        try {
            statusId = operations.queryForInt(SQL_FOUND_DEVICE_STATUS, args);
        } catch (DataAccessException e) {
            log.error(e.getMessage(), e);
        }
        return statusId;
    }
    public static boolean registerstatus(DataSource dataSource, DeviceStatus data) {
        Integer deviceId = DeviceDAO.foundDevice(dataSource, data.getDeviceNumber());
        Integer statusId = foundDeviceStatus(dataSource, deviceId);
        if (statusId == null) {
            return addDeviceStatus(dataSource, data, deviceId);
        } else {
            return updateDeviceStatus(dataSource, data, deviceId);
        }
    }

    private static Map<String,Object> status2map(DataSource dataSource, DeviceStatus status) {
        Integer deviceId = DeviceDAO.foundDevice(dataSource, status.getDeviceNumber());
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("device_id", deviceId);
        map.put("date", status.getLastChange());
        Long longitude = null;
        Long latitude = null;
        Integer height = null;
        if (status.getCoordinate() != null) {
            longitude = status.getCoordinate().getLongitude();
            latitude = status.getCoordinate().getLatitude();
            height = status.getCoordinate().getHeight();

        }
        map.put("longitude", longitude);
        map.put("latitude", latitude);
        map.put("height", height);
        map.put("alarm", status.getAlarm());
        return map;
    }

    private static DeviceStatus map2status(Map<String,Object> map) {
        DeviceStatus status = new DeviceStatus();
        status.setDeviceNumber(getInt(map, "device_num"));
        status.setLastChange(getDate(map, "date"));
        status.setCoordinate(new Coordinate(getLong(map, "longitude"), getLong(map, "latitude"), getInt(map, "height")));
        status.setAlarm(getBool(map, "alarm"));
        return status;
    }

    private static boolean addDeviceStatus(DataSource dataSource, DeviceStatus data, Integer deviceId) {
        NamedParameterJdbcOperations operations = new NamedParameterJdbcTemplate(dataSource);
        Map<String,Object> args = status2map(dataSource, data);
        args.put("device_id", deviceId);
        try {
            operations.update(SQL_ADD_DEVICE_SOCKET, args);
        } catch (DataAccessException e) {
            log.error(e.getMessage(), e);
            return false;
        }
        return true;
    }
    private static boolean updateDeviceStatus(DataSource dataSource, DeviceStatus data, Integer deviceId) {
        NamedParameterJdbcOperations operations = new NamedParameterJdbcTemplate(dataSource);
        Map<String,Object> args = status2map(dataSource, data);
        args.put("device_id", deviceId);
        try {
            operations.update(SQL_UPDATE_DEVICE_SOCKET, args);
        } catch (DataAccessException e) {
            log.error(e.getMessage(), e);
            return false;
        }
        return true;
    }

    private static Boolean getBool(Map<String, Object> map, String str) {
        if (map.containsKey(str)) {
            Object o = map.get(str);
            if (o instanceof Boolean) {
                return (Boolean)o;
            }
        }
        return null;
    }

    private static Integer getInt(Map<String, Object> map, String str) {
        if (map.containsKey(str)) {
            Object o = map.get(str);
            if (o instanceof Integer) {
                return (Integer)o;
            }
        }
        return null;
    }

    private static Long getLong(Map<String, Object> map, String str) {
        if (map.containsKey(str)) {
            Object o = map.get(str);
            if (o instanceof Long) {
                return (Long)o;
            }
        }
        return null;
    }

    private static Date getDate(Map<String, Object> map, String str) {
        if (map.containsKey(str)) {
            Object o = map.get(str);
            if (o instanceof Date) {
                return (Date)o;
            }
        }
        return null;
    }

    public static List<DeviceStatus> loadDeviceStatus(DataSource dataSource) {
        NamedParameterJdbcOperations operations = new NamedParameterJdbcTemplate(dataSource);
        List<DeviceStatus> result = new ArrayList<DeviceStatus>();
        try {
            List<Map<String, Object>> res = operations.queryForList(SQL_LOAD_DEVICE_STATUS, new HashMap<String, Object>());
            if (res != null) {
                for(Map<String, Object> map: res) {
                    result.add(map2status(map));
                }
            }
        } catch (DataAccessException e) {
            log.error(e.getMessage(), e);
        }
        return result;


    }

}
