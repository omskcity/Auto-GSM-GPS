package com.navi.client.dao;

import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcOperations;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

/**
 * DAO for device
 *
 * @author <a href="mailto:basil.belokon@gmail.com">Vasily Belokon</a>
 * @version 1.0
 */
public class DeviceDAO {
    private final static Logger log = Logger.getLogger(DeviceDAO.class);

    private final static String SQL_FOUND_DEVICE = "select d.id from n_device d where d.number=:number";

    public static Integer foundDevice(DataSource dataSource, final Integer deviceNum) {
        NamedParameterJdbcOperations operations = new NamedParameterJdbcTemplate(dataSource);
        Map<String,Object> args = new HashMap<String,Object>();
        args.put("number", deviceNum);
        Integer deviceId = null;
        try {
            deviceId = operations.queryForInt(SQL_FOUND_DEVICE, args);
        } catch (DataAccessException e) {
            log.error(e.getMessage(), e);
        }
        return deviceId;
    }

}
