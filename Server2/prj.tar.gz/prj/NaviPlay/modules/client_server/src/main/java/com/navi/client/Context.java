package com.navi.client;

import com.navi.client.dao.DeviceStatusDAO;
import com.navi.core.client.DeviceStatus;

import javax.sql.DataSource;
import java.util.*;

public class Context {

    private DataSource dataSource;

    private Map<Integer, DeviceStatus> deviceStatuses = new HashMap<Integer, DeviceStatus>();

    public Context(DataSource dataSource) {
        this.dataSource = dataSource;
    }
    public void init() {
        List<DeviceStatus> list = DeviceStatusDAO.loadDeviceStatus(dataSource);
        for (DeviceStatus dataMessage : list) {
            deviceStatuses.put(dataMessage.getDeviceNumber(), dataMessage);
        }
    }

    public DeviceStatus fetchDeviceStatus(Integer deviceNum) {
        DeviceStatus result = deviceStatuses.get(deviceNum);
        if (result == null) {
            result = new DeviceStatus();
            result.setDeviceNumber(deviceNum);
            result.setLastChange(new Date());
            deviceStatuses.put(deviceNum, result);
            storeStatus(result);
        }
        return result;
    }

    public void storeStatus(DeviceStatus dataMessage) {
        DeviceStatusDAO.registerstatus(dataSource, dataMessage);
    }

    public List<DeviceStatus> getDevicesStatus() {
        return new ArrayList<DeviceStatus>(deviceStatuses.values());
    }
}
