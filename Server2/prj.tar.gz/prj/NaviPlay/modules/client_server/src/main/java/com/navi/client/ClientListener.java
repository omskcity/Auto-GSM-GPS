package com.navi.client;

import com.navi.core.client.DeviceStatus;
import com.navi.core.client.messages.toClient.AlarmStatusMessage;
import com.navi.core.jms.Sender;
import com.navi.core.client.messages.*;
import com.navi.core.client.messages.toClient.AlarmMessage;
import com.navi.core.client.messages.toClient.ConnectMessage;
import com.navi.core.client.messages.toClient.DataMessage;
import com.navi.core.client.messages.toClient.DeviceStatusResponse;
import com.navi.core.client.messages.toClient.GetDeviceListResponse;
import com.navi.core.client.messages.GetDeviceListRequest;
import com.navi.core.client.AlarmType;
import org.apache.log4j.Logger;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;
import java.util.Date;

public class ClientListener implements MessageListener {

    final Logger log = Logger.getLogger(ClientListener.class);

    private Sender toClientSender;
    private Sender toDeviceSender;
    private Sender replySender;
    private Context context;

    public ClientListener(
            Sender toClientSender,
            Sender toDeviceSender,
            Context context,
            Sender replySender
    ) {
        this.toClientSender = toClientSender;
        this.toDeviceSender = toDeviceSender;
        this.context = context;
        this.replySender = replySender;
    }

    @Override
    public void onMessage(Message message) {
        if (message instanceof ObjectMessage) {
            ObjectMessage objectMessage = (ObjectMessage)message;
            try {
                Object obj = objectMessage.getObject();
                if (obj instanceof ToClientMessage) {
                    process((ToClientMessage) obj);
                } else if (obj instanceof FromClientMessage) {
                    FromClientMessage fromClientMessage = (FromClientMessage) obj;
                    processMessageFromClient(message, fromClientMessage);
                } else {
                    log.warn("UNEXPECTED OBJECT TYPE IN MESSAGE " + obj);
                }
            } catch (JMSException e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    public void processMessageFromClient(Message message, FromClientMessage fromClientMessage) {
        if (fromClientMessage instanceof ClientRequestMessage) {
            ClientRequestMessage requestMessage = (ClientRequestMessage) fromClientMessage;
            processClientRequest(message, requestMessage);
        } else {
            log.info("dispatch message " + fromClientMessage.toString());
            toDeviceSender.send(fromClientMessage);
        }

    }

    public void processClientRequest(Message message, ClientRequestMessage clientRequest) {
        if (clientRequest instanceof GetDeviceListRequest) {
            try {
                GetDeviceListResponse response = new GetDeviceListResponse();
                response.setData(context.getDevicesStatus());
                replySender.reply(response, message);
            } catch (Exception e) {
                log.error(e.getMessage(), e);
            }
        }
    }

    public void process(ToClientMessage toClientMessage) {
        if (toClientMessage instanceof DataMessage) {
            process((DataMessage) toClientMessage);
        } else if (toClientMessage instanceof AlarmMessage) {
            process((AlarmMessage) toClientMessage);
        } else if (toClientMessage instanceof AlarmStatusMessage) {
            process((AlarmStatusMessage) toClientMessage);
        } else if (toClientMessage instanceof DeviceStatusResponse) {
            process((DeviceStatusResponse) toClientMessage);
        } else if (toClientMessage instanceof ConnectMessage) {
            process((ConnectMessage) toClientMessage);
        } else {
            log.warn("UNHANDLED OBJECT TYPE IN MESSAGE " + toClientMessage);
        }


    }

    public void process(DeviceStatusResponse deviceStatusresponse) {
        DeviceStatus status = context.fetchDeviceStatus(deviceStatusresponse.getDeviceNum());
        status.setOnline(true);
        status.setLastChange(new Date());
        status.setAlarm(deviceStatusresponse.getAlarm());
        if (deviceStatusresponse.getLowVoltage()) {
            status.addAlarm(AlarmType.LOW_EXTERNAL_VOLTAGE);
        } else {
            status.removeAlarm(AlarmType.LOW_EXTERNAL_VOLTAGE);
        }
        context.storeStatus(status);
        toClientSender.send(status);
    }

    public void process(ConnectMessage connectMessage) {
        DeviceStatus status = context.fetchDeviceStatus(connectMessage.getDeviceNum());
        status.setOnline(connectMessage.getOnline());
        status.setLastChange(new Date());
        context.storeStatus(status);
        toClientSender.send(status);
    }

    public void process(DataMessage deviceMessage) {
        DeviceStatus status = context.fetchDeviceStatus(deviceMessage.getDeviceNum());
        if (status.getLastChange().getTime() < deviceMessage.getDate().getTime()) {
            status.setOnline(true);
            status.setLastChange(deviceMessage.getDate());
            status.setAlarm(deviceMessage.getAlarm());
            status.setCoordinate(deviceMessage.getCoordinate());
            context.storeStatus(status);
            toClientSender.send(status);
        }
    }

    public void process(AlarmMessage alarmMessage) {
        DeviceStatus status = context.fetchDeviceStatus(alarmMessage.getDeviceNum());
        status.setOnline(true);
        status.cleanAlarm();
        for (AlarmType alarmType : alarmMessage.getAlarmSources()) {
            status.addAlarm(alarmType);
        }
        status.setLastChange(new Date());
        context.storeStatus(status);
        toClientSender.send(status);
    }

    public void process(AlarmStatusMessage alarmStatusMessage) {
        DeviceStatus status = context.fetchDeviceStatus(alarmStatusMessage.getDeviceNum());
        status.setOnline(true);
        status.setAlarm(alarmStatusMessage.isStatus());
        status.cleanAlarm();
        status.setLastChange(new Date());
        context.storeStatus(status);
        toClientSender.send(status);
    }

}
