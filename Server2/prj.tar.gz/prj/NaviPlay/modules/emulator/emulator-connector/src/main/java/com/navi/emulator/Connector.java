package com.navi.emulator;

import com.navi.core.jms.Sender;
import com.navi.core.client.messages.toClient.DataMessage;
import com.navi.core.client.Coordinate;

import java.util.Date;

public class Connector {


    public Connector(Sender sender) {

        DataMessage dataMessage = new DataMessage();
        dataMessage.setDeviceNum(2222);
        dataMessage.setCoordinate(new Coordinate(1L, 2L, 3));
        dataMessage.setMove(true);
        dataMessage.setSpeed(12);
        dataMessage.setAlarm(false);
        dataMessage.setDate(new Date());
        sender.sendNow(dataMessage);
        dataMessage = new DataMessage();
        dataMessage.setDeviceNum(11111);
        dataMessage.setCoordinate(new Coordinate(3L, 22L, 32));
        dataMessage.setMove(false);
        dataMessage.setSpeed(0);
        dataMessage.setAlarm(true);
        dataMessage.setDate(new Date());
        sender.sendNow(dataMessage);
        sender.close();

    }
}
