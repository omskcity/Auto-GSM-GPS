package com.navi.emulator;

import com.navi.core.jms.Sender;
import com.navi.core.client.messages.ToClientMessage;
import org.apache.log4j.Logger;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ConnectorRuner {


    public static void main(String[] args) {
        final Logger log = Logger.getLogger("main");
        new ClassPathXmlApplicationContext("connectorContext.xml");

    }

}
