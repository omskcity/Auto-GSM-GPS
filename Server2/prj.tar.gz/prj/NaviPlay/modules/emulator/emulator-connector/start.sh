#!/bin/sh

mvn dependency:build-classpath -Dmdep.outputFile=cp.txt
cp=$(cat cp.txt);
nohup java -cp "./target/emulator-send-command-from-client-server-1.0.jar:$cp" ModuleRunner &