--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.q_user2role DROP CONSTRAINT fk_q_user2role_user_id;
ALTER TABLE ONLY public.q_user2role DROP CONSTRAINT fk_q_user2role_role_id;
ALTER TABLE ONLY public.q_role_right DROP CONSTRAINT fk_q_role_right_role_id;
ALTER TABLE ONLY public.q_object DROP CONSTRAINT fk_q_object_object_type;
ALTER TABLE ONLY public.q_object DROP CONSTRAINT fk_q_object_folder;
ALTER TABLE ONLY public.q_launcher2role DROP CONSTRAINT fk_q_launcher2role_user_id;
ALTER TABLE ONLY public.q_launcher2role DROP CONSTRAINT fk_q_launcher2role_role_id;
ALTER TABLE ONLY public.q_folder DROP CONSTRAINT fk_q_folder_parent_id;
ALTER TABLE ONLY public.n_device_socket DROP CONSTRAINT fk_n_device_socket_device;
ALTER TABLE ONLY public.q_user DROP CONSTRAINT q_user_pkey;
ALTER TABLE ONLY public.q_user2role DROP CONSTRAINT q_user2role_pkey;
ALTER TABLE ONLY public.q_role_right DROP CONSTRAINT q_role_right_pkey;
ALTER TABLE ONLY public.q_role DROP CONSTRAINT q_role_pkey;
ALTER TABLE ONLY public.q_object_type DROP CONSTRAINT q_object_type_pkey;
ALTER TABLE ONLY public.q_object DROP CONSTRAINT q_object_pkey;
ALTER TABLE ONLY public.q_launcher DROP CONSTRAINT q_launcher_pkey;
ALTER TABLE ONLY public.q_launcher2role DROP CONSTRAINT q_launcher2role_pkey;
ALTER TABLE ONLY public.q_folder DROP CONSTRAINT q_folder_pkey;
ALTER TABLE ONLY public.n_device_socket DROP CONSTRAINT n_device_socket_pkey;
ALTER TABLE ONLY public.n_device DROP CONSTRAINT n_device_pkey;
DROP TABLE public.q_user2role;
DROP SEQUENCE public.sq_q_user2role;
DROP TABLE public.q_user;
DROP SEQUENCE public.sq_q_user;
DROP TABLE public.q_role_right;
DROP SEQUENCE public.sq_q_role_right;
DROP TABLE public.q_role;
DROP SEQUENCE public.sq_q_role;
DROP TABLE public.q_object_type;
DROP SEQUENCE public.sq_q_object_type;
DROP TABLE public.q_object;
DROP SEQUENCE public.sq_q_object;
DROP TABLE public.q_launcher2role;
DROP SEQUENCE public.sq_q_launcher2role;
DROP TABLE public.q_launcher;
DROP SEQUENCE public.sq_q_launcher;
DROP TABLE public.q_folder;
DROP SEQUENCE public.sq_q_folder;
DROP TABLE public.n_device_socket;
DROP SEQUENCE public.sq_n_device_socket;
DROP TABLE public.n_device;
DROP SEQUENCE public.sq_n_device;
DROP TABLE public.dual;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: dual; Type: TABLE; Schema: public; Owner: navi; Tablespace: 
--

CREATE TABLE dual (
    dual integer NOT NULL
);


ALTER TABLE public.dual OWNER TO navi;

--
-- Name: sq_n_device; Type: SEQUENCE; Schema: public; Owner: navi
--

CREATE SEQUENCE sq_n_device
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sq_n_device OWNER TO navi;

--
-- Name: n_device; Type: TABLE; Schema: public; Owner: navi; Tablespace: 
--

CREATE TABLE n_device (
    id integer DEFAULT nextval('sq_n_device'::regclass) NOT NULL,
    number integer NOT NULL,
    imei character varying(15) NOT NULL
);


ALTER TABLE public.n_device OWNER TO navi;

--
-- Name: sq_n_device_socket; Type: SEQUENCE; Schema: public; Owner: navi
--

CREATE SEQUENCE sq_n_device_socket
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sq_n_device_socket OWNER TO navi;

--
-- Name: n_device_socket; Type: TABLE; Schema: public; Owner: navi; Tablespace: 
--

CREATE TABLE n_device_socket (
    id integer DEFAULT nextval('sq_n_device_socket'::regclass) NOT NULL,
    device_id integer NOT NULL,
    socket_id integer NOT NULL
);


ALTER TABLE public.n_device_socket OWNER TO navi;

--
-- Name: sq_q_folder; Type: SEQUENCE; Schema: public; Owner: navi
--

CREATE SEQUENCE sq_q_folder
    START WITH 11
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sq_q_folder OWNER TO navi;

--
-- Name: q_folder; Type: TABLE; Schema: public; Owner: navi; Tablespace: 
--

CREATE TABLE q_folder (
    id integer DEFAULT nextval('sq_q_folder'::regclass) NOT NULL,
    parent_id integer,
    name character varying(256) DEFAULT NULL::character varying
);


ALTER TABLE public.q_folder OWNER TO navi;

--
-- Name: sq_q_launcher; Type: SEQUENCE; Schema: public; Owner: navi
--

CREATE SEQUENCE sq_q_launcher
    START WITH 4
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sq_q_launcher OWNER TO navi;

--
-- Name: q_launcher; Type: TABLE; Schema: public; Owner: navi; Tablespace: 
--

CREATE TABLE q_launcher (
    id integer DEFAULT nextval('sq_q_launcher'::regclass) NOT NULL,
    name character varying(30) DEFAULT NULL::character varying,
    descr character varying(256) DEFAULT NULL::character varying,
    data text
);


ALTER TABLE public.q_launcher OWNER TO navi;

--
-- Name: sq_q_launcher2role; Type: SEQUENCE; Schema: public; Owner: navi
--

CREATE SEQUENCE sq_q_launcher2role
    START WITH 37
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sq_q_launcher2role OWNER TO navi;

--
-- Name: q_launcher2role; Type: TABLE; Schema: public; Owner: navi; Tablespace: 
--

CREATE TABLE q_launcher2role (
    id integer DEFAULT nextval('sq_q_launcher2role'::regclass) NOT NULL,
    launcher_id integer NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE public.q_launcher2role OWNER TO navi;

--
-- Name: sq_q_object; Type: SEQUENCE; Schema: public; Owner: navi
--

CREATE SEQUENCE sq_q_object
    START WITH 177
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sq_q_object OWNER TO navi;

--
-- Name: q_object; Type: TABLE; Schema: public; Owner: navi; Tablespace: 
--

CREATE TABLE q_object (
    id integer DEFAULT nextval('sq_q_object'::regclass) NOT NULL,
    folder_id integer,
    object_type_id integer NOT NULL,
    name character varying(30) NOT NULL,
    descr character varying(256) DEFAULT NULL::character varying,
    data text
);


ALTER TABLE public.q_object OWNER TO navi;

--
-- Name: sq_q_object_type; Type: SEQUENCE; Schema: public; Owner: navi
--

CREATE SEQUENCE sq_q_object_type
    START WITH 125
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sq_q_object_type OWNER TO navi;

--
-- Name: q_object_type; Type: TABLE; Schema: public; Owner: navi; Tablespace: 
--

CREATE TABLE q_object_type (
    id integer DEFAULT nextval('sq_q_object_type'::regclass) NOT NULL,
    name character varying(30) NOT NULL,
    icon_name character varying(30) DEFAULT NULL::character varying,
    editor_name character varying(30) DEFAULT NULL::character varying,
    run_template character varying(21554) DEFAULT NULL::character varying,
    sort_index integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.q_object_type OWNER TO navi;

--
-- Name: sq_q_role; Type: SEQUENCE; Schema: public; Owner: navi
--

CREATE SEQUENCE sq_q_role
    START WITH 4
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sq_q_role OWNER TO navi;

--
-- Name: q_role; Type: TABLE; Schema: public; Owner: navi; Tablespace: 
--

CREATE TABLE q_role (
    id integer DEFAULT nextval('sq_q_role'::regclass) NOT NULL,
    name character varying(32) DEFAULT NULL::character varying,
    descr character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public.q_role OWNER TO navi;

--
-- Name: sq_q_role_right; Type: SEQUENCE; Schema: public; Owner: navi
--

CREATE SEQUENCE sq_q_role_right
    START WITH 25
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sq_q_role_right OWNER TO navi;

--
-- Name: q_role_right; Type: TABLE; Schema: public; Owner: navi; Tablespace: 
--

CREATE TABLE q_role_right (
    id integer DEFAULT nextval('sq_q_role_right'::regclass) NOT NULL,
    role_id integer NOT NULL,
    object_mask character varying(256) DEFAULT '*'::character varying NOT NULL,
    for_select integer DEFAULT 0 NOT NULL,
    for_insert integer DEFAULT 0 NOT NULL,
    for_update integer DEFAULT 0 NOT NULL,
    for_delete integer DEFAULT 0 NOT NULL,
    for_execute integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.q_role_right OWNER TO navi;

--
-- Name: sq_q_user; Type: SEQUENCE; Schema: public; Owner: navi
--

CREATE SEQUENCE sq_q_user
    START WITH 12
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sq_q_user OWNER TO navi;

--
-- Name: q_user; Type: TABLE; Schema: public; Owner: navi; Tablespace: 
--

CREATE TABLE q_user (
    id integer DEFAULT nextval('sq_q_user'::regclass) NOT NULL,
    login character varying(30) DEFAULT NULL::character varying,
    hash character varying(32) DEFAULT NULL::character varying,
    descr character varying(256) DEFAULT NULL::character varying,
    email character varying(256) DEFAULT NULL::character varying,
    enabled integer DEFAULT 1
);


ALTER TABLE public.q_user OWNER TO navi;

--
-- Name: sq_q_user2role; Type: SEQUENCE; Schema: public; Owner: navi
--

CREATE SEQUENCE sq_q_user2role
    START WITH 27
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sq_q_user2role OWNER TO navi;

--
-- Name: q_user2role; Type: TABLE; Schema: public; Owner: navi; Tablespace: 
--

CREATE TABLE q_user2role (
    id integer DEFAULT nextval('sq_q_user2role'::regclass) NOT NULL,
    user_id integer NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE public.q_user2role OWNER TO navi;

--
-- Data for Name: dual; Type: TABLE DATA; Schema: public; Owner: navi
--

COPY dual (dual) FROM stdin;
1
\.


--
-- Data for Name: n_device; Type: TABLE DATA; Schema: public; Owner: navi
--

COPY n_device (id, number, imei) FROM stdin;
1	11111	012207002702659
2	2222	012207002724885
\.


--
-- Data for Name: n_device_socket; Type: TABLE DATA; Schema: public; Owner: navi
--

COPY n_device_socket (id, device_id, socket_id) FROM stdin;
24	1	22
26	2	24
\.


--
-- Data for Name: q_folder; Type: TABLE DATA; Schema: public; Owner: navi
--

COPY q_folder (id, parent_id, name) FROM stdin;
10	\N	Система
11	\N	NaviPlay
\.


--
-- Data for Name: q_launcher; Type: TABLE DATA; Schema: public; Owner: navi
--

COPY q_launcher (id, name, descr, data) FROM stdin;
1	Админка	Админка	<dlg>\n<name>list_q_object</name>\n<operation>show</operation>\n </dlg> \n
2	Вход	Вход	<dlg>\n<name>dlg_q_login</name>\n<operation>add</operation>\n </dlg> \n
3	Выход	Выход	<dlg>\n<name>dlg_q_logout</name>\n<operation>add</operation>\n </dlg> 
\.


--
-- Data for Name: q_launcher2role; Type: TABLE DATA; Schema: public; Owner: navi
--

COPY q_launcher2role (id, launcher_id, role_id) FROM stdin;
32	1	1
33	1	2
34	2	3
35	3	2
36	3	1
\.


--
-- Data for Name: q_object; Type: TABLE DATA; Schema: public; Owner: navi
--

COPY q_object (id, folder_id, object_type_id, name, descr, data) FROM stdin;
103	10	121	dlg_q_logout	Система. Форма выхода	<dialog>\n<title>Форма выхода</title>\n<url>logout</url>\n<save_button_text>Да, хочу</save_button_text>\n<operation value="edit"/>\n<label width="480px" value="Вы хотите выйти?"/>\n</dialog> 
104	10	124	list_q_user	Система. Список Пользователей	<dialog>\n<title>Список пользователей</title>\n<list label="" width="800" height="400" multi_select="0">\n<use_filter>true</use_filter>\n<script value="select * from q_user"/>\n<columns>\n<col field="login" title="Login" width="50%"/>\n<col field="descr" title="Описание" width="50%"/>\n</columns>\n<use_filter value="true"/>\n<commands>\n<cmd title="Добавить">\n     <icon>ui-icon-plus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_user</name>\n                      <operation value="add"/>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Редактировать" for_selection="single">\n     <icon>ui-icon-check</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_user</name>\n                      <operation value="edit"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Удалить" for_selection="single">\n     <icon>ui-icon-minus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_user</name>\n                      <operation value="del"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n</commands>\n</list>\n</dialog> 
105	10	121	dlg_q_user	Система. Редактор пользователя	<dialog>\n<title>Пользователь</title>\n<width value="620px"/>\n<object value="q_user"/>\n<disabled>login</disabled>\n<know_params>id</know_params>\n<string id="login" label="login" width="400px"/>\n<string id="descr" label="Описание" width="400px"/>\n<string id="email" label="email" width="400px"/>\n<list label="" width="600px" height="400px" multi_select="0">\n<script value="select u2r.id, r.name from q_role r, q_user2role u2r where u2r.user_id=%id% and u2r.role_id=r.id"/>\n<columns>\n<col field="name" title="Название" width="50%"/>\n<col field="descr" title="Описание" width="50%"/>\n</columns>\n<commands>\n<cmd title="Добавить">\n     <icon>ui-icon-plus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_user2role</name>\n                      <operation value="add"/>\n                      <constants>\n                          <user_id>%id%</user_id>\n                      </constants>\n\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Редактировать" for_selection="single">\n     <icon>ui-icon-check</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_user2role</name>\n                      <operation value="edit"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Удалить" for_selection="single">\n     <icon>ui-icon-minus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_user2role</name>\n                      <operation value="del"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n</commands>\n</list>\n </dialog> 
106	10	124	list_q_role	Список ролей	<dialog>\n<title>Список ролей</title>\n<width value="830px"/>\n<list label="" width="800px" height="400px" multi_select="0">\n<script value="select * from q_role"/>\n<columns>\n<col field="name" title="Название" width="50%"/>\n<col field="descr" title="Описание" width="50%"/>\n</columns>\n<commands>\n<cmd title="Добавить">\n     <icon>ui-icon-plus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_role</name>\n                      <operation value="add"/>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Редактировать" for_selection="single">\n     <icon>ui-icon-check</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_role</name>\n                      <operation value="edit"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Удалить" for_selection="single">\n     <icon>ui-icon-minus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_role</name>\n                      <operation value="del"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n</commands>\n</list>\n</dialog> 
107	10	121	dlg_q_role	Система. Редактор роли	<dialog>\n<title>Роль</title>\n<width value="620px"/>\n<object value="q_role"/>\n<string id="name" label="Название" width="400px"/>\n<string id="descr" label="Описание" width="400px"/>\n<list label="" width="600px" height="200px" multi_select="0">\n<script value="select rr.* from q_role_right rr where rr.role_id=:role_id"/>\n<script_param>\n<role_id>%id%</role_id>\n</script_param>\n<columns>\n<col field="object_mask" title="Название" width="50%"/>\n<col field="for_select" title="S" width="10px"/>\n<col field="for_insert" title="I" width="10px"/>\n<col field="for_update" title="U" width="10px"/>\n<col field="for_delete" title="D" width="10px"/>\n<col field="for_execute" title="X" width="10px"/>\n</columns>\n<commands>\n<cmd title="Добавить">\n     <command>\n           <dlg>\n                      <name>dlg_q_role_right</name>\n                      <operation value="add"/>\n                      <params>\n                          <role_id value="%id%"/>\n                      </params>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Редактировать" for_selection="single">\n     <command>\n           <dlg>\n                      <name>dlg_q_role_right</name>\n                      <operation value="edit"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Удалить" for_selection="single">\n     <command>\n           <dlg>\n                      <name>dlg_q_role_right</name>\n                      <operation value="del"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n</commands>\n</list>\n </dialog> 
108	10	121	dlg_q_role_right	Система. Редактор элемента роли	<dialog>\n<title>Доступ на обьект</title>\n<width value="500px"/>\n<object value="q_role_right"/>\n<string id="object_mask" label="Обьект*" width="200px"/>\n\n<checkbox id="for_select" label="for_select" width="200px"/>\n<checkbox id="for_insert" label="for_insert" width="200px"/>\n<checkbox id="for_update" label="for_update" width="200px"/>\n<checkbox id="for_delete" label="for_delete" width="200px"/>\n<checkbox id="for_execute" label="for_execute" width="200px"/>\n </dialog> 
109	10	121	dlg_q_folder	Система. Редактор папки	<dialog>\n<title>Папка</title>\n<width value="500px"/>\n<object value="q_folder"/>\n<spr id="parent_id" label="Входит в" width="200px" spr_name="q_folder"/>\n<string id="name" label="Имя" width="200px"/>\n </dialog> 
110	10	121	dlg_q_user2role	Система. Роль пользователя	<dialog>\n<title>Роль пользователя</title>\n<width value="540px"/>\n<object value="q_user2role"/>\n<spr id="user_id" label="Пользователь" spr_name="q_user" width="300px"/>\n<spr id="role_id" label="Роль" spr_name="q_role" width="300px"/>\n </dialog> 
126	10	121	dlg_q_login	Система. Форма входа в систему.	<dialog>\n<title>Форма входа</title>\n<url>j_spring_security_check</url>\n<save_button_text>Вход</save_button_text>\n<operation value="edit"/>\n\n<commands>\n    <cmd>\n   <name value="Регистрация"/>\n   <icon value="ui-icon-plus"/>\n    <cmd>\n      <dlg>\n        <name>dlg_q_user_registrtion</name>\n      </dlg>\n    </cmd>\n    </cmd>\n    <cmd>\n   <name value="Сброс пароля"/>\n   <icon value="ui-icon-cancel"/>\n    <cmd>\n      <dlg>\n        <name>dlg_q_recovery_pass</name>\n      </dlg>\n    </cmd>\n    </cmd>\n</commands>\n\n<string label="Логин*" width="200px" id="j_username"/>\n<string label="Пароль*" width="200px" type="password" id="j_password"/>\n</dialog> \n
128	10	121	dlg_q_change_date	Система. Смена даты	<dialog>\n<title>Сменить дату</title>\n<url>session-data.do</url>\n<width value="400px"/>\n<operation>edit</operation>\n<date label="Дата*" width="200px" id="curr_date"/>\n</dialog> \n
129	10	121	dlg_q_user_registrtion	Система. Регистрация пользователя	<dialog>\n<title>Регистрация</title>\n<url>registration.do</url>\n<width value="500px"/>\n<operation>edit</operation>\n<constants>\n<license_info>\nСвоей регистрацией в системе заказа питания я добровольно соглашаюсь периодически исполнять функции по поддержанию процессов обеспечения участников систмы питанием. Отказ от исполнения мной указанных функций означает бессрочный и безвозвратный отказ от использования системы заказа питания.\n</license_info>\n<mode>registration</mode>\n</constants>\n<label width="480px" value="%license_info%"/>\n<string label="Логин*" width="300px" id="login"/>\n<string label="Пароль*" type="password" width="300px" id="pass"/>\n<string label="Подтверждение*" type="password" width="300px" id="pass_confirm"/>\n<string label="email*" width="300px" id="email"/>\n<string label="ФИО*" width="300px" id="descr"/>\n\n</dialog> \n
130	10	121	dlg_q_user_passchange	Система. Смена пороля	<dialog>\n<title>Смена пороля</title>\n<url>registration.do</url>\n<operation>edit</operation>\n<constants>\n<mode>change_pass</mode>\n</constants>\n<string label="Новый пароль*" type="password" width="300px" id="new_pass"/>\n<string label="Подтверждение*" type="password" width="300px" id="new_pass_confirm"/>\n</dialog> \n
131	10	121	dlg_q_user_simple	Система. Редактор пользователя простой	<dialog>\n<title>Пользователь</title>\n<width value="620px"/>\n<object value="q_user"/>\n<operation value="edit"/>\n<disabled>login</disabled>\n<required_params>\n<login>Не указан логин</login>\n<descr>Не указано описание</descr>\n<email>Не указан почтовый адрес</email>\n</required_params>\n<string id="login" label="login" width="400px"/>\n<string id="descr" label="Описание" width="400px"/>\n<string id="email" label="email" width="400px"/>\n </dialog> 
132	10	124	list_tables	Список таблиц	<dialog>\n<title>Список таблиц</title>\n<width value="630px"/>\n<list label="" width="600px" height="400px" multi_select="0">\n<script>\nSHOW TABLES\n</script>\n<columns>\n</columns>\n<use_filter value="true"/>\n<commands>\n</commands>\n</list>\n</dialog> 
133	10	121	dlg_q_recovery_pass	Востановление пароля	<dialog>\n<title>Сброс пароля</title>\n<url>registration.do</url>\n<width value="500px"/>\n<operation>edit</operation>\n<save_button_text>Сбросить</save_button_text>\n<constants>\n<mode>recoverypass</mode>\n</constants>\n<string label="email*" width="300px" id="email"/>\n</dialog> \n
140	10	124	list_q_object_type	Список типов обьектов	<dialog>\n<title>Список типов обьектов</title>\n<width value="830px"/>\n<list label="" width="600" height="400" multi_select="0">\n<script value="select * from q_object_type"/>\n<columns>\n<col field="name" title="Название" width="100%"/>\n<col field="icon_name" as_icon="true" title="" width="20"/>\n</columns>\n<commands>\n<cmd title="Добавить">\n     <icon>ui-icon-plus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_object_type</name>\n                      <operation value="add"/>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Редактировать" for_selection="single">\n     <icon>ui-icon-check</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_object_type</name>\n                      <operation value="edit"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Удалить" for_selection="single">\n     <icon>ui-icon-minus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_object_type</name>\n                      <operation value="del"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n</commands>\n</list>\n</dialog> 
141	10	121	dlg_q_object_type	Редактирование типов обьектов	<dialog>\n<title>Тип обьектов</title>\n<object value="q_object_type"/>\n<required_params>\n<name>Не указано название</name>\n</required_params>\n\n<string id="name" label="Название" width="200px"/>\n<string id="icon_name" label="Иконка" width="200px"/>\n<string id="editor_name" label="Форма для редактирования" width="200"/>\n<string id="sort_index" label="Порядок сортировки" width="200px"/>\n<text id="run_template" label="Шаблон команды запуска" with="400" height="400"/>\n </dialog>
142	10	121	dlg_q_object	Редактор обьекта	<dialog>\n<title>Обьект</title>\n<object value="q_object"/>\n<required_params>\n<name>Не указано название</name>\n<object_type_id>Не указан тип обьекта</object_type_id>\n</required_params>\n\n<spr id="object_type_id" spr_name="q_object_type" label="Тип" width="200px"/>\n<string id="name" label="Название" width="200"/>\n<string id="descr" label="Описание" width="200"/>\n<spr id="folder_id" spr_name="q_folder" label="Папка" width="200"/>\n<text id="data" label="" width="400" height="400"/>\n </dialog>
143	10	124	list_q_object	Список обьектов	<dialog>\n<title>Список обьектов</title>\n<know_params>folder_id</know_params>\n<list label="" width="600" height="400" multi_select="0">\n<use_filter value="true"/>\n<script>\nselect concat('folder_', cast(f.id as char)) id\n ,f.name \n ,f.name display_name\n ,'Папка' type_name\n ,'ui-icon-folder-collapsed' icon\n ,'<dlg><name>list_q_object</name><operation value="show"/><constants><folder_id>' || f.id || '</folder_id></constants></dlg>' run_oper\n ,'<dlg><name>dlg_q_folder</name><operation value="edit"/><id>' ||f.id ||'</id></dlg>' edit_oper\n ,'<dlg><name>dlg_q_folder</name><operation value="del"/><id>' ||f.id || '</id></dlg>' del_oper\n,concat('001_',f.name) sort_order\n from q_folder f\nwhere coalesce(:folder_id,-1)=coalesce(f.parent_id, -1)\nunion all\nselect concat('folder_null') id\n ,'..'\n ,'..'\n ,'Папка' type_name\n ,'ui-icon-folder-collapsed' icon\n ,'<dlg><name>list_q_object</name><operation value="show"/></dlg>' run_oper\n ,'<dlg><name>dlg_q_folder</name><operation value="edit"/><id>'||:folder_id ||'</id></dlg>' edit_oper\n ,'<dlg><name>dlg_q_folder</name><operation value="del"/><id>'||:folder_id ||'</id></dlg>' del_oper\n,'000_' \n from dual\nwhere coalesce(:folder_id,-1) != -1\nunion all\nselect concat('obj_',cast(o.id as char)) id\n ,o.name\n ,concat(o.name, ' (',coalesce(o.descr, ''), ')')\n ,ot.name type_name\n ,ot.icon_name icon\n ,'<dlg><name>'||o.name||'</name><recreate value="1"/></dlg>' run_oper\n ,'<dlg><name>'||ot.editor_name||'</name><operation value="edit"/><id>'||o.id ||'</id></dlg>' edit_oper\n ,'<dlg><name>'|| ot.editor_name||'</name><operation value="del"/><id>'||o.id ||'</id></dlg>' del_oper\n,concat(ot.sort_index,o.descr) sort_order\nfrom q_object o \n,q_object_type ot \nwhere ot.id=o.object_type_id\n  and coalesce(:folder_id,-1)=coalesce(o.folder_id, -1)\norder by sort_order\n\n</script>\n<script_param>\n<folder_id>%folder_id%</folder_id>\n</script_param>\n\n<columns>\n<col field="icon" as_icon="1" title="" width="20"/>\n<col field="display_name" title="Название" width="100%"/>\n</columns>\n<commands>\n<cmd title="Новая папка" key="F7">\n     <icon>ui-icon-folder-collapsed,ui-icon-plus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_folder</name>\n                      <operation value="add"/>\n                      <constants><parent_id value="%folder_id%"/></constants>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Добавить" key="insert">\n     <icon>ui-icon-plus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_object</name>\n                      <operation value="add"/>\n                      <constants><folder_id value="%folder_id%"/></constants>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Редактировать" for_selection="single" key="F4">\n     <icon>ui-icon-check</icon>\n     <command>\n           #edit_oper#\n     </command>\n</cmd>\n<cmd title="Удалить" for_selection="single" key="delete">\n     <icon>ui-icon-minus</icon>\n     <command>\n          #del_oper#\n     </command>\n</cmd>\n<cmd title="Запустить" for_selection="single"  key="enter">\n     <icon>ui-icon-play</icon>\n     <command>\n        #run_oper#\n     </command>\n</cmd>\n\n</commands>\n</list>\n</dialog> 
171	10	124	list_q_launcher	Ярлыки запуска	<dialog>\n<title>Список ярлыков запуска</title>\n<width value="830px"/>\n<list label="" width="800px" height="400px" multi_select="0">\n<use_filter>true</use_filter>\n<script value="select * from q_launcher"/>\n<columns>\n<col field="name" title="Название" width="50%"/>\n<col field="descr" title="Описание" width="50%"/>\n</columns>\n<use_filter value="true"/>\n<commands>\n<cmd title="Добавить" key="insert">\n     <icon>ui-icon-plus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_launcher</name>\n                      <operation value="add"/>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Редактировать" for_selection="single" key="Enter">\n     <icon>ui-icon-check</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_launcher</name>\n                      <operation value="edit"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Удалить" for_selection="single" key="del">\n     <icon>ui-icon-minus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_launcher</name>\n                      <operation value="del"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n</commands>\n</list>\n</dialog> 
172	10	121	dlg_q_launcher	Редактор ярлыка	<dialog>\n<title>Ярлык</title>\n<object value="q_launcher"/>\n<required_params>\n<name>Не указано название</name>\n</required_params>\n\n<string id="name" label="Название" width="200"/>\n<string id="descr" label="Описание" width="200"/>\n<text id="data" label="" width="400" height="200"/>\n<list label="" width="400" height="200" multi_select="0">\n<script value="select l2r.id, r.name from q_role r, q_launcher2role l2r where l2r.launcher_id=%id% and l2r.role_id=r.id"/>\n<columns>\n<col field="name" title="Роль" width="100%"/>\n</columns>\n<commands>\n<cmd title="Добавить">\n     <icon>ui-icon-plus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_launcher2role</name>\n                      <operation value="add"/>\n                      <constants>\n                          <launcher_id>%id%</launcher_id>\n                      </constants>\n\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Редактировать" for_selection="single">\n     <icon>ui-icon-check</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_launcher2role</name>\n                      <operation value="edit"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Удалить" for_selection="single">\n     <icon>ui-icon-minus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_launcher2role</name>\n                      <operation value="del"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n</commands>\n</list>\n\n\n </dialog>
173	10	121	dlg_q_launcher2role	роль для ярлыка	<dialog>\n<title>Роль для ярлыка</title>\n<object value="q_launcher2role"/>\n<spr id="launcher_id" label="Пользователь" spr_name="q_launcher" width="300"/>\n<spr id="role_id" label="Роль" spr_name="q_role" width="300"/>\n </dialog> 
174	\N	122	available_launchers	доступные ярлыки	select name, descr, data  from q_launcher
102	10	124	list_q_folder	Список папок	<dialog>\n<title>Список папок</title>\n<list label="" width="800" height="400" multi_select="0">\n<script value="select * from q_folder"/>\n<columns>\n<col field="name" title="Название" width="50%"/>\n<col field="descr" title="Описание" width="50%"/>\n</columns>\n<commands>\n<cmd title="Добавить">\n     <icon>ui-icon-plus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_folder</name>\n                      <operation value="add"/>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Редактировать" for_selection="single">\n     <icon>ui-icon-check</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_folder</name>\n                      <operation value="edit"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Удалить" for_selection="single">\n     <icon>ui-icon-minus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_q_folder</name>\n                      <operation value="del"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Содержимое" for_selection="single">\n     <icon>ui-icon-calculator</icon>\n     <command>\n           <dlg>\n                      <name>list_q_dialog</name>\n                      <operation value="show"/>\n                      <folder_id>#id#</folder_id>\n            </dlg>\n     </command>\n</cmd>\n</commands>\n</list>\n</dialog> 
181	\N	124	list_n_device	Список устройств	<dialog>\n<title>Список устройств</title>\n<list label="" width="800" height="400" multi_select="0">\n<script value="select * from n_device"/>\n<columns>\n<col field="number" title="Номер" width="50%"/>\n<col field="imei" title="imei" width="50%"/>\n</columns>\n<commands>\n<cmd title="Добавить">\n     <icon>ui-icon-plus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_n_device</name>\n                      <operation value="add"/>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Редактировать" for_selection="single">\n     <icon>ui-icon-check</icon>\n     <command>\n           <dlg>\n                      <name>dlg_n_device</name>\n                      <operation value="edit"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n<cmd title="Удалить" for_selection="single">\n     <icon>ui-icon-minus</icon>\n     <command>\n           <dlg>\n                      <name>dlg_n_device</name>\n                      <operation value="del"/>\n                      <id>#id#</id>\n            </dlg>\n     </command>\n</cmd>\n</commands>\n</list>\n</dialog> 
182	\N	121	dlg_n_device	Редактор устройств	<dialog>\n<title>Устройство</title>\n<object value="n_device"/>\n<required_params>\n<imei>Не указан imei</imei>\n<number>Не указан номер</number>\n</required_params>\n<string id="number" label="Номер" width="400"/>\n<string id="imei" label="imei" width="400"/>\n </dialog> 
183	\N	124	list_device_status	Список устройств со статусом	<dialog>\n<title>Список устройств</title>\n<list label="" width="800" height="400" multi_select="0">\n<script value="device"/>\n<script_param>\n<action>get_list</action>\n</script_param>\n<url>navi.do</url>\n<columns>\n<col field="deviceNum" title="Номер" width="20%"/>\n<col field="speed" title="скорость" width="20%"/>\n<col field="move" title="двигается" width="20%"/>\n<col field="alarm" title="охрана" width="20%"/>\n<col field="date" title="дата" width="20%"/>\n</columns>\n<commands>\n<cmd title="Поставить на охрану">\n     <command>\n           <request>\n                      <url>navi.do</url>\n                      <object>device</object>\n                      <param>\n                        <action>send_command</action>\n<command>com.navi.core.messages.toDevice.AlarmOnRequest</command>\n                        <device>#deviceNum#</device>\n                      </param>\n            </request>\n     </command>\n</cmd>\n<cmd title="Снять с охраны">\n     <command>\n           <request>\n                      <url>navi.do</url>\n                      <object>device</object>\n                      <param>\n                        <action>send_command</action>\n<command>com.navi.core.messages.toDevice.AlarmOffRequest</command>\n                        <device>#deviceNum#</device>\n                      </param>\n            </request>\n     </command>\n</cmd>\n\n</commands>\n</list>\n</dialog>
\.


--
-- Data for Name: q_object_type; Type: TABLE DATA; Schema: public; Owner: navi
--

COPY q_object_type (id, name, icon_name, editor_name, run_template, sort_index) FROM stdin;
121	form	ui-icon-contact	dlg_q_object	\N	2
122	query	ui-icon-script	dlg_q_object	\N	5
123	email_template	ui-icon-mail-closed	dlg_q_object	\N	3
124	list	ui-icon-calculator	dlg_q_object	\N	1
\.


--
-- Data for Name: q_role; Type: TABLE DATA; Schema: public; Owner: navi
--

COPY q_role (id, name, descr) FROM stdin;
1	admin	Администратор
2	user	Пользователь
3	ROLE_ANONYMOUS	Роль для пользователя который не залогинился
\.


--
-- Data for Name: q_role_right; Type: TABLE DATA; Schema: public; Owner: navi
--

COPY q_role_right (id, role_id, object_mask, for_select, for_insert, for_update, for_delete, for_execute) FROM stdin;
1	2	[ \\t\\n\\x0b\\r\\f]{0,}select .*	1	0	0	0	0
3	3	[ \\t\\n\\x0b\\r\\f]{0,}select .*	1	0	0	0	0
19	2	f_dish_like	1	1	1	1	0
21	2	еда/.*	1	1	1	1	1
22	2	q_user	1	0	1	0	0
24	3	available_launchers	1	0	0	0	1
\.


--
-- Data for Name: q_user; Type: TABLE DATA; Schema: public; Owner: navi
--

COPY q_user (id, login, hash, descr, email, enabled) FROM stdin;
11	basil	1f5aceff51af420533d4ccaa126777f1	Белоконь Василий	vbelokon@luxoft.com	1
\.


--
-- Data for Name: q_user2role; Type: TABLE DATA; Schema: public; Owner: navi
--

COPY q_user2role (id, user_id, role_id) FROM stdin;
26	11	1
\.


--
-- Name: sq_n_device; Type: SEQUENCE SET; Schema: public; Owner: navi
--

SELECT pg_catalog.setval('sq_n_device', 2, true);


--
-- Name: sq_n_device_socket; Type: SEQUENCE SET; Schema: public; Owner: navi
--

SELECT pg_catalog.setval('sq_n_device_socket', 26, true);


--
-- Name: sq_q_folder; Type: SEQUENCE SET; Schema: public; Owner: navi
--

SELECT pg_catalog.setval('sq_q_folder', 11, true);


--
-- Name: sq_q_launcher; Type: SEQUENCE SET; Schema: public; Owner: navi
--

SELECT pg_catalog.setval('sq_q_launcher', 4, false);


--
-- Name: sq_q_launcher2role; Type: SEQUENCE SET; Schema: public; Owner: navi
--

SELECT pg_catalog.setval('sq_q_launcher2role', 37, false);


--
-- Name: sq_q_object; Type: SEQUENCE SET; Schema: public; Owner: navi
--

SELECT pg_catalog.setval('sq_q_object', 183, true);


--
-- Name: sq_q_object_type; Type: SEQUENCE SET; Schema: public; Owner: navi
--

SELECT pg_catalog.setval('sq_q_object_type', 125, false);


--
-- Name: sq_q_role; Type: SEQUENCE SET; Schema: public; Owner: navi
--

SELECT pg_catalog.setval('sq_q_role', 4, false);


--
-- Name: sq_q_role_right; Type: SEQUENCE SET; Schema: public; Owner: navi
--

SELECT pg_catalog.setval('sq_q_role_right', 25, false);


--
-- Name: sq_q_user; Type: SEQUENCE SET; Schema: public; Owner: navi
--

SELECT pg_catalog.setval('sq_q_user', 12, false);


--
-- Name: sq_q_user2role; Type: SEQUENCE SET; Schema: public; Owner: navi
--

SELECT pg_catalog.setval('sq_q_user2role', 27, false);


--
-- Name: n_device_pkey; Type: CONSTRAINT; Schema: public; Owner: navi; Tablespace: 
--

ALTER TABLE ONLY n_device
    ADD CONSTRAINT n_device_pkey PRIMARY KEY (id);


--
-- Name: n_device_socket_pkey; Type: CONSTRAINT; Schema: public; Owner: navi; Tablespace: 
--

ALTER TABLE ONLY n_device_socket
    ADD CONSTRAINT n_device_socket_pkey PRIMARY KEY (id);


--
-- Name: q_folder_pkey; Type: CONSTRAINT; Schema: public; Owner: navi; Tablespace: 
--

ALTER TABLE ONLY q_folder
    ADD CONSTRAINT q_folder_pkey PRIMARY KEY (id);


--
-- Name: q_launcher2role_pkey; Type: CONSTRAINT; Schema: public; Owner: navi; Tablespace: 
--

ALTER TABLE ONLY q_launcher2role
    ADD CONSTRAINT q_launcher2role_pkey PRIMARY KEY (id);


--
-- Name: q_launcher_pkey; Type: CONSTRAINT; Schema: public; Owner: navi; Tablespace: 
--

ALTER TABLE ONLY q_launcher
    ADD CONSTRAINT q_launcher_pkey PRIMARY KEY (id);


--
-- Name: q_object_pkey; Type: CONSTRAINT; Schema: public; Owner: navi; Tablespace: 
--

ALTER TABLE ONLY q_object
    ADD CONSTRAINT q_object_pkey PRIMARY KEY (id);


--
-- Name: q_object_type_pkey; Type: CONSTRAINT; Schema: public; Owner: navi; Tablespace: 
--

ALTER TABLE ONLY q_object_type
    ADD CONSTRAINT q_object_type_pkey PRIMARY KEY (id);


--
-- Name: q_role_pkey; Type: CONSTRAINT; Schema: public; Owner: navi; Tablespace: 
--

ALTER TABLE ONLY q_role
    ADD CONSTRAINT q_role_pkey PRIMARY KEY (id);


--
-- Name: q_role_right_pkey; Type: CONSTRAINT; Schema: public; Owner: navi; Tablespace: 
--

ALTER TABLE ONLY q_role_right
    ADD CONSTRAINT q_role_right_pkey PRIMARY KEY (id);


--
-- Name: q_user2role_pkey; Type: CONSTRAINT; Schema: public; Owner: navi; Tablespace: 
--

ALTER TABLE ONLY q_user2role
    ADD CONSTRAINT q_user2role_pkey PRIMARY KEY (id);


--
-- Name: q_user_pkey; Type: CONSTRAINT; Schema: public; Owner: navi; Tablespace: 
--

ALTER TABLE ONLY q_user
    ADD CONSTRAINT q_user_pkey PRIMARY KEY (id);


--
-- Name: fk_n_device_socket_device; Type: FK CONSTRAINT; Schema: public; Owner: navi
--

ALTER TABLE ONLY n_device_socket
    ADD CONSTRAINT fk_n_device_socket_device FOREIGN KEY (device_id) REFERENCES n_device(id);


--
-- Name: fk_q_folder_parent_id; Type: FK CONSTRAINT; Schema: public; Owner: navi
--

ALTER TABLE ONLY q_folder
    ADD CONSTRAINT fk_q_folder_parent_id FOREIGN KEY (parent_id) REFERENCES q_folder(id);


--
-- Name: fk_q_launcher2role_role_id; Type: FK CONSTRAINT; Schema: public; Owner: navi
--

ALTER TABLE ONLY q_launcher2role
    ADD CONSTRAINT fk_q_launcher2role_role_id FOREIGN KEY (role_id) REFERENCES q_role(id);


--
-- Name: fk_q_launcher2role_user_id; Type: FK CONSTRAINT; Schema: public; Owner: navi
--

ALTER TABLE ONLY q_launcher2role
    ADD CONSTRAINT fk_q_launcher2role_user_id FOREIGN KEY (launcher_id) REFERENCES q_launcher(id);


--
-- Name: fk_q_object_folder; Type: FK CONSTRAINT; Schema: public; Owner: navi
--

ALTER TABLE ONLY q_object
    ADD CONSTRAINT fk_q_object_folder FOREIGN KEY (folder_id) REFERENCES q_folder(id);


--
-- Name: fk_q_object_object_type; Type: FK CONSTRAINT; Schema: public; Owner: navi
--

ALTER TABLE ONLY q_object
    ADD CONSTRAINT fk_q_object_object_type FOREIGN KEY (object_type_id) REFERENCES q_object_type(id);


--
-- Name: fk_q_role_right_role_id; Type: FK CONSTRAINT; Schema: public; Owner: navi
--

ALTER TABLE ONLY q_role_right
    ADD CONSTRAINT fk_q_role_right_role_id FOREIGN KEY (role_id) REFERENCES q_role(id);


--
-- Name: fk_q_user2role_role_id; Type: FK CONSTRAINT; Schema: public; Owner: navi
--

ALTER TABLE ONLY q_user2role
    ADD CONSTRAINT fk_q_user2role_role_id FOREIGN KEY (role_id) REFERENCES q_role(id);


--
-- Name: fk_q_user2role_user_id; Type: FK CONSTRAINT; Schema: public; Owner: navi
--

ALTER TABLE ONLY q_user2role
    ADD CONSTRAINT fk_q_user2role_user_id FOREIGN KEY (user_id) REFERENCES q_user(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

