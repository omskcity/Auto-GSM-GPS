INSERT INTO public.n_device_status (id, device_id, date, longitude, latitude, height, speed, move, alarm) VALUES (1, 2, '2013-03-13 00:41:56', 73402512, 54952972, 54952972, 0, false, true);
INSERT INTO public.n_device_status (id, device_id, date, longitude, latitude, height, speed, move, alarm) VALUES (2, 1, '2013-03-12 17:22:04', 73389920, 54976004, 54976004, 163, true, false);
