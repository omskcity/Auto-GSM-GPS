create sequence sq_n_device;
CREATE TABLE n_device (
  id int NOT NULL DEFAULT NEXTVAL('sq_n_device'),
  number int not null,
  imei varchar(15) not NULL,
  PRIMARY KEY (id)
)