/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmain.com.
**
****************************************************************************/

#ifndef NAVI_SERVER_REQUEST_PARSER
#define NAVI_SERVER_REQUEST_PARSER

#include <stdint.h>
#include <boost/logic/tribool.hpp>
#include <boost/tuple/tuple.hpp>

struct Request;

/// Parser for incoming requests.
class RequestParser
{
public:
  /// Construct ready to parse the request method.
  RequestParser();

  /// Reset to initial parser state.
  void reset();

  /// Parse some data. The tribool return value is true when a complete request
  /// has been parsed, false if the data is invalid, indeterminate when more
  /// data is required. The InputIterator return value indicates how much of the
  /// input has been consumed.
  template <typename InputIterator>
  boost::tuple<boost::tribool, InputIterator> parse(Request& req,
      InputIterator begin, InputIterator end)
  {
		while (begin != end) {
			boost::tribool result = consume(req, *begin++);
			if (result || !result) {
				if (result)
					result = checkCRC(req, *((uint16_t*)&_dataCRC[0]));
				return boost::make_tuple(result, begin);
			}
		}
		boost::tribool result = boost::indeterminate;
		return boost::make_tuple(result, begin);
  }

	private:
		/// Handle the next character of input.
		boost::tribool consume(Request& req, uint8_t input);
		static bool checkCRC(Request& req, uint16_t crc);

		/// The current state of the parser.
		enum States {
			length_start,
			length_received,
			data_receiving,
			data_received,
			read_crcL,
			read_crcH
		} _state;
		uint16_t _dataLength;
		uint16_t _dataIdx;
		uint8_t _dataCRC[2];

};

#endif // NAVI_SERVER_REQUEST_PARSER
