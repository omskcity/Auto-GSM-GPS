/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#ifndef NAVI_SERVER_CONNECTION
#define NAVI_SERVER_CONNECTION

#include <boost/asio.hpp>
#include <boost/array.hpp>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>

#include "reply.hpp"
#include "request.hpp"
#include "request_handler.hpp"
#include "request_parser.hpp"

/// Represents a single connection from a client.
class Connection
  : public boost::enable_shared_from_this<Connection>, private boost::noncopyable
{
	public:
		/// Construct a connection with the given io_service.
		explicit Connection(boost::asio::io_service& io_service, RequestHandler& handler);
		~Connection();

		/// Get the socket associated with the connection.
		boost::asio::ip::tcp::socket& socket();

		/// Start the first asynchronous operation for the connection.
		void start();

		void close();
		void retransPacket(Reply& reply);

	private:
		/// Handle completion of a read operation.
		void handleRead(const boost::system::error_code& e,
			std::size_t bytes_transferred);

		/// Handle completion of a write operation.
		void handleWrite(const boost::system::error_code& e);
		void handleWrite2(const boost::system::error_code& e);

		/// Socket for the connection.
		boost::asio::ip::tcp::socket _socket;
		unsigned long _id;

		/// The handler used to process the incoming request.
		RequestHandler& _requestHandler;

		/// Buffer for incoming data.
		boost::array<char, 16384> _buffer;

		/// The incoming request.
		Request _request;

		/// The parser for the incoming request.
		RequestParser _requestParser;

		/// The reply to be sent back to the client.
		Reply _reply;
};

typedef boost::shared_ptr<Connection> ConnectionPtr;

#endif // NAVI_SERVER_CONNECTION
