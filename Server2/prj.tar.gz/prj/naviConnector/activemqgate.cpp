/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#include "activemqgate.hpp"
#include "amqmessageproducer.hpp"
#include "amqmessageconsumer.hpp"

#include <activemq/core/ActiveMQConnectionFactory.h>
#include <activemq/library/ActiveMQCPP.h>

//#include <iostream>
//#include "defs.h"

ActiveMQGate* ActiveMQGate::_instance = 0;

ActiveMQGate::ActiveMQGate(const std::string& brokerURI,
	const std::string& producerDestURI, const std::string& consumerDestURI)
	: _connectionFactoryP(new activemq::core::ActiveMQConnectionFactory(brokerURI)),
	_producer(new AMQMessageProducer(_connectionFactoryP, producerDestURI)),
	_consumer(new AMQMessageConsumer(brokerURI, consumerDestURI))
{
	_instance = this;
}

ActiveMQGate::~ActiveMQGate()
{
	finish();
	delete _consumer;
	delete _producer;

	//delete _connectionFactoryC;
	delete _connectionFactoryP;

	_instance = 0;
}

ActiveMQGate* ActiveMQGate::instance()
{
	return _instance;
}

void ActiveMQGate::run()
{
	_producer->start();
	decaf::lang::Thread::sleep(400);
	_consumer->startWait();
}

void ActiveMQGate::finish()
{
	_consumer->close();
	decaf::lang::Thread::sleep(200);
	_producer->close();
}


void ActiveMQGate::initialize()
{
	activemq::library::ActiveMQCPP::initializeLibrary();
}

void ActiveMQGate::shutdown()
{
	activemq::library::ActiveMQCPP::shutdownLibrary();
}
