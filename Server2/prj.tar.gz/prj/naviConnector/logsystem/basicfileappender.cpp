#include "basicfileappender.h"
#include "semaphore.h"

#include <fstream>
#include <sstream>

#include <boost/format.hpp>
#include <boost/thread.hpp>

namespace LoggingSystem {

class BasicFileAppender::BasicFileAppenderImpl
{
	public:
		BasicFileAppenderImpl(const std::string& name, const std::string& fileName, bool append);
		~BasicFileAppenderImpl();

		void close();
		void doAppend(LogEventConstPtr event);
		std::string renderEvent(LogEventConstPtr event);

		struct Worker {
			Worker(BasicFileAppender::BasicFileAppenderImpl* owner) : _owner(owner) { }
			void operator()();
			BasicFileAppender::BasicFileAppenderImpl *_owner;
		};

		bool _isRunning;
		bool _appendToFile;
		Worker _worker;

		std::string _name;
		std::string _fileName;
		std::ofstream _stream;

		Semaphore _sem;
		boost::mutex _logQueueLocker;
		std::list<LogEventConstPtr> _logQueue;

		boost::thread _thread;
};

void BasicFileAppender::BasicFileAppenderImpl::Worker::operator ()()
{
	LogEventConstPtr evt;
	bool hasEvent = false;
	bool doFlush = true;

	while (_owner->_isRunning) {
		_owner->_sem.acquire();
		_owner->_logQueueLocker.lock();
		hasEvent = !_owner->_logQueue.empty();
		if (hasEvent) {
			evt = _owner->_logQueue.front();
			_owner->_logQueue.pop_front();
			doFlush = _owner->_logQueue.empty();
		}
		_owner->_logQueueLocker.unlock();
		if (hasEvent) {
			_owner->_stream << _owner->renderEvent(evt);
		}
		if (doFlush)
			_owner->_stream.flush();
	}
	_owner->_logQueueLocker.lock();
	while (!_owner->_logQueue.empty()) {
		evt = _owner->_logQueue.front();
		_owner->_logQueue.pop_front();
		_owner->_stream << _owner->renderEvent(evt);
	}
	_owner->_logQueueLocker.unlock();
	_owner->_stream.flush();
}

BasicFileAppender::BasicFileAppenderImpl::BasicFileAppenderImpl(const std::string& name,
	const std::string& fileName, bool append) : _isRunning(true), _appendToFile(append),
	_worker(this), _name(name), _fileName(fileName), _stream(),
	_sem(0), _logQueueLocker(), _logQueue(), _thread(_worker)
{
	if (append)
		_stream.open(_fileName.c_str(), std::fstream::out | std::fstream::app);
	else
		_stream.open(_fileName.c_str(), std::fstream::out | std::fstream::trunc);
}

BasicFileAppender::BasicFileAppenderImpl::~BasicFileAppenderImpl()
{
	close();
}

void BasicFileAppender::BasicFileAppenderImpl::close()
{
	_isRunning = false;
	_sem.release();
	_thread.join();

	_stream.flush();
	_stream.close();
}

void BasicFileAppender::BasicFileAppenderImpl::doAppend(LogEventConstPtr event)
{
	//_stream << renderEvent(event);
	//_stream.flush();
	boost::mutex::scoped_lock locker(_logQueueLocker);
	_logQueue.push_back(event);
	_sem.release();
}

std::string BasicFileAppender::BasicFileAppenderImpl::renderEvent(LogEventConstPtr event)
{
	boost::posix_time::time_facet* facet = new boost::posix_time::time_facet("%Y.%m.%d %H:%M:%S.%f");
	std::stringstream sstream;
	sstream.imbue(std::locale(sstream.getloc(), facet));
	sstream << "<< ";
	sstream << event->timeStamp();
	sstream << " | ";

	switch (event->level()) {
		case INFO:
			sstream << "Info   ";
			break;
		case WARN:
			sstream << "Warning";
			break;
		case ERROR:
			sstream << "Error  ";
			break;
		case FATAL:
			sstream << "Fatal  ";
			break;
		default:
			sstream << "Debug  ";
			break;
	}

	sstream << " | ";
	sstream << event->threadId();
	sstream << " >> : ";
	sstream << event->message();
	sstream << std::endl;

	return sstream.str();
}


BasicFileAppender::BasicFileAppender(const std::string& name, const std::string& fileName, bool append)
	: _impl(new BasicFileAppenderImpl(name, fileName, append))
{
}

BasicFileAppender::~BasicFileAppender()
{
	delete _impl;
}

std::string BasicFileAppender::name() const
{
	return _impl->_name;
}

void BasicFileAppender::close()
{
	_impl->close();
}

void BasicFileAppender::doAppend(LogEventConstPtr event)
{
	_impl->doAppend(event);
}

bool BasicFileAppender::appendToFile() const
{
	return _impl->_appendToFile;
}

void BasicFileAppender::setAppendToFile(bool value)
{
	_impl->_appendToFile = value;
}

std::string BasicFileAppender::renderEvent(LogEventConstPtr event)
{
	_impl->renderEvent(event);
}


} // namespace LoggingSystem
