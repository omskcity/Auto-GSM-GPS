#ifndef LOGSYSTEM_LOGEVENT_H
#define LOGSYSTEM_LOGEVENT_H

#include <string>
#include "logginglevels.h"

#include <boost/date_time/posix_time/posix_time.hpp>
#include "boost/shared_ptr.hpp"

namespace LoggingSystem {

class LogEvent
{
	public:
		explicit LogEvent(const std::string& message,
			LoggingSystem::LoggingLevels level = LoggingSystem::DEBUG);
		~LogEvent();

		std::string message() const;
		LoggingLevels level() const;
		boost::posix_time::ptime timeStamp() const;
		std::string threadId() const;

	private:
		LogEvent(const LogEvent& other);
		LogEvent& operator=(const LogEvent& other);

		class LogEventImpl;
		LogEventImpl *_impl;
};

typedef boost::shared_ptr<LogEvent> LogEventPtr;
typedef boost::shared_ptr<const LogEvent> LogEventConstPtr;

} // namespace LoggingSystem

#endif // LOGSYSTEM_LOGEVENT_HPP
