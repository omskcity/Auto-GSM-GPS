
#include "logevent.h"
#include "logginglevels.h"

#include <sstream>

#include <boost/date_time/gregorian/gregorian.hpp>
#include <boost/uuid/uuid_generators.hpp>
#include <boost/uuid/uuid_io.hpp>

#include <boost/thread.hpp>

namespace LoggingSystem {

class LogEvent::LogEventImpl
{
	public:
		LogEventImpl(const std::string& message, LoggingLevels level);

		std::string _msg;
		LoggingLevels _level;
		std::string _threadId;
		std::string _uuid;

		boost::posix_time::ptime _timeStamp;
};

LogEvent::LogEventImpl::LogEventImpl(const std::string& message, LoggingLevels level)
	: _msg(message), _level(level), _threadId(),
	_uuid(), _timeStamp(boost::posix_time::microsec_clock::local_time())
{
	//std::stringstream ss;
	//ss << boost::this_thread::get_id();
	//_threadId = ss.str();
	_threadId = boost::lexical_cast<std::string>(boost::this_thread::get_id());


	boost::uuids::basic_random_generator<boost::mt19937> uuidGen;
	boost::uuids::uuid uid = uuidGen();
	std::string s = boost::lexical_cast<std::string>(uid);
	//_uuid = std::to_string(uid);
	boost::to_upper(_uuid);
}

LogEvent::LogEvent(const std::string& message, LoggingSystem::LoggingLevels level)
	: _impl(new LogEvent::LogEventImpl(message, level))
{
}

LogEvent::~LogEvent()
{
	delete _impl;
}

std::string LogEvent::message() const
{
	return _impl->_msg;
}

LoggingLevels LogEvent::level() const
{
	return _impl->_level;
}

boost::posix_time::ptime LogEvent::timeStamp() const
{
	return _impl->_timeStamp;
}

std::string LogEvent::threadId() const
{
	return _impl->_threadId;
}

} // namespace LoggingSystem
