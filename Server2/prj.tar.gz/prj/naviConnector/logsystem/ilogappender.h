#ifndef LOGSYSTEM_ILOGAPPENDER_H
#define LOGSYSTEM_ILOGAPPENDER_H

#include <string>

#include "logevent.h"
#include "boost/shared_ptr.hpp"

namespace LoggingSystem {

class LogEvent;

class ILogAppender
{
	public:
		ILogAppender() { }
		virtual ~ILogAppender() { }

		virtual std::string name() const = 0;

		virtual void close() = 0;
		virtual void doAppend(LogEventConstPtr event) = 0;

	protected:
		virtual std::string renderEvent(LogEventConstPtr event) = 0;
};

typedef boost::shared_ptr<ILogAppender> ILogAppenderPtr;

} // namespace LoggingSystem

#endif // LOGSYSTEM_ILOGAPPENDER_HPP
