#ifndef LOGSYSTEM_ILOGGER_H
#define LOGSYSTEM_ILOGGER_H

#include "ilogappender.h"

namespace LoggingSystem {

class LogEvent;

class ILogger
{
	public:
		ILogger() { }
		virtual ~ILogger() { }

		virtual std::string name() const = 0;

		virtual void debug(const std::string& message) = 0;
		virtual void info(const std::string& message) = 0;
		virtual void warn(const std::string& message) = 0;
		virtual void error(const std::string& message) = 0;
		virtual void fatal(const std::string& message) = 0;

		virtual bool addLogAppender(ILogAppenderPtr appender) = 0;
		virtual bool removeLogAppender(ILogAppenderPtr appender) = 0;
		virtual bool removeLogAppender(const std::string& appenderName) = 0;

	protected:
		virtual void log(LogEventConstPtr event) = 0;
};

} // namespace LoggingSystem

#endif // LOGSYSTEM_ILOGGER_HPP
