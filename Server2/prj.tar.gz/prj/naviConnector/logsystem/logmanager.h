#ifndef LOGSYSTEM_LOGMANAGER_H
#define LOGSYSTEM_LOGMANAGER_H

#include <string>

namespace boost {
class mutex;
}

namespace LoggingSystem {

class ILogger;

class LogManager
{

	class LogManagerImpl;

	public:
		LogManager();
		~LogManager();

		static LogManager* instance();

		class ProxyLogger {
			public:
				ProxyLogger(ILogger* l, boost::mutex* m);
				~ProxyLogger();
				ILogger* operator->() const;

			private:
				ILogger* _l;
				boost::mutex* _m;

			friend class LogManagerImpl;
		};

		ProxyLogger getLogger(const std::string& name);
		bool registerLogger(ILogger* logger);
		bool unregisterLogger(ILogger* logger);
		bool unregisterLogger(const std::string& name);

	private:
		static LogManager *_instance;
		LogManagerImpl* _impl;
};

} // namespace LoggingSystem

#endif // LOGSYSTEM_LOGMANAGER_HPP
