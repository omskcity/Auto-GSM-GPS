#include "logmanager.h"
#include "ilogger.h"

#include <boost/thread/mutex.hpp>

#include <map>
#include <stdexcept>

namespace LoggingSystem {

LogManager* LogManager::_instance = 0;

class LogManager::LogManagerImpl
{
	public:
		LogManagerImpl();
		~LogManagerImpl();

		LogManager::ProxyLogger getLogger(const std::string& name);
		bool registerLogger(ILogger* logger);
		bool unregisterLogger(ILogger* logger);
		bool unregisterLogger(const std::string& name);

		struct SafeLogger {
			SafeLogger(ILogger* logger, boost::mutex *mutex) : logger(logger), mtx(mutex) { }

			ILogger *logger;
			boost::mutex *mtx;
		};

		typedef std::map<std::string, SafeLogger> LoggersMap;
		LoggersMap loggersMap;
		boost::mutex mtx;
};

LogManager::LogManagerImpl::LogManagerImpl()
	: loggersMap(), mtx()
{
}

LogManager::LogManagerImpl::~LogManagerImpl()
{
	boost::mutex::scoped_lock locker(mtx);

	for (LoggersMap::iterator it = loggersMap.begin(); it != loggersMap.end(); ++it)
		delete it->second.mtx;

	loggersMap.clear();
}


LogManager::ProxyLogger LogManager::LogManagerImpl::getLogger(const std::string& name)
{
	boost::mutex::scoped_lock locker(mtx);

	LoggersMap::iterator it = loggersMap.find(name);
	if (it != loggersMap.end())
		return LogManager::ProxyLogger(it->second.logger, it->second.mtx);

	throw std::runtime_error("Logger with name: " + name + " does not exist");
}

bool LogManager::LogManagerImpl::registerLogger(ILogger* logger)
{
	boost::mutex::scoped_lock locker(mtx);

	LoggersMap::iterator it = loggersMap.find(logger->name());
	if (it != loggersMap.end())
		return false;

	loggersMap.insert(std::make_pair(logger->name(),
		LogManager::LogManagerImpl::SafeLogger(logger, new boost::mutex())));

	return true;
}

bool LogManager::LogManagerImpl::unregisterLogger(ILogger* logger)
{
	return unregisterLogger(logger->name());
}

bool LogManager::LogManagerImpl::unregisterLogger(const std::string& name)
{
	boost::mutex::scoped_lock locker(mtx);

	LoggersMap::iterator it = loggersMap.find(name);
	if (it == loggersMap.end())
		return false;

	delete it->second.mtx;

	loggersMap.erase(it);
	return true;
}


LogManager::LogManager() : _impl(new LogManagerImpl())
{
	_instance = this;
}

LogManager::~LogManager()
{
	delete _impl;
	_instance = 0;
}

LogManager *LogManager::instance()
{
	return _instance;
}

LogManager::ProxyLogger LogManager::getLogger(const std::string& id)
{
	return _impl->getLogger(id);
}

bool LogManager::registerLogger(ILogger* logger)
{
	return _impl->registerLogger(logger);
}

bool LogManager::unregisterLogger(ILogger* logger)
{
	return _impl->unregisterLogger(logger);
}

bool LogManager::unregisterLogger(const std::string& name)
{
	return _impl->unregisterLogger(name);
}

LogManager::ProxyLogger::ProxyLogger(ILogger *l, boost::mutex *m) : _l(l), _m(m)
{
	_m->lock();
}

LogManager::ProxyLogger::~ProxyLogger()
{
	_m->unlock();
}

ILogger* LogManager::ProxyLogger::operator->() const
{
	return _l;
}

} // namespace LoggingSystem
