#ifndef SEMAPHORE_H
#define SEMAPHORE_H

class Semaphore
{
	public:
		explicit Semaphore(int n = 0);
		~Semaphore();

		void acquire(int n = 1);
		bool tryAcquire(int n = 1);
		bool tryAcquire(int n, int timeout);

		void release(int n = 1);

		int available() const;

	private:
		class SemaphorePrivate;
		SemaphorePrivate *_impl;
};

#endif // SEMAPHORE_H
