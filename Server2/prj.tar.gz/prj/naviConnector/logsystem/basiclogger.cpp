#include "basiclogger.h"
#include "logevent.h"
#include "ilogappender.h"

#include <boost/thread/mutex.hpp>

#include <map>

namespace LoggingSystem {

class BasicLogger::BasicLoggerImpl
{
	public:
		explicit BasicLoggerImpl(const std::string& nm) : name(nm), appenders(), mtx() { }
		~BasicLoggerImpl();

		bool addLogAppender(ILogAppenderPtr appender);
		bool removeLogAppender(ILogAppenderPtr appender);
		bool removeLogAppender(const std::string& appenderName);

		void log(LogEventConstPtr event);

		std::string name;
		typedef std::map<std::string, ILogAppenderPtr> AppendersMap;
		AppendersMap appenders;
		boost::mutex mtx;
};

BasicLogger::BasicLoggerImpl::~BasicLoggerImpl()
{
	boost::mutex::scoped_lock locker(mtx);
	appenders.clear();
}

bool BasicLogger::BasicLoggerImpl::addLogAppender(ILogAppenderPtr appender)
{
	boost::mutex::scoped_lock locker(mtx);
	AppendersMap::iterator it = appenders.find(appender->name());
	if (it != appenders.end())
		return false;

	appenders.insert(std::make_pair(appender->name(), appender));
	return true;
}

bool BasicLogger::BasicLoggerImpl::removeLogAppender(ILogAppenderPtr appender)
{
	return removeLogAppender(appender->name());
}

bool BasicLogger::BasicLoggerImpl::removeLogAppender(const std::string& appenderName)
{
	boost::mutex::scoped_lock locker(mtx);
	AppendersMap::iterator it = appenders.find(appenderName);
	if (it == appenders.end())
		return false;

	appenders.erase(it);
	return true;
}

void BasicLogger::BasicLoggerImpl::log(LogEventConstPtr event)
{
	boost::mutex::scoped_lock locker(mtx);
	for (AppendersMap::iterator it = appenders.begin(); it != appenders.end(); ++it) {
		it->second->doAppend(event);
	}
}



BasicLogger::BasicLogger(const std::string& name) : _impl(new BasicLoggerImpl(name))
{
}

BasicLogger::~BasicLogger()
{
	delete _impl;
}

std::string BasicLogger::name() const
{
	return _impl->name;
}

void BasicLogger::debug(const std::string& message)
{
	log(LogEventConstPtr(new LogEvent(message, LoggingSystem::DEBUG)));
}

void BasicLogger::info(const std::string& message)
{
	log(LogEventConstPtr(new LogEvent(message, LoggingSystem::INFO)));
}

void BasicLogger::warn(const std::string& message)
{
	log(LogEventConstPtr(new LogEvent(message, LoggingSystem::WARN)));
}

void BasicLogger::error(const std::string& message)
{
	log(LogEventConstPtr(new LogEvent(message, LoggingSystem::ERROR)));
}

void BasicLogger::fatal(const std::string& message)
{
	log(LogEventConstPtr(new LogEvent(message, LoggingSystem::FATAL)));
}

bool BasicLogger::addLogAppender(ILogAppenderPtr appender)
{
	_impl->addLogAppender(appender);
}

bool BasicLogger::removeLogAppender(ILogAppenderPtr appender)
{
	_impl->removeLogAppender(appender);
}

bool BasicLogger::removeLogAppender(const std::string& appenderName)
{
	_impl->removeLogAppender(appenderName);
}

void BasicLogger::log(LogEventConstPtr event)
{
	_impl->log(event);
}

} // namespace LoggingSystem
