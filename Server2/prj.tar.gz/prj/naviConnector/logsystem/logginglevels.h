#ifndef LOGSYSTEM_LOGGINGLEVELS_H
#define LOGSYSTEM_LOGGINGLEVELS_H

namespace LoggingSystem {

enum LoggingLevels {
	OFF = 0,
	FATAL,
	ERROR,
	WARN,
	INFO,
	DEBUG,
	ALL = 0xff
};

} // namespace LoggingSystem

#endif // LOGSYSTEM_LOGGINGLEVELS_H
