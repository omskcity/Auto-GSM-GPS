#ifndef LOGSYSTEM_FILEAPPENDER_H
#define LOGSYSTEM_FILEAPPENDER_H

#include <string>

#include "ilogappender.h"

namespace LoggingSystem {

class BasicFileAppender : public ILogAppender
{
	public:
		BasicFileAppender(const std::string& name, const std::string& fileName, bool append = true);
		~BasicFileAppender();

		std::string name() const;

		void close();
		void doAppend(LogEventConstPtr event);

		bool appendToFile() const;
		void setAppendToFile(bool value);

	protected:
		std::string renderEvent(LogEventConstPtr event);

	private:
		class BasicFileAppenderImpl;
		BasicFileAppenderImpl *_impl;
};

} // namespace LoggingSystem

#endif // LOGSYSTEM_FILEAPPENDER_HPP
