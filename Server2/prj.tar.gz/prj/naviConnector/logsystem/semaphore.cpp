#include "semaphore.h"

#include <boost/thread/mutex.hpp>
#include <boost/thread/condition.hpp>

class Semaphore::SemaphorePrivate
{
	public:

		inline SemaphorePrivate(int n) : avail(n) { }

		boost::mutex mutex;
		boost::condition_variable cond;

		int avail;
};

Semaphore::Semaphore(int n) : _impl(new Semaphore::SemaphorePrivate(n))
{
}

Semaphore::~Semaphore()
{
	delete _impl;
}


void Semaphore::acquire(int n)
{
	boost::mutex::scoped_lock locker(_impl->mutex);
	while (n > _impl->avail)
		_impl->cond.wait(locker);
	_impl->avail -= n;

}

bool Semaphore::tryAcquire(int n)
{
	boost::mutex::scoped_lock locker(_impl->mutex);
	if (n > _impl->avail)
		return false;
	_impl->avail -= n;
	return true;
}

bool Semaphore::tryAcquire(int n, int timeout)
{
	return false;
}

void Semaphore::release(int n)
{
	boost::mutex::scoped_lock locker(_impl->mutex);
	_impl->avail += n;
	_impl->cond.notify_all();
}

int Semaphore::available() const
{
	boost::mutex::scoped_lock locker(_impl->mutex);
	return _impl->avail;
}
