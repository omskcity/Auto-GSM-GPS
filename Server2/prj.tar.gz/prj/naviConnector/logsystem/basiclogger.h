#ifndef LOGSYSTEM_BASICLOGGER_H
#define LOGSYSTEM_BASICLOGGER_H

#include "ilogger.h"

namespace LoggingSystem {

class BasicLogger : public ILogger
{
	public:
		explicit BasicLogger(const std::string& name);
		~BasicLogger();

		virtual std::string name() const;

		virtual void debug(const std::string& message);
		virtual void info(const std::string& message);
		virtual void warn(const std::string& message);
		virtual void error(const std::string& message);
		virtual void fatal(const std::string& message);

		virtual bool addLogAppender(ILogAppenderPtr appender);
		virtual bool removeLogAppender(ILogAppenderPtr appender);
		virtual bool removeLogAppender(const std::string& appenderName);

	protected:
		virtual void log(LogEventConstPtr event);

	private:
		class BasicLoggerImpl;
		BasicLoggerImpl *_impl;
};

} // namespace LoggingSystem

#endif // LOGSYSTEM_BASICLOGGER_HPP
