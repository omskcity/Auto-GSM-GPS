/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmain.com.
**
****************************************************************************/

#include <boost/lexical_cast.hpp>

#include "common.h"

#include "request_parser.hpp"
#include "request.hpp"

RequestParser::RequestParser() : _state(length_start)
{
}

void RequestParser::reset()
{
	_state = length_start;
}

boost::tribool RequestParser::consume(Request& req, uint8_t input)
{
	switch (_state) {
		case length_start:
			req.data.clear();
			_dataIdx = 0;
			_dataLength = (uint16_t)input;
			_dataCRC[0] = 0;
			_dataCRC[1] = 0;
			_state = length_received;
			return boost::indeterminate;

		case length_received:
			_dataLength |= (((uint16_t)input) << 8) & 0x3f00;
			req.type = (input >> 6) & 0x03;
			if (req.data.capacity() > 4096) {
				std::vector<uint8_t>(req.data).swap(req.data);
				//req.data.swap(std::vector<uint8_t>());
				req.data.reserve(_dataLength);
			}
			else if (req.data.capacity() < _dataLength)
				req.data.reserve(_dataLength);
			if (_dataLength) {
				_state = data_receiving;
			}
			else {
				_state = read_crcL;
			}
			return boost::indeterminate;

		case data_receiving:
			req.data.push_back(input);
			++_dataIdx;
			if (_dataIdx >= _dataLength) {
				_state = read_crcL;
			}
			return boost::indeterminate;
		case read_crcL:
			_dataCRC[0] = input;
			_state = read_crcH;
			return boost::indeterminate;
		case read_crcH:
			_dataCRC[1] = input;
			req.crc = *((uint16_t*)(&_dataCRC[0]));
			return true;
		default:
			return false;
	}
}

bool RequestParser::checkCRC(Request& req, uint16_t crc)
{
	std::vector<uint8_t> data(req.data.size() + 2);

	data[0] = (uint8_t)(req.data.size() & 0xFF);
	data[1] = (uint8_t)((req.data.size() >> 8) & 0xFF);
	data[1] |= (req.type << 6) & 0xc0;
	std::copy (req.data.begin(), req.data.end(), data.begin() + 2);
	uint16_t crc_ = calcCRC(data);
	return crc == crc_;
}
