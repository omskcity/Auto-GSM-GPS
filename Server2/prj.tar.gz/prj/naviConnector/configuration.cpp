/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#include "configuration.hpp"

#include <fstream>
#include <boost/program_options.hpp>
namespace po = boost::program_options;

Configuration::Configuration(const std::string& config_path)
{
	po::options_description config("Configuration");
	config.add_options()("Server", po::value<std::string>(&this->_serverAddress)->default_value("0.0.0.0"), "server listener")
		("Port", po::value<std::string>(&this->_serverPort)->default_value("10000"), "server listener port")
		("ThreadPoolSize", po::value<int>(&this->_servicesPollSize)->default_value(4), "io_services pool size")
		("ActiveMQBrokerURI", po::value<std::string>(&this->_activeMQBrokerURI)->default_value("failover:(tcp://127.0.0.1:61618)"), "ActiveMQ broker URI")
		("ActiveMQProducerURI", po::value<std::string>(&this->_activeMQProducerURI)->default_value("navisetGT20d_d_service"), "ActiveMQ producer URI")
		("ActiveMQConsumerURI", po::value<std::string>(&this->_activeMQConsumerURI)->default_value("coonector_service"), "ActiveMQ consumer URI")
		("LogFileName", po::value<std::string>(&this->_logFileName)->default_value("logfile.log"), "Log file name");

	po::options_description config_file_options;
	config_file_options.add(config);

	po::variables_map vm;

	std::ifstream ifs(config_path.c_str());
	if (ifs)
	{
		store(parse_config_file(ifs, config_file_options), vm);
		notify(vm);
	}
}
