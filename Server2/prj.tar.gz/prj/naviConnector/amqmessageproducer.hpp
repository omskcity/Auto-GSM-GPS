/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#ifndef NAVI_SERVER_AMQMESSAGEPRODUCER_HPP
#define NAVI_SERVER_AMQMESSAGEPRODUCER_HPP

#include <list>
#include <string>
#include <vector>
#include <decaf/lang/Thread.h>

namespace decaf {
namespace util {
namespace concurrent {
class Mutex;
class Semaphore;
}
}
}

namespace activemq {
namespace core {
class ActiveMQConnectionFactory;
}
}

namespace cms {
class Connection;
class Destination;
class Message;
class MessageProducer;
class Session;
}

class AMQMessageProducer : public decaf::lang::Thread
{
	public:
		AMQMessageProducer(activemq::core::ActiveMQConnectionFactory* connectionFactory,
			const std::string& destURI);
		~AMQMessageProducer();

		void addMessage(const cms::Message* message);
		cms::Message* createMapMessage() const;

		void handlePacketReceived(int type, long socket, const std::vector<unsigned char>& data);
		void handleSocketConnected(long socket);
		void handleSocketDisconnected(long socket);

		void close();

	private:
		void cleanup();
		void run();

		bool _isRunning;
		activemq::core::ActiveMQConnectionFactory *_connectionFactory;
		std::string _destinationURI;

		cms::Connection *_connection;
		cms::Session *_session;
		cms::Destination *_destination;
		cms::MessageProducer *_producer;

		std::list<cms::Message*> _messageQueue;
		decaf::util::concurrent::Mutex *_queueLocker;
		decaf::util::concurrent::Semaphore *_queueSyncer;
};

#endif // NAVI_SERVER_AMQMESSAGEPRODUCER_HPP
