/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#ifndef LOGSYSTEM_ILOGAPPENDER_HPP
#define LOGSYSTEM_ILOGAPPENDER_HPP

#include <string>

namespace LoggingSystem {

class LogEvent;

class ILogAppender
{
	public:
		ILogAppender() { }
		virtual ~ILogAppender() { }

		virtual void close() = 0;
		virtual void doAppend(const LogEvent& event) = 0;

	protected:
		virtual std::string renderEvent(const LogEvent& event) = 0;
};

} // namespace LoggingSystem

#endif // LOGSYSTEM_ILOGAPPENDER_HPP
