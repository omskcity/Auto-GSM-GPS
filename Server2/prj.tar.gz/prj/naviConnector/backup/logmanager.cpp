/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#include "logmanager.hpp"
#include "filelogger.hpp"
#include <map>

#include <boost/thread.hpp>
#include <boost/interprocess/sync/scoped_lock.hpp>

#include "boost/date_time/gregorian/gregorian.hpp"
#include "boost/date_time/posix_time/posix_time.hpp"
#include <boost/format.hpp>

namespace LoggingSystem {

LogManager* LogManager::_instance = 0;

class LogManager::LogManagerImpl
{
	public:
		LogManagerImpl();
		~LogManagerImpl();

		ILogger* GetLogger(const std::string& loggerId);

		typedef std::map<std::string, ILogger*> LoggersMap;
		LoggersMap _loggersMap;
		boost::mutex _loggersMapLocker;
};

LogManager::LogManagerImpl::LogManagerImpl()
	: _loggersMap(), _loggersMapLocker()
{
	boost::posix_time::ptime now = boost::posix_time::microsec_clock::local_time();
	boost::gregorian::date today = now.date();
	boost::posix_time::time_duration t = now.time_of_day();

	std::string fName = str(boost::format("system_%1%%2%%3%%4%%5%%6%.log") % today.year() % (int)today.month() % today.day() % t.hours() % t.minutes() % t.seconds());
	_loggersMap["system"] = new FileLogger(fName);
}

LogManager::LogManagerImpl::~LogManagerImpl()
{
	boost::interprocess::scoped_lock<boost::mutex> locker(_loggersMapLocker);

	for (LoggersMap::iterator it = _loggersMap.begin(); it != _loggersMap.end(); ++it) {
		delete it->second;
	}
	_loggersMap.clear();
}


ILogger* LogManager::LogManagerImpl::GetLogger(const std::string& loggerId)
{
	boost::interprocess::scoped_lock<boost::mutex> locker(_loggersMapLocker);

	LoggersMap::iterator it = _loggersMap.find(loggerId);
	if (it != _loggersMap.end())
		return it->second;

	return NULL;
}


LogManager::LogManager() : _impl(new LogManagerImpl())
{
	_instance = this;
}

LogManager::~LogManager()
{
	delete _impl;
	_instance = 0;
}

LogManager *LogManager::instance()
{
	return _instance;
}

ILogger *LogManager::GetLogger(const std::string& loggerId)
{
	_impl->GetLogger(loggerId);
}

} // namespace LoggingSystem
