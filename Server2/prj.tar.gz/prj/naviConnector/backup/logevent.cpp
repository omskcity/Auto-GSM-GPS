/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#include "logevent.hpp"
#include "logmessage.hpp"
#include "logginglevels.h"

#include <string>
#include <sstream>

#include <boost/date_time/gregorian/gregorian.hpp>
#include <boost/uuid/uuid_generators.hpp>
#include <boost/uuid/uuid_io.hpp>

#include <boost/thread.hpp>

namespace LoggingSystem {

class LogEvent::LogEventImpl
{
	public:
		LogEventImpl(const LogMessage& message, LoggingLevels level);

		LogMessage _msg;
		LoggingLevels _level;
		std::string _threadId;
		std::string _uuid;

		boost::posix_time::ptime _timeStamp;
};

LogEvent::LogEventImpl::LogEventImpl(const LogMessage& message, LoggingLevels level)
	: _msg(message), _level(level), _threadId(),
	_uuid(), _timeStamp(boost::posix_time::microsec_clock::local_time())
{
	std::stringstream ss;
	ss << boost::this_thread::get_id();
	_threadId = ss.str();

	boost::uuids::basic_random_generator<boost::mt19937> uuidGen;
	boost::uuids::uuid uid = uuidGen();
	std::string s = boost::lexical_cast<std::string>(uid);
	//_uuid = std::to_string(uid);
	boost::to_upper(_uuid);
}

LogEvent::LogEvent()
	: _impl(new LogEvent::LogEventImpl(LogMessage(), LoggingSystem::DEBUG))
{
}

LogEvent::LogEvent(const LogMessage& message, LoggingSystem::LoggingLevels level)
	: _impl(new LogEvent::LogEventImpl(message, level))
{
}

LogEvent::LogEvent(const LogEvent &other)
	: _impl(new LogEvent::LogEventImpl(other._impl->_msg, other._impl->_level))
{
	//_impl->_msg = other._impl->_msg;
	//_impl->_level = other._impl->_level;
	_impl->_timeStamp = other._impl->_timeStamp;
	_impl->_threadId = other._impl->_threadId;
	_impl->_uuid = other._impl->_uuid;
}

LogEvent::~LogEvent()
{
	delete _impl;
}

LogMessage LogEvent::message() const
{
	return _impl->_msg;
}

LoggingLevels LogEvent::level() const
{
	return _impl->_level;
}

boost::posix_time::ptime LogEvent::timeStamp() const
{
	return _impl->_timeStamp;
}

std::string LogEvent::threadId() const
{
	return _impl->_threadId;
}

LogEvent &LogEvent::operator =(const LogEvent &other)
{
	_impl->_msg = other._impl->_msg;
	_impl->_level = other._impl->_level;
	_impl->_timeStamp = other._impl->_timeStamp;
	_impl->_threadId = other._impl->_threadId;
	_impl->_uuid = other._impl->_uuid;

	return *this;
}

} // namespace LoggingSystem
