/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#ifndef LOGSYSTEM_ILOGGER_HPP
#define LOGSYSTEM_ILOGGER_HPP

#include <boost/shared_ptr.hpp>
#include "ilogappender.hpp"

namespace LoggingSystem {

class LogEvent;
class LogMessage;

typedef boost::shared_ptr<ILogAppender> ILogAppenderPtr;

class ILogger
{
	public:
		ILogger() { }
		virtual ~ILogger() { }

		virtual void debug(const LogMessage& message) = 0;
		virtual void info(const LogMessage& message) = 0;
		virtual void warn(const LogMessage& message) = 0;
		virtual void error(const LogMessage& message) = 0;
		virtual void fatal(const LogMessage& message) = 0;

		virtual void setLogAppender(ILogAppenderPtr appender) = 0;

	protected:
		virtual void log(const LogEvent& event) = 0;
};

} // namespace LoggingSystem

#endif // LOGSYSTEM_ILOGGER_HPP
