/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#ifndef LOGSYSTEM_LOGEVENT_HPP
#define LOGSYSTEM_LOGEVENT_HPP

#include <boost/date_time/posix_time/posix_time.hpp>

#include "logginglevels.h"

namespace LoggingSystem {

class LogMessage;

class LogEvent
{
	public:
		LogEvent();
		explicit LogEvent(const LogMessage& message,
			LoggingSystem::LoggingLevels level = LoggingSystem::DEBUG);
		LogEvent(const LogEvent& other);
		~LogEvent();

		LogMessage message() const;
		LoggingLevels level() const;
		boost::posix_time::ptime timeStamp() const;
		std::string threadId() const;

		LogEvent& operator=(const LogEvent& other);

	private:
		class LogEventImpl;
		LogEventImpl *_impl;
};

} // namespace LoggingSystem

#endif // LOGSYSTEM_LOGEVENT_HPP
