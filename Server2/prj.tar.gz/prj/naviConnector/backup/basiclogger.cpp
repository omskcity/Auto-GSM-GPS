/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#include "basiclogger.hpp"
#include "logginglevels.h"
#include "logevent.hpp"
#include "ilogappender.hpp"

#include <iostream>
#include <list>

namespace LoggingSystem {

BasicLogger::BasicLogger() : _appender()
{
}

void BasicLogger::debug(const LogMessage& message)
{
	log(LogEvent(message, LoggingSystem::DEBUG));
}

void BasicLogger::info(const LogMessage& message)
{
	log(LogEvent(message, LoggingSystem::INFO));
}

void BasicLogger::warn(const LogMessage& message)
{
	log(LogEvent(message, LoggingSystem::WARN));
}

void BasicLogger::error(const LogMessage& message)
{
	log(LogEvent(message, LoggingSystem::ERROR));
}

void BasicLogger::fatal(const LogMessage& message)
{
	log(LogEvent(message, LoggingSystem::FATAL));
}

void BasicLogger::setLogAppender(ILogAppenderPtr appender)
{
	_appender = appender;
}

void BasicLogger::log(const LogEvent& event)
{
	if (_appender != 0)
		_appender->doAppend(event);
}


} // namespace LoggingSystem
