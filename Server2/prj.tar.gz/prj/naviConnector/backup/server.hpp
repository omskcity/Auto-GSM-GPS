/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmain.com.
**
****************************************************************************/

#ifndef NAVI_SERVER
#define NAVI_SERVER

#include <string>
#include <vector>

#include <boost/asio.hpp>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>

#include "connection.hpp"
#include "io_service_pool.hpp"
#include "request_handler.hpp"

/// The top-level class of the server.
class NAVIServer : private boost::noncopyable
{
	public:
		explicit NAVIServer(const std::string& address, const std::string& port,
			std::size_t io_service_pool_size, const std::string& logsTo);

		/// Run the server's io_service loop.
		void run();
		/// Handle a request to stop the server.
		void finish();

	private:
		/// Initiate an asynchronous accept operation.
		void start_accept();

		/// Handle completion of an asynchronous accept operation.
		void handle_accept(const boost::system::error_code& e);

		/// The pool of io_service objects used to perform asynchronous operations.
		IOServicePool io_service_pool_;

		/// The signal_set is used to register for process termination notifications.
		boost::asio::signal_set signals_;

		/// Acceptor used to listen for incoming connections.
		boost::asio::ip::tcp::acceptor acceptor_;

		/// The next connection to be accepted.
		ConnectionPtr new_connection_;

		/// The handler for all incoming requests.
		RequestHandler request_handler_;
};


#endif // NAVI_SERVER
