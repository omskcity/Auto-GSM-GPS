/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmain.com.
**
****************************************************************************/

#include <iostream>
#include <string>

#include <boost/lexical_cast.hpp>
#include <boost/shared_ptr.hpp>

#include <boost/asio.hpp>
#include <boost/bind.hpp>

#include "defs.h"
#include "logmanager.hpp"
#include "ilogger.hpp"
#include "logmessage.hpp"
#include "activemqgate.hpp"
#include "server.hpp"

const char * const strAbout = "NAVI Server version 0.1";
const char * const strUsage = "Usage: naviServer <address> <port> <threads>";

void Usage()
{
	Console() << strAbout << EndLine;
	Console() << strUsage << EndLine;
}

int main(int argc, char* argv[])
{
	boost::shared_ptr<LoggingSystem::LogManager> logManager(new LoggingSystem::LogManager());

	// Check command line arguments.
	if (argc < 4) {
		Usage();
		return 1;
	}

	std::string logPath = ".";
	if (argc >= 5) {
		logPath = argv[4];
	}

	std::string brokerIp = "127.0.0.1";
	std::string brokerPort = "61618"; //61616
	if (argc >= 6) {
		brokerIp = argv[5];
	}
	if (argc >= 7) {
		brokerPort = argv[6];
	}
	std::string brokerURI = "failover:(tcp://" + brokerIp + ":" + brokerPort + ")";

	// Initialise the server.
	ActiveMQGate::initialize();

	// This is the Destination Name and URI options.
	std::string producerDestURI = "device_service";
	std::string consumerDestURI = "coonector_service";

	LoggingSystem::LogManager::instance()->GetLogger("system")->debug("brokerURI: " + brokerURI);

	ActiveMQGate *amqGate = NULL;
	try {
		amqGate = new ActiveMQGate(brokerURI, producerDestURI, consumerDestURI);
		amqGate->run();
	}
	catch (std::exception& e) {
		LoggingSystem::LogManager::instance()->GetLogger("system")->fatal("Exception: " + std::string(e.what()));
		ActiveMQGate::shutdown();
		return -1;
	}

	NAVIServer *naviServer = NULL;
	try {

		std::size_t num_threads = boost::lexical_cast<std::size_t>(argv[3]);
		naviServer = new NAVIServer(argv[1], argv[2], num_threads, logPath);

		// Run the server until stopped.
		naviServer->run();
	}
	catch (std::exception& e) {
		LoggingSystem::LogManager::instance()->GetLogger("system")->fatal("Exception: " + std::string(e.what()));
	}

	// Wait to exit.
	Console() << "Press 's' to stop server and quit" << EndLine;
	while( std::cin.get() != 's') {}

	if (naviServer) {
		naviServer->finish();
		delete naviServer;
	}

	if (amqGate) {
		amqGate->finish();
		delete amqGate;
	}

	ActiveMQGate::shutdown();

	return 0;
}
