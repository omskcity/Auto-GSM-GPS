/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmain.com.
**
****************************************************************************/

#ifndef NAVI_SERVER_REQUEST_HANDLER
#define NAVI_SERVER_REQUEST_HANDLER

#include <string>
#include <boost/noncopyable.hpp>
#include <boost/asio.hpp>

//#include <boost/log/sources/logger.hpp>

struct Request;
struct Reply;

/// The common handler for all incoming requests.
class RequestHandler : private boost::noncopyable
{
	public:
		/// Construct with a directory containing files to be served.
		explicit RequestHandler(const std::string& logs_path);
		~RequestHandler();

		/// Handle a request and produce a reply.
		void handleRequest(const Request& req, Reply& rep,
			boost::asio::ip::tcp::socket& socket);
		void handleCloseConnection(boost::asio::ip::tcp::socket& socket);

	private:
		/// The directory containing the files to be served.
		std::string _logs_path;
		//boost::log::sources::logger_mt _logger;
};

#endif // NAVI_SERVER_REQUEST_HANDLER
