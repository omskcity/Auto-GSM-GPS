/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#ifndef LOGSYSTEM_FILELOGGER_HPP
#define LOGSYSTEM_FILELOGGER_HPP

#include <string>
#include "basiclogger.hpp"

namespace LoggingSystem {

class FileLogger : public BasicLogger
{
	public:
		FileLogger(const std::string& fileName);
};

} // namespace LoggingSystem

#endif // LOGSYSTEM_FILELOGGER_HPP
