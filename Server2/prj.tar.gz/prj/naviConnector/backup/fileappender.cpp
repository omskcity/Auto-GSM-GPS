/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#include "fileappender.hpp"
#include "logevent.hpp"
#include "logmessage.hpp"

#include <fstream>

#include <boost/format.hpp>
#include <boost/thread.hpp>
#include <boost/interprocess/sync/scoped_lock.hpp>
#include <boost/interprocess/sync/interprocess_semaphore.hpp>

namespace LoggingSystem {

class FileAppender::FileAppenderImpl
{
	public:
		FileAppenderImpl();
		FileAppenderImpl(const std::string& fileName);
		~FileAppenderImpl();

		void close();
		void doAppend(const LogEvent& event);
		std::string renderEvent(const LogEvent& event);

		std::string _fileName;
		std::ofstream _stream;

		struct Worker {
			Worker(FileAppender::FileAppenderImpl* owner) : _owner(owner) { }
			void operator()();
			FileAppender::FileAppenderImpl *_owner;
		};

		Worker _worker;

		bool _isRunning;
		boost::interprocess::interprocess_semaphore _sem;
		boost::mutex _logQueueLocker;
		std::list<LogEvent> _logQueue;

		boost::thread _thread;
};

void FileAppender::FileAppenderImpl::Worker::operator ()()
{
	LogEvent evt;
	bool hasEvent = false;

	while (_owner->_isRunning) {
		_owner->_sem.wait();
		_owner->_logQueueLocker.lock();
		hasEvent = !_owner->_logQueue.empty();
		if (hasEvent) {
			evt = _owner->_logQueue.front();
			_owner->_logQueue.pop_front();
		}
		_owner->_logQueueLocker.unlock();
		if (hasEvent) {
			_owner->_stream << _owner->renderEvent(evt);
		}
	}
	_owner->_logQueueLocker.lock();
	while (!_owner->_logQueue.empty()) {
		evt = _owner->_logQueue.front();
		_owner->_logQueue.pop_front();
		_owner->_stream << _owner->renderEvent(evt);
	}
	_owner->_logQueueLocker.unlock();
}

FileAppender::FileAppenderImpl::FileAppenderImpl()
	: _fileName(), _stream(), _worker(this), _isRunning(true), _sem(0),
	_logQueueLocker(), _logQueue(), _thread(_worker)
{
	_fileName = "journal.log";
	_stream.open(_fileName.c_str(), std::fstream::out | std::fstream::trunc);
}

FileAppender::FileAppenderImpl::FileAppenderImpl(const std::string& fileName)
	: _fileName(fileName), _stream(fileName.c_str(), std::fstream::out | std::fstream::trunc),
	_worker(this), _isRunning(true), _sem(0), _logQueueLocker(), _logQueue(),
	_thread(_worker)
{
}

FileAppender::FileAppenderImpl::~FileAppenderImpl()
{
	close();
}

void FileAppender::FileAppenderImpl::close()
{
	_isRunning = false;
	_sem.post();
	_thread.join();

	_stream.flush();
	_stream.close();
}

void FileAppender::FileAppenderImpl::doAppend(const LogEvent& event)
{
	boost::interprocess::scoped_lock<boost::mutex> locker(_logQueueLocker);
	_logQueue.push_back(event);
	_sem.post();
}

std::string FileAppender::FileAppenderImpl::renderEvent(const LogEvent& event)
{
	boost::gregorian::date d = event.timeStamp().date();
	boost::posix_time::time_duration t = event.timeStamp().time_of_day();
	std::string result = str(boost::format("<< %1%.%2%.%3% %4%:%5%:%6%.%7% @ ") % d.year() % (int)d.month() % d.day() % t.hours() % t.minutes() % t.seconds() % t.ticks());

	switch (event.level()) {
		case INFO:
			result.append("Info");
			break;
		case WARN:
			result.append("Warning");
			break;
		case ERROR:
			result.append("Error");
			break;
		case FATAL:
			result.append("Fatal");
			break;
		default:
			result.append("Debug");
			break;
	}

	result.append(" @ ");
	result.append(event.threadId());
	result.append(" >> : ");
	result.append(event.message().rawString());
	result.append("\n");

	return result;
}


FileAppender::FileAppender() : _impl(new FileAppenderImpl())
{
}

FileAppender::FileAppender(const std::string& fileName)
	: _impl(new FileAppenderImpl(fileName))
{
}

FileAppender::~FileAppender()
{
	delete _impl;
}

void FileAppender::close()
{
	_impl->close();
}

void FileAppender::doAppend(const LogEvent& event)
{
	_impl->doAppend(event);
}

std::string FileAppender::renderEvent(const LogEvent& event)
{
	_impl->renderEvent(event);
}


} // namespace LoggingSystem
