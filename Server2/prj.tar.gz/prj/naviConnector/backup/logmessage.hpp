/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#ifndef LOGSYSTEM_LOGMESSAGE_HPP
#define LOGSYSTEM_LOGMESSAGE_HPP

#include <string>

namespace LoggingSystem {

class LogEvent;

class LogMessage
{
	public:
		LogMessage() : _msg() { }
		LogMessage(const char* msg) : _msg(msg) { }
		LogMessage(const std::string& msg) : _msg(msg) { }

		std::string rawString() const { return _msg; }

	private:
		std::string _msg;
		friend class LogEvent;
};

} // namespace LoggingSystem

#endif // LOGSYSTEM_LOGMESSAGE_HPP
