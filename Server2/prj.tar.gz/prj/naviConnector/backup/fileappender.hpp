/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#ifndef LOGSYSTEM_FILEAPPENDER_HPP
#define LOGSYSTEM_FILEAPPENDER_HPP

#include <string>

#include "ilogappender.hpp"

namespace LoggingSystem {

class FileAppender : ILogAppender
{
	public:
		FileAppender();
		FileAppender(const std::string& fileName);
		~FileAppender();

		void close();
		void doAppend(const LogEvent& event);

	protected:
		std::string renderEvent(const LogEvent& event);

	private:
		class FileAppenderImpl;
		FileAppenderImpl *_impl;
};

} // namespace LoggingSystem

#endif // LOGSYSTEM_FILEAPPENDER_HPP
