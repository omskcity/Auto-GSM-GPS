/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#ifndef LOGSYSTEM_BASICLOGGER_HPP
#define LOGSYSTEM_BASICLOGGER_HPP

#include "ilogger.hpp"

namespace LoggingSystem {

class BasicLogger : public ILogger
{
	public:
		BasicLogger();

		virtual void debug(const LogMessage& message);
		virtual void info(const LogMessage& message);
		virtual void warn(const LogMessage& message);
		virtual void error(const LogMessage& message);
		virtual void fatal(const LogMessage& message);

		virtual void setLogAppender(ILogAppenderPtr appender);

	protected:
		virtual void log(const LogEvent& event);

	private:
		ILogAppenderPtr _appender;
};

} // namespace LoggingSystem

#endif // LOGSYSTEM_BASICLOGGER_HPP
