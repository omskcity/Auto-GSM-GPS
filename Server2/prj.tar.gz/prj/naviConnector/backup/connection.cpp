/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmain.com.
**
****************************************************************************/

#include "logmanager.hpp"
#include "ilogger.hpp"
#include "logmessage.hpp"

#include <vector>
#include <boost/bind.hpp>
#include <boost/format.hpp>

#include "connection.hpp"
#include "request_handler.hpp"

Connection::Connection(boost::asio::io_service& io_service,
	RequestHandler& handler) : _socket(io_service), _requestHandler(handler)
{
}

Connection::~Connection()
{
	std::string result = str(boost::format("Connection::~Connection() | DESTROY _socket: %1%") % _socket.native_handle());
	LoggingSystem::LogManager::instance()->GetLogger("system")->debug(result);
}

boost::asio::ip::tcp::socket& Connection::socket()
{
	return _socket;
}

void Connection::start()
{
	_socket.async_read_some(boost::asio::buffer(_buffer),
		boost::bind(&Connection::handleRead, shared_from_this(),
		boost::asio::placeholders::error,
		boost::asio::placeholders::bytes_transferred));

	std::string result = str(boost::format("Connection::start() _socket: %1%") % _socket.native_handle());
	LoggingSystem::LogManager::instance()->GetLogger("system")->debug(result);

}

void Connection::retransPacket(Reply& reply)
{
	boost::asio::write(_socket, reply.to_buffers());
	LoggingSystem::LogManager::instance()->GetLogger("system")->debug("Connection::retransPacket() | Packet retranslated !");
}

void Connection::handleRead(const boost::system::error_code& e,
	std::size_t bytes_transferred)
{
	if (!e) {
		boost::tribool result;
		boost::tie(result, boost::tuples::ignore) = _requestParser.parse(_request,
			_buffer.data(), _buffer.data() + bytes_transferred);

		if (result) {
			_requestHandler.handleRequest(_request, _reply, _socket);
			boost::asio::async_write(_socket, _reply.to_buffers(),
				boost::bind(&Connection::handleWrite, shared_from_this(),
				boost::asio::placeholders::error));
		}
		else if (!result) {
			_reply = Reply::stock_reply(Reply::bad_request);
			boost::asio::async_write(_socket, _reply.to_buffers(),
				boost::bind(&Connection::handleWrite, shared_from_this(),
				boost::asio::placeholders::error));
		}
		else {
			_socket.async_read_some(boost::asio::buffer(_buffer),
				boost::bind(&Connection::handleRead, shared_from_this(),
				boost::asio::placeholders::error,
				boost::asio::placeholders::bytes_transferred));
		}
	}
}

void Connection::handleWrite(const boost::system::error_code& e)
{
	if (!e) {
		// Initiate graceful connection closure.
		boost::system::error_code ignored_ec;
		if (_reply.isCloseAfterSend) {
			_socket.shutdown(boost::asio::ip::tcp::socket::shutdown_both, ignored_ec);
		}
		else {
			LoggingSystem::LogManager::instance()->GetLogger("system")->info("Connection::handleWrite | Reset to wait new data");
			_requestParser.reset();
			_socket.async_read_some(boost::asio::buffer(_buffer),
				boost::bind(&Connection::handleRead, shared_from_this(),
				boost::asio::placeholders::error,
				boost::asio::placeholders::bytes_transferred));
		}
	}
	else {
		LoggingSystem::LogManager::instance()->GetLogger("system")->error("Connection::handleWrite e:" + e.message());
	}
}

void Connection::handleWrite2(const boost::system::error_code& e)
{
	LoggingSystem::LogManager::instance()->GetLogger("system")->debug("Connection::handleWrite2() | Packet retranslated !");
}
