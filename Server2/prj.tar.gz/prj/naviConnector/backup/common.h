/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmain.com.
**
****************************************************************************/

#ifndef COMMON_H
#define COMMON_H

#include <stdint.h>
#include <vector>

const char * const strErrNotEnoughMemory = "Not enough memory for allocation of buffer";
const char * const strIllegalSize = "Illigal file size had been set: ";
const char * const strFileNameEmpty = "Name of file for sorting is empty";

// ERRORS
namespace Errors
{
	enum ErrorConstants {
		SUCCESS = 0, ERR_ILLEGAL_SIZE, ERR_NOT_ENOUGH_MEMORY,
		ERR_FILE_DOES_NOT_EXIST, ERR_FILE_NAME_EMPTY
	};
}

uint16_t calcCRC(const std::vector<uint8_t> & data);

#endif // COMMON_H
