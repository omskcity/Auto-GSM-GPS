/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmain.com.
**
****************************************************************************/

#include "request_handler.hpp"
#include "reply.hpp"
#include "request.hpp"
#include "activemqgate.hpp"
#include "amqmessageproducer.hpp"

#include "common.h"

#include <fstream>
#include <sstream>
#include <string>
#include "boost/date_time/gregorian/gregorian.hpp"
#include "boost/date_time/posix_time/posix_time.hpp"
//#include <boost/lexical_cast.hpp>
#include <boost/format.hpp>

#include <cms/MapMessage.h>

RequestHandler::RequestHandler(const std::string& logs_path)
  : _logs_path(logs_path)
{
/*
	boost::log::add_file_log(
			boost::log::keywords::file_name = "file_%Y-%m-%d_%H-%M-%S.%N.log",
			boost::log::keywords::format = "[%TimeStamp%]: %_%"
	);
*/
}

RequestHandler::~RequestHandler()
{
}

void RequestHandler::handleRequest(const Request& req, Reply& rep,
	boost::asio::ip::tcp::socket& socket)
{
	/*
	boost::posix_time::ptime now = boost::posix_time::microsec_clock::local_time();
	boost::gregorian::date today = now.date();
	boost::posix_time::time_duration t = now.time_of_day();
	std::string fName = _logs_path + str(boost::format("request_%1%%2%%3%%4%%5%%6%%7%.log") % today.year() % (int)today.month() % today.day() % t.hours() % t.minutes() % t.seconds() % t.ticks());
	std::ofstream out(fName.c_str(), std::ofstream::trunc);
	out << req.toString();
	out.close();
	*/

	rep = Reply::stock_reply(Reply::bad_request);
	rep.data.push_back(0x01);
	//uint16_t crc = calcCRC(rep.data);
	rep.data.push_back((uint8_t)(req.crc & 0xff));
	rep.data.push_back((uint8_t)((req.crc >> 8) & 0xff));

	cms::MapMessage *msg = static_cast<cms::MapMessage*>(ActiveMQGate::instance()->messageProducer()->createMapMessage());
	msg->setInt("type", req.type);
	msg->setBytes("data", req.data);
	msg->setInt("socket_id", (unsigned int)socket.native_handle());
	ActiveMQGate::instance()->messageProducer()->addMessage(msg);
	delete msg;

}

void RequestHandler::handleCloseConnection(boost::asio::ip::tcp::socket& socket)
{
	cms::MapMessage *msg = static_cast<cms::MapMessage*>(ActiveMQGate::instance()->messageProducer()->createMapMessage());
	msg->setString("event", "DISCONNECT");
	msg->setInt("socket_id", (unsigned int)socket.native_handle());
	ActiveMQGate::instance()->messageProducer()->addMessage(msg);
	delete msg;
}
