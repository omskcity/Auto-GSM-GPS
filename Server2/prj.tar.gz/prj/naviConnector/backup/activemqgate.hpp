/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmain.com.
**
****************************************************************************/

#ifndef NAVI_SERVER_ACTIVEMQ_GATE_HPP
#define NAVI_SERVER_ACTIVEMQ_GATE_HPP

#include <string>

namespace activemq {
namespace core {
class ActiveMQConnectionFactory;
}
}

class AMQMessageProducer;
class AMQMessageConsumer;

class ActiveMQGate
{
	public:
		ActiveMQGate(const std::string& brokerURI,
			const std::string& producerDestURI, const std::string& consumerDestURI);
		~ActiveMQGate();

		static ActiveMQGate* instance();

		void run();
		void finish();

		static void initialize();
		static void shutdown();

		inline AMQMessageProducer* messageProducer() const { return _producer; }
		inline AMQMessageConsumer* messageConsumer() const { return _consumer; }

	private:
		activemq::core::ActiveMQConnectionFactory *_connectionFactoryP;
		//activemq::core::ActiveMQConnectionFactory *_connectionFactoryC;
		AMQMessageConsumer *_consumer;
		AMQMessageProducer *_producer;

		static ActiveMQGate* _instance;
};

#endif // NAVI_SERVER_ACTIVEMQ_GATE_HPP
