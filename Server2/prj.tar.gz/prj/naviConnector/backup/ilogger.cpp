#include "ilogger.hpp"

ILogger::ILogger()
{
}
