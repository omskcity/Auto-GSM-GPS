/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmain.com.
**
****************************************************************************/

//#include "defs.h"
#include "logmanager.h"
#include "ilogger.h"

#include "server.hpp"

#include <boost/bind.hpp>

NAVIServer::NAVIServer(const std::string& address, const std::string& port,
	std::size_t io_service_pool_size)
		: _io_service_pool(io_service_pool_size),
		_signals(_io_service_pool.get_io_service()),
		_acceptor(_io_service_pool.get_io_service()),
		new_connection_(),
		_request_handler(".")
{
	// Register to handle the signals that indicate when the server should exit.
	// It is safe to register for the same signal multiple times in a program,
	// provided all registration for the specified signal is made through Asio.
	_signals.add(SIGINT);
	_signals.add(SIGTERM);
#if defined(SIGQUIT)
	_signals.add(SIGQUIT);
#endif // defined(SIGQUIT)
	_signals.async_wait(boost::bind(&NAVIServer::finish, this));

	// Open the acceptor with the option to reuse the address (i.e. SO_REUSEADDR).
	boost::asio::ip::tcp::resolver resolver(_acceptor.get_io_service());
	boost::asio::ip::tcp::resolver::query query(address, port);
	boost::asio::ip::tcp::endpoint endpoint = *resolver.resolve(query);
	_acceptor.open(endpoint.protocol());
	_acceptor.set_option(boost::asio::ip::tcp::acceptor::reuse_address(true));
	_acceptor.bind(endpoint);
	_acceptor.listen();

	start_accept();
}

void NAVIServer::run()
{
	_io_service_pool.run();
}

void NAVIServer::start_accept()
{
	new_connection_.reset(new Connection(
		_io_service_pool.get_io_service(), _request_handler));
	_acceptor.async_accept(new_connection_->socket(),
		boost::bind(&NAVIServer::handle_accept, this,
		boost::asio::placeholders::error));
}

void NAVIServer::handle_accept(const boost::system::error_code& e)
{
	if (!e) {
		new_connection_->start();
	}

	start_accept();
}

void NAVIServer::finish()
{
	_io_service_pool.stop();
	LoggingSystem::LogManager::instance()->getLogger("system")->debug("NAVIServer::finish()");
}
