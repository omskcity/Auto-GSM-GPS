/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmain.com.
**
****************************************************************************/

#include "reply.hpp"
#include "common.h"

#include <string>
#include <boost/lexical_cast.hpp>

std::vector<boost::asio::const_buffer> Reply::to_buffers()
{
	std::vector<boost::asio::const_buffer> buffers;
	buffers.push_back(boost::asio::buffer(data));

	return buffers;

}

Reply Reply::stock_reply(Reply::status_type status)
{
	Reply rep;
	rep.status = status;
	rep.isCloseAfterSend = false;
	return rep;
}
