/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#ifndef NAVI_SERVER_CONFIGURATION_HPP
#define NAVI_SERVER_CONFIGURATION_HPP

#include <string>

class Configuration
{
	public:
		Configuration(const std::string& config_path);

		inline std::string address() const { return _serverAddress; }
		inline std::string port() const { return _serverPort; }
		inline int servicesPollSize() const { return _servicesPollSize; }
		inline std::string activeMQBrokerURI() const { return _activeMQBrokerURI; }
		inline std::string activeMQProducerURI() const { return _activeMQProducerURI; }
		inline std::string activeMQConsumerURI() const { return _activeMQConsumerURI; }

		inline std::string logFileName() const { return _logFileName; }

	private:
		std::string _serverAddress;
		std::string _serverPort;
		int _servicesPollSize;
		std::string _activeMQBrokerURI;
		std::string _activeMQProducerURI;
		std::string _activeMQConsumerURI;

		std::string _logFileName;
};

#endif // NAVI_SERVER_CONFIGURATION_HPP
