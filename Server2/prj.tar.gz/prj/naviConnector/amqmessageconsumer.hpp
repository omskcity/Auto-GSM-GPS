/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#ifndef NAVI_SERVER_AMQMESSAGECONSUMER_HPP
#define NAVI_SERVER_AMQMESSAGECONSUMER_HPP

#include <map>

#include <decaf/lang/Thread.h>
#include <decaf/lang/Runnable.h>
#include <activemq/transport/DefaultTransportListener.h>
#include <cms/ExceptionListener.h>
#include <cms/MessageListener.h>

namespace decaf {
namespace util {
namespace concurrent {
class Mutex;
class Semaphore;
}
}
}

namespace cms {
//class CMSException;
class Connection;
class Destination;
//class Message;
class MessageConsumer;
class Session;
}

namespace activemq {
namespace core {
class ActiveMQConnectionFactory;
}
}

class Connection;

class AMQMessageConsumer : public cms::ExceptionListener, public cms::MessageListener,
	public activemq::transport::DefaultTransportListener
{
	public:
		AMQMessageConsumer(const std::string& brokerURI, const std::string& destURI);
		virtual ~AMQMessageConsumer();

		void startWait();
		void close();

		virtual void onMessage(const cms::Message* message);
		virtual void onCommand(decaf::lang::Pointer<activemq::commands::Command> &command AMQCPP_UNUSED);
		virtual void onException(const cms::CMSException& ex);

		virtual void transportInterrupted();
		virtual void transportResumed();

		unsigned long registerConnection(Connection* conn);
		void unregisterConnection(unsigned long id);

	private:
		void cleanup();

		std::string _brokerURI;
		std::string _destinationURI;

		cms::Connection *_connection;
		cms::Session *_session;
		cms::Destination *_destination;
		cms::MessageConsumer *_consumer;

		unsigned long _nextSockeId;

		decaf::util::concurrent::Mutex *_mapLocker;
		std::map<unsigned long, Connection*> _socketMap;
};

#endif // NAVI_SERVER_AMQMESSAGECONSUMER_HPP
