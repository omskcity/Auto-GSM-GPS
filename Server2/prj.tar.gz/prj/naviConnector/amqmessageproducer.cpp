/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#include "logmanager.h"
#include "ilogger.h"

#include "amqmessageproducer.hpp"

#include <decaf/util/concurrent/Mutex.h>
#include <decaf/util/concurrent/Semaphore.h>

#include <activemq/core/ActiveMQConnectionFactory.h>
#include <cms/CMSException.h>
#include <cms/Connection.h>
#include <cms/MessageProducer.h>
#include <cms/Queue.h>
#include <cms/Session.h>

AMQMessageProducer::AMQMessageProducer(activemq::core::ActiveMQConnectionFactory* connectionFactory, const std::string &destURI)
	: _isRunning(false), _connectionFactory(connectionFactory), _destinationURI(destURI),
	  _connection(0), _session(0), _destination(0), _producer(0), _messageQueue(),
	  _queueLocker(new decaf::util::concurrent::Mutex()),
	  _queueSyncer(new decaf::util::concurrent::Semaphore(0))
{
}

AMQMessageProducer::~AMQMessageProducer()
{
	close();

	delete _queueSyncer;
	delete _queueLocker;

}

void AMQMessageProducer::addMessage(const cms::Message* message)
{
	if (message) {
		_queueLocker->lock();
		_messageQueue.push_back(message->clone());
		_queueLocker->unlock();
	}
	_queueSyncer->release();
}

cms::Message *AMQMessageProducer::createMapMessage() const
{
	return _session->createMapMessage();
}

void AMQMessageProducer::handlePacketReceived(int type, long socket, const std::vector<unsigned char>& data)
{
	cms::MapMessage *msg = _session->createMapMessage();
	msg->setString("command", "package");
	msg->setInt("type", type);
	msg->setInt("socket_id", socket);
	msg->setBytes("data", data);
	addMessage(msg);
	delete msg;
}

void AMQMessageProducer::handleSocketConnected(long socket)
{
	cms::MapMessage *msg = _session->createMapMessage();
	msg->setString("command", "connect");
	msg->setInt("socket_id", socket);
	addMessage(msg);
	delete msg;
}

void AMQMessageProducer::handleSocketDisconnected(long socket)
{
	cms::MapMessage *msg = _session->createMapMessage();
	msg->setString("command", "disconnect");
	msg->setInt("socket_id", socket);
	addMessage(msg);
	delete msg;
}

void AMQMessageProducer::run()
{
	_isRunning = true;

	// Create a Connection
	try {
		_connection = _connectionFactory->createConnection();
		_connection->start();
	}
	catch (cms::CMSException& e) {
		e.printStackTrace();
		throw e;
	}

	_session = _connection->createSession(cms::Session::AUTO_ACKNOWLEDGE);
	_destination = _session->createQueue(_destinationURI);

	// Create a MessageProducer from the Session to the Topic or Queue
	_producer = _session->createProducer(_destination);
	_producer->setDeliveryMode(cms::DeliveryMode::NON_PERSISTENT);

	cms::Message* message = 0;
	while (_isRunning) {
		_queueSyncer->acquire();
		message = 0;
		_queueLocker->lock();
		if (!_messageQueue.empty()) {
			message = _messageQueue.front();
			_messageQueue.pop_front();
		}
		_queueLocker->unlock();
		if (message) {
			_producer->send(message);
			LoggingSystem::LogManager::instance()->getLogger("system")->debug("AMQMessageProducer::run()() | message sent !");
			delete message;
		}
	}
}

void AMQMessageProducer::close()
{
	if (_isRunning) {
		_isRunning = false;
		_queueLocker->lock();
		for (std::list<cms::Message*>::iterator it = _messageQueue.begin(); it != _messageQueue.end(); ++it)
			delete *it;
		_messageQueue.clear();
		_queueLocker->unlock();
		_queueSyncer->release();

		this->join();
	}

	cleanup();
}

void AMQMessageProducer::cleanup()
{
	// Destroy resources.
	try {
		if (_destination != NULL)
			delete _destination;
	}
	catch (cms::CMSException& e) {
		e.printStackTrace();
	}
	_destination = NULL;

	try {
		if (_producer != NULL)
			delete _producer;
	}
	catch (cms::CMSException& e) {
		e.printStackTrace();
	}
	_producer = NULL;

	// Close open resources.
	try {
		if (_session != NULL)
			_session->close();
		if (_connection != NULL)
			_connection->close();
	}
	catch (cms::CMSException& e) {
		e.printStackTrace();
	}

	try {
		if (_session != NULL)
			delete _session;
	}
	catch (cms::CMSException& e) {
		e.printStackTrace();
	}
	_session = NULL;

	try {
		if (_connection != NULL)
			delete _connection;
	}
	catch (cms::CMSException& e) {
		e.printStackTrace();
	}
	_connection = NULL;
}
