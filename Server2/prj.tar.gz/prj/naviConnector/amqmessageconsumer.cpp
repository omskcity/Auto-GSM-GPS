/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmail.com.
**
****************************************************************************/

#include "logmanager.h"
#include "ilogger.h"

#include "amqmessageconsumer.hpp"

#include "common.h"
#include "connection.hpp"

#include "activemqgate.hpp"
#include "amqmessageproducer.hpp"

#include <boost/format.hpp>

#include <activemq/core/ActiveMQConnectionFactory.h>
#include <activemq/core/ActiveMQConnection.h>
#include <decaf/util/concurrent/Mutex.h>
#include <decaf/util/concurrent/Lock.h>
#include <cms/CMSException.h>
#include <cms/Connection.h>
#include <cms/Session.h>
#include <cms/Queue.h>
#include <cms/ExceptionListener.h>
#include <cms/MessageListener.h>

AMQMessageConsumer::AMQMessageConsumer(const std::string& brokerURI,
	const std::string& destURI) : _brokerURI(brokerURI), _destinationURI(destURI),
	_connection(0), _session(0), _destination(0), _consumer(0), _nextSockeId(1),
	_mapLocker(new decaf::util::concurrent::Mutex()), _socketMap()
{
}

AMQMessageConsumer::~AMQMessageConsumer()
{
	close();
}


void AMQMessageConsumer::startWait()
{
	// Create a Connection
	try {
		activemq::core::ActiveMQConnectionFactory* connectionFactory =
			new activemq::core::ActiveMQConnectionFactory(_brokerURI);

		_connection = connectionFactory->createConnection();
		delete connectionFactory;

		activemq::core::ActiveMQConnection *amqConnection = dynamic_cast<activemq::core::ActiveMQConnection*>(_connection);
		if (amqConnection != NULL) {
			amqConnection->addTransportListener(this);
		}
		_connection->start();
	}
	catch (cms::CMSException& e) {
		std::stringstream ss;
		ss << "AMQMessageConsumer::startWait() | Exception: " << e.getMessage() << " | StackTrace: ";
		e.printStackTrace(ss);
		LoggingSystem::LogManager::instance()->getLogger("system")->fatal(ss.str());
		throw e;
	}

	_connection->setExceptionListener(this);

	_session = _connection->createSession(cms::Session::AUTO_ACKNOWLEDGE);
	_destination = _session->createQueue(_destinationURI);

	// Create a MessageConsumer from the Session to the Queue
	_consumer = _session->createConsumer(_destination);
	_consumer->setMessageListener(this);
}

void AMQMessageConsumer::close()
{
	decaf::util::concurrent::Lock locker(_mapLocker);
	_socketMap.clear();

	this->cleanup();
}

void AMQMessageConsumer::onMessage(const cms::Message* message)
{

	try {
		const cms::MapMessage *msg = dynamic_cast<const cms::MapMessage*>(message);

		if (msg) {
			std::vector<std::string> keys = msg->getMapNames();
			std::string tstr = "AMQMessageConsumer::onMessage() | keys:";
			for (int i = 0; i < keys.size(); ++i)
				tstr += " " + keys.at(i);
			LoggingSystem::LogManager::instance()->getLogger("system")->debug(tstr);

			std::string command = msg->getString("command");
			if (command == "package") {
				std::vector<unsigned char> data = msg->getBytes("data");
				unsigned long sock = msg->getInt("socket_id");

				decaf::util::concurrent::Lock locker(_mapLocker);
				std::map<unsigned long, Connection*>::iterator it = _socketMap.find(sock);
				if (it != _socketMap.end()) {
					Reply rep = Reply::stock_reply(Reply::bad_request);
					rep.data = data;
					unsigned short crc = calcCRC(rep.data);
					rep.data.push_back((unsigned char)(crc & 0xff));
					rep.data.push_back((unsigned char)((crc >> 8) & 0xff));
					((Connection*)it->second)->retransPacket(rep);

					std::string result = str(boost::format("AMQMessageConsumer::onMessage | package | data.size: %1% socket_id: %2%") % data.size() % sock);
					LoggingSystem::LogManager::instance()->getLogger("system")->debug(result);
				}
				else {
					std::string tstr = str(boost::format("AMQMessageConsumer::onMessage | Socket: %1% not found !") % sock );
					LoggingSystem::LogManager::instance()->getLogger("system")->warn(tstr);
				}
			}
			if (command == "get_socket_list") {
				LoggingSystem::LogManager::instance()->getLogger("system")->debug("AMQMessageConsumer::onMessage | get_socket_list");
				cms::MapMessage *rmsg = static_cast<cms::MapMessage*>(ActiveMQGate::instance()->messageProducer()->createMapMessage());
				rmsg->setString("command", "get_socket_list");
				std::stringstream ss;
				_mapLocker->lock();
				for (std::map<unsigned long, Connection*>::iterator it = _socketMap.begin(); it != _socketMap.end(); ++it) {
					if (it != _socketMap.begin())
						ss << ",";
					ss << it->first;
				}
				_mapLocker->unlock();
				rmsg->setString("sockets", ss.str());
				ActiveMQGate::instance()->messageProducer()->addMessage(rmsg);
				delete rmsg;

				LoggingSystem::LogManager::instance()->getLogger("system")->warn("AMQMessageConsumer::onMessage | get_socket_list | " + ss.str());
			}
			if (command == "disconnect") {
				LoggingSystem::LogManager::instance()->getLogger("system")->debug("AMQMessageConsumer::onMessage | disconnect");
				unsigned long sock = msg->getInt("socket_id");
				decaf::util::concurrent::Lock locker(_mapLocker);
				std::map<unsigned long, Connection*>::iterator it = _socketMap.find(sock);
				if (it != _socketMap.end()) {
					((Connection*)it->second)->close();
					_socketMap.erase(it);
				}
			}
		}
		else {
			LoggingSystem::LogManager::instance()->getLogger("system")->info("AMQMessageConsumer::onMessage | Unknown message received");
		}
	}
	catch (cms::CMSException& e) {
		std::stringstream ss;
		ss << "AMQMessageConsumer::onMessage | Exception: " << e.getMessage() << " | StackTrace: ";
		e.printStackTrace(ss);
		LoggingSystem::LogManager::instance()->getLogger("system")->error(ss.str());
	}
}

void AMQMessageConsumer::onCommand(decaf::lang::Pointer<activemq::commands::Command> &command)
{
	LoggingSystem::LogManager::instance()->getLogger("system")->info("AMQMessageConsumer::onCommand()");
}

void AMQMessageConsumer::onException(const cms::CMSException &ex)
{
	LoggingSystem::LogManager::instance()->getLogger(
		"system")->error("AMQMessageConsumer::onException: " + ex.getMessage());
}

void AMQMessageConsumer::transportInterrupted()
{
	LoggingSystem::LogManager::instance()->getLogger("system")->info("AMQMessageConsumer::transportInterrupted()");
}

void AMQMessageConsumer::transportResumed()
{
	LoggingSystem::LogManager::instance()->getLogger("system")->info("AMQMessageConsumer::transportResumed()");
}

unsigned long AMQMessageConsumer::registerConnection(Connection* conn)
{
	decaf::util::concurrent::Lock locker(_mapLocker);
	unsigned long id = _nextSockeId;
	_socketMap[id] = conn;
	ActiveMQGate::instance()->messageProducer()->handleSocketConnected(id);
	++_nextSockeId;

	std::string info = str(boost::format("AMQMessageConsumer::registerConnection() | Connection: %1% | socket: %2% | Id: %3% | _socketMap.size(): %4%") % (void*)conn % conn->socket().native_handle() % id % _socketMap.size());
	LoggingSystem::LogManager::instance()->getLogger("system")->info(info);

	return id;
}

void AMQMessageConsumer::unregisterConnection(unsigned long id)
{
	decaf::util::concurrent::Lock locker(_mapLocker);
	std::map<unsigned long, Connection*>::iterator it = _socketMap.find(id);
	if (it != _socketMap.end()) {
		std::string info = str(boost::format("AMQMessageConsumer::unregisterConnection() | Id: %1% Connection: %2% | socket: %3% | _socketMap.size(): %4%") % id % (void*)it->second % ((Connection*)it->second)->socket().native_handle() % _socketMap.size());
		ActiveMQGate::instance()->messageProducer()->handleSocketDisconnected(id);
		_socketMap.erase(it);
		LoggingSystem::LogManager::instance()->getLogger("system")->info(info);
	}

}

void AMQMessageConsumer::cleanup()
{
	// Destroy resources.
	try {
		if (_destination != NULL)
			delete _destination;
	}
	catch (cms::CMSException& e) {
		e.printStackTrace();
	}
	_destination = NULL;

	try {
		if (_consumer != NULL)
			delete _consumer;
	}
	catch (cms::CMSException& e) {
		e.printStackTrace();
	}
	_consumer = NULL;

	// Close open resources.
	try {
		if (_session != NULL)
			_session->close();
		if (_connection != NULL)
			_connection->close();
	}
	catch (cms::CMSException& e) {
		e.printStackTrace();
	}

	try {
		if (_session != NULL)
			delete _session;
	}
	catch (cms::CMSException& e) {
		e.printStackTrace();
	}
	_session = NULL;

	try {
		if (_connection != NULL)
			delete _connection;
	}
	catch (cms::CMSException& e) {
		e.printStackTrace();
	}
	_connection = NULL;

	LoggingSystem::LogManager::instance()->getLogger("system")->debug("AMQMessageConsumer::cleanup()");
}

