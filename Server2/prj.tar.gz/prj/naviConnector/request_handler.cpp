/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmain.com.
**
****************************************************************************/

#include "logmanager.h"
#include "ilogger.h"

#include "request_handler.hpp"
#include "reply.hpp"
#include "request.hpp"
#include "activemqgate.hpp"
#include "amqmessageproducer.hpp"

#include "common.h"

#include <fstream>
#include <sstream>
#include <string>
#include "boost/date_time/gregorian/gregorian.hpp"
#include "boost/date_time/posix_time/posix_time.hpp"
//#include <boost/lexical_cast.hpp>
#include <boost/format.hpp>

#include <cms/MapMessage.h>

RequestHandler::RequestHandler(const std::string& logs_path)
  : _logs_path(logs_path)
{
}

RequestHandler::~RequestHandler()
{
}

void RequestHandler::handleRequest(const Request& req, Reply& rep,
	unsigned long socketId)
{
	ActiveMQGate::instance()->messageProducer()->handlePacketReceived(req.type, socketId, req.data);

	rep = Reply::stock_reply(Reply::bad_request);
	rep.data.push_back(0x01);
	//uint16_t crc = calcCRC(rep.data);
	rep.data.push_back((uint8_t)(req.crc & 0xff));
	rep.data.push_back((uint8_t)((req.crc >> 8) & 0xff));

	std::stringstream ss;
	ss << "RequestHandler::handleRequest | socketId: " << socketId << "  request data length: " << req.data.size();
	LoggingSystem::LogManager::instance()->getLogger("system")->debug(ss.str());
}
