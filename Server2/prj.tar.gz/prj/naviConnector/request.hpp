/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmain.com.
**
****************************************************************************/

#ifndef HTTP_SERVER2_REQUEST_HPP
#define HTTP_SERVER2_REQUEST_HPP

#include <ostream>
#include <string>
#include <sstream>
#include <vector>

#include <stdint.h>

#include "boost/lexical_cast.hpp"
//#include <boost/format.hpp>

/// A request received from a device.
struct Request
{
	uint8_t type;
	std::vector<uint8_t> data;
	uint16_t	crc;

    friend std::ostream& operator<<( std::ostream& out, const Request& value )
    {
        out << std::hex << (unsigned short)value.type;
		for (size_t i = 0; i < value.data.size(); ++i)
			out << std::hex << " " << (unsigned short)value.data.at(i);
		return out;
    }

	std::string toString() const {
		std::stringstream ss(std::stringstream::out);
		ss << "type: " << (int)type << std::endl;
		ss << "data:";
		ss << std::hex;
		for (size_t i = 0; i < data.size(); ++i) {
			ss << " ";
			if (data.at(i) < 0x10)
				ss << "0";
			ss << (unsigned short)data.at(i);
		}
		ss << std::endl;
		return ss.str();
	}
};

#endif // HTTP_SERVER2_REQUEST_HPP
