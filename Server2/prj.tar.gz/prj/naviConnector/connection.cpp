/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmain.com.
**
****************************************************************************/

#include "logmanager.h"
#include "ilogger.h"

#include <vector>
#include <boost/bind.hpp>
#include <boost/format.hpp>

#include "connection.hpp"
#include "request_handler.hpp"

#include "activemqgate.hpp"
#include "amqmessageconsumer.hpp"

Connection::Connection(boost::asio::io_service& io_service,
	RequestHandler& handler) : _socket(io_service), _id(0), _requestHandler(handler)
{
}

Connection::~Connection()
{
	close();

	std::string result = str(boost::format("Connection::~Connection() | DESTROY | this: %1% | _socket: %2%") % (void*)this % _socket.native_handle());
	LoggingSystem::LogManager::instance()->getLogger("system")->debug(result);
}

boost::asio::ip::tcp::socket& Connection::socket()
{
	return _socket;
}

void Connection::start()
{
	_socket.async_read_some(boost::asio::buffer(_buffer),
		boost::bind(&Connection::handleRead, shared_from_this(),
		boost::asio::placeholders::error,
		boost::asio::placeholders::bytes_transferred));

	_id = ActiveMQGate::instance()->messageConsumer()->registerConnection(this);

	std::string result = str(boost::format("Connection::start() | this: %1% | _id: %2% | _socket: %3%") % (void*)this % _id % _socket.native_handle());
	LoggingSystem::LogManager::instance()->getLogger("system")->debug(result);
}

void Connection::close()
{
	std::string info = str(boost::format("Connection::close() | this: %1% | _id: %2% | _socket: %3%") % (void*)this % _id % _socket.native_handle());

	ActiveMQGate::instance()->messageConsumer()->unregisterConnection(_id);

	boost::system::error_code ignored_ec;
	_socket.shutdown(boost::asio::ip::tcp::socket::shutdown_both, ignored_ec);
	_id = 0;

	LoggingSystem::LogManager::instance()->getLogger("system")->debug(info);
}

void Connection::retransPacket(Reply& reply)
{
	boost::asio::write(_socket, reply.to_buffers());
	std::string info = str(boost::format("Connection::retransPacket | _id: %1% _socket: %2% | Packet retranslated !") % _id % _socket.native_handle());
	LoggingSystem::LogManager::instance()->getLogger("system")->debug(info);
}

void Connection::handleRead(const boost::system::error_code& e,
	std::size_t bytes_transferred)
{
	if (!e) {
		boost::tribool result;
		if (bytes_transferred < 16384) {
			boost::tie(result, boost::tuples::ignore) = _requestParser.parse(_request,
				_buffer.data(), _buffer.data() + bytes_transferred);
		}
		else {
			LoggingSystem::LogManager::instance()->getLogger("system")->error("Connection::handleRead | BUFFER OVERFLOW !");
		}

		if (result) {
			_requestHandler.handleRequest(_request, _reply, _id);
			boost::asio::async_write(_socket, _reply.to_buffers(),
				boost::bind(&Connection::handleWrite, shared_from_this(),
				boost::asio::placeholders::error));
		}
		else if (!result) {
			_reply = Reply::stock_reply(Reply::bad_request);
			boost::asio::async_write(_socket, _reply.to_buffers(),
				boost::bind(&Connection::handleWrite, shared_from_this(),
				boost::asio::placeholders::error));
		}
		else {
			_socket.async_read_some(boost::asio::buffer(_buffer),
				boost::bind(&Connection::handleRead, shared_from_this(),
				boost::asio::placeholders::error,
				boost::asio::placeholders::bytes_transferred));
		}
	}
	else {
		if (e == boost::asio::error::eof) {
			LoggingSystem::LogManager::instance()->getLogger("system")->debug("Connection::handleRead | CloseConnection");
			close();
			return;
		}
		else {
			_requestParser.reset();
			_socket.async_read_some(boost::asio::buffer(_buffer),
				boost::bind(&Connection::handleRead, shared_from_this(),
				boost::asio::placeholders::error,
				boost::asio::placeholders::bytes_transferred));
			LoggingSystem::LogManager::instance()->getLogger("system")->error("Connection::handleRead e: " + e.message());
		}
	}
}

void Connection::handleWrite(const boost::system::error_code& e)
{
	if (!e) {
		// Initiate graceful connection closure.
		if (_reply.isCloseAfterSend) {
			std::string tstr = str(boost::format("Connection::handleWrite | _socket: %1% | SHUTDOWN") % _socket.native_handle());
			LoggingSystem::LogManager::instance()->getLogger("system")->debug(tstr);
			close();
		}
		else {
			_requestParser.reset();
			_socket.async_read_some(boost::asio::buffer(_buffer),
				boost::bind(&Connection::handleRead, shared_from_this(),
				boost::asio::placeholders::error,
				boost::asio::placeholders::bytes_transferred));
			std::string tstr = str(boost::format("Connection::handleWrite | _socket: %1% | Reset to wait new data") % _socket.native_handle());
			LoggingSystem::LogManager::instance()->getLogger("system")->debug(tstr);
		}
	}
	else {
		LoggingSystem::LogManager::instance()->getLogger("system")->error("Connection::handleWrite e: " + e.message());
	}
}

void Connection::handleWrite2(const boost::system::error_code& e)
{
	LoggingSystem::LogManager::instance()->getLogger("system")->debug("Connection::handleWrite2() | Packet retranslated !");
}
