/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmain.com.
**
****************************************************************************/

#include <stdio.h>

#if defined(LINUX)
#include <signal.h>
#include <unistd.h>
#include <syslog.h>
#endif

#include <fstream>
#include <iostream>
#include <string>

#include "defs.h"

#include "logmanager.h"
#include "ilogger.h"
#include "basiclogger.h"
#include "basicfileappender.h"

#include <boost/lexical_cast.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/asio.hpp>

#include "activemqgate.hpp"
#include "configuration.hpp"
#include "server.hpp"

const char * const strAbout = "NAVI Server version 0.1";
const char * const strUsage = "Usage: naviServer start|stop";

Configuration conf("./naviConnector.cfg");

void Usage()
{
	Console() << strAbout << EndLine;
	Console() << strUsage << EndLine;
}

#if defined(LINUX)
pid_t getDaemonPid()
{
	std::ifstream pidFile("/var/run/naviConnector.pid", std::fstream::in);
	if (!pidFile)
		return -1;

	pid_t pid;
	pidFile >> pid;

	return pid;
}

int prepareDaemon()
{
	if (pid_t pid = fork()) {
		if (pid > 0) {
			exit(0);
		}
		else {
			syslog(LOG_ERR | LOG_USER, "First fork failed: %m");
			return 1;
		}
	}

	// Make the process a new session leader. This detaches it from the
	// terminal.
	setsid();

	// A process inherits its working directory from its parent. This could be
	// on a mounted filesystem, which means that the running daemon would
	// prevent this filesystem from being unmounted. Changing to the root
	// directory avoids this problem.
	chdir("/");

	// The file mode creation mask is also inherited from the parent process.
	// We don't want to restrict the permissions on files created by the
	// daemon, so the mask is cleared.
	umask(0);

	// A second fork ensures the process cannot acquire a controlling terminal.
	if (pid_t pid = fork()) {
		if (pid > 0) {
			exit(0);
		}
		else {
			syslog(LOG_ERR | LOG_USER, "Second fork failed: %m");
			return 1;
		}
	}

	// Close the standard streams. This decouples the daemon from the terminal
	// that started it.
	close(0);
	close(1);
	close(2);

	// We don't want the daemon to have any standard input.
	if (open("/dev/null", O_RDONLY) < 0) {
		syslog(LOG_ERR | LOG_USER, "Unable to open /dev/null: %m");
		return 1;
	}

	// Send standard output to a log file.
	const char* output = "/tmp/naviconnector.daemon.out";
	const int flags = O_WRONLY | O_CREAT | O_APPEND;
	const mode_t mode = S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH;
	if (open(output, flags, mode) < 0) {
		syslog(LOG_ERR | LOG_USER, "Unable to open output file %s: %m", output);
		return 1;
	}

	// Also send standard error to the same log file.
	if (dup(1) < 0) {
		syslog(LOG_ERR | LOG_USER, "Unable to dup output descriptor: %m");
		return 1;
	}

	std::ofstream pidFile("/var/run/naviConnector.pid", std::fstream::out | std::fstream::trunc);
	if (!pidFile)
		return 1;
	pidFile << getpid();
	pidFile.close();

	return 0;
}

#endif

int work()
{
	LoggingSystem::LogManager *logManager = new LoggingSystem::LogManager();
	LoggingSystem::BasicLogger *logger = new LoggingSystem::BasicLogger("system");
	logger->addLogAppender(LoggingSystem::ILogAppenderPtr(new LoggingSystem::BasicFileAppender("BasicFileAppender", conf.logFileName())));
	logManager->registerLogger(logger);

	LoggingSystem::LogManager::instance()->getLogger("system")->info("Daemon started");

	// Initialise the server.
	ActiveMQGate::initialize();

	ActiveMQGate *amqGate = NULL;
	try {
		amqGate = new ActiveMQGate(conf.activeMQBrokerURI(), conf.activeMQProducerURI(), conf.activeMQConsumerURI());
		amqGate->run();
	}
	catch (std::exception& e) {
		LoggingSystem::LogManager::instance()->getLogger("system")->fatal("Exception: " + std::string(e.what()));
		ActiveMQGate::shutdown();
		return -1;
	}

	LoggingSystem::LogManager::instance()->getLogger("system")->debug("brokerURI: " + conf.activeMQBrokerURI());

	NAVIServer *naviServer = NULL;
	try {
		naviServer = new NAVIServer(conf.address(), conf.port(), conf.servicesPollSize());

		// Run the server until stopped.
		naviServer->run();
	}
	catch (std::exception& e) {
		LoggingSystem::LogManager::instance()->getLogger("system")->fatal("Exception: " + std::string(e.what()));
	}

	if (naviServer) {
		//naviServer->finish();
		delete naviServer;
	}

	if (amqGate) {
		amqGate->finish();
		delete amqGate;
	}

	ActiveMQGate::shutdown();

	remove("/var/run/naviConnector.pid");

	LoggingSystem::LogManager::instance()->getLogger("system")->info("Daemon stopped");

	logManager->unregisterLogger(logger);
	delete logger;
	delete logManager;

	exit(EXIT_SUCCESS);
	//return 0;
}

int main(int argc, char* argv[])
{
#if defined(LINUX)
	if (argc >= 2) {
		if (!strcmp(argv[1], "stop")) {
			pid_t pid = getDaemonPid();
			if (pid != -1) {
				if (kill(pid, SIGTERM) == ESRCH) {
					remove("/var/run/naviConnector.pid");
				}
				Debug() << "TERM pid: " << pid << std::endl;
				exit(EXIT_SUCCESS);
			}
			else {
				Debug() << "Deamon is not started !\n";
				exit(EXIT_FAILURE);
			}
		}
		Usage();
		return 1;
	}

	pid_t pid = getDaemonPid();
	if (pid != -1) {
		Debug() << "Deamon has already started ! Please, finish it before\n";
		exit(EXIT_FAILURE);
	}
	prepareDaemon();
	return work();

#endif
	Usage();
	return 0;
}
