/****************************************************************************
**
** This file is part of naviServer
**
** Copyright (c) 2012 MaxSHdr (Dreamatec)
**
**
**
** This file is provided AS IS with NO WARRANTY OF ANY KIND, INCLUDING THE
** WARRANTY OF DESIGN, MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
**
** If you have questions regarding the use of this file, please contact
** MaxSHdr Dreamatec at maxshdr@gmain.com.
**
****************************************************************************/

#ifndef DEFS_H
#define DEFS_H

#define	EndLine		std::endl
#define	CString		std::string
#define	Debug()		std::cerr
#define	Console()	std::cout
#define	Input()		std::cin

#endif // DEFS_H
